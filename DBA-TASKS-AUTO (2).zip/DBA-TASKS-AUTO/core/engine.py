"""
Snowflake DBA Tasks Automation - Core Engine

This is the SINGLE core logic file for the entire framework.
All business logic, shared utilities, and task implementations reside here.
Command scripts are thin wrappers that validate input and delegate to this engine.

Usage:
    from core.engine import Engine

    engine = Engine()
    engine.initialize()
    # ... use engine methods for task execution
"""

import os
import sys
import time
import functools

import yaml

from core.logger import get_logger, reset_logger
from core.connection import get_connection, close_connection


# =============================================================================
# Configuration Loader
# =============================================================================

# Default config file path (relative to framework root)
DEFAULT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "config",
    "dba_tasks_config.yaml",
)


def load_config(config_path=None):
    """
    Load and return the YAML configuration.

    Args:
        config_path: str - Path to config file. Uses default if None.

    Returns:
        dict - Parsed configuration dictionary.

    Raises:
        FileNotFoundError: If config file does not exist.
        yaml.YAMLError: If config file is malformed.
    """
    path = config_path or DEFAULT_CONFIG_PATH

    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"Configuration file not found: {path}. "
            f"Please create it from the template."
        )

    with open(path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    if not config:
        raise ValueError(f"Configuration file is empty: {path}")

    return config


# =============================================================================
# Trace Decorator
# =============================================================================

def trace(func):
    """
    Decorator that logs function entry and exit.

    Automatically logs:
    - Entry: function name and sanitized parameters
    - Exit: function name and status (success/exception)

    Usage:
        @trace
        def my_function(param1, param2):
            ...
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger = get_logger()
        func_name = func.__name__
        module_name = func.__module__

        # Sanitize parameters for logging (exclude sensitive values)
        safe_kwargs = {
            k: "***" if _is_sensitive_key(k) else v
            for k, v in kwargs.items()
        }

        logger.info(f"Entering {func_name} | params: {safe_kwargs}")

        try:
            result = func(*args, **kwargs)
            logger.info(f"Exiting {func_name} | status: success")
            return result
        except Exception as e:
            logger.erro(
                f"Exiting {func_name} | status: exception | error: {str(e)}"
            )
            raise

    return wrapper


def _is_sensitive_key(key):
    """Check if a parameter key likely contains sensitive data."""
    sensitive_keywords = [
        "password", "passphrase", "token", "secret", "key", "credential",
        "pat", "oauth", "private",
    ]
    key_lower = key.lower()
    return any(s in key_lower for s in sensitive_keywords)


# =============================================================================
# Input Validation
# =============================================================================

def validate_connection_name(config, connection_name):
    """
    Validate that a connection name exists in the configuration.

    Args:
        config: dict - Full configuration dictionary.
        connection_name: str - Connection name to validate.

    Returns:
        True if valid.

    Raises:
        ValueError: If connection name is not found.
    """
    connections = config.get("connections", {})
    if connection_name not in connections:
        available = ", ".join(connections.keys()) if connections else "none"
        raise ValueError(
            f"Connection '{connection_name}' not found in configuration. "
            f"Available connections: {available}"
        )
    return True


def validate_required_params(params_dict, required_keys):
    """
    Validate that all required parameters are present and non-empty.

    Args:
        params_dict: dict - Dictionary of parameter name -> value.
        required_keys: list - List of required parameter names.

    Returns:
        True if all valid.

    Raises:
        ValueError: If any required parameter is missing or empty.
    """
    missing = []
    for key in required_keys:
        val = params_dict.get(key)
        if val is None or (isinstance(val, str) and val.strip() == ""):
            missing.append(key)

    if missing:
        raise ValueError(
            f"Missing required parameters: {', '.join(missing)}"
        )
    return True


# =============================================================================
# Engine Class
# =============================================================================

class Engine:
    """
    Core engine for Snowflake DBA Tasks Automation.

    Provides:
    - Configuration loading
    - Logger initialization
    - Connection management
    - Shared utilities for all command scripts

    Usage:
        engine = Engine()
        engine.initialize()
        conn = engine.get_connection("prod_main")
        # ... perform DBA tasks
        engine.shutdown()
    """

    def __init__(self, config_path=None):
        """
        Initialize engine with optional config path override.

        Args:
            config_path: str - Path to configuration file.
        """
        self._config_path = config_path
        self._config = None
        self._logger = None
        self._connections = {}  # Active connections cache
        self._task_id = None  # Unique epoch timestamp per invocation
        self._pipeline_id = None  # Azure DevOps pipeline Build ID (optional)

    @trace
    def initialize(self):
        """
        Load configuration and initialize logging.
        Must be called before any other engine operations.
        """
        # Load configuration
        self._config = load_config(self._config_path)

        # Initialize logger with config
        self._logger = get_logger(self._config)

        # Generate unique task ID (epoch timestamp in milliseconds) for this invocation
        self._task_id = int(time.time() * 1000)

        self._logger.info("Engine initialized successfully")

        return self

    @property
    def config(self):
        """Get the loaded configuration dictionary."""
        if self._config is None:
            raise RuntimeError("Engine not initialized. Call initialize() first.")
        return self._config

    @property
    def logger(self):
        """Get the logger instance."""
        if self._logger is None:
            # Return default logger if engine not yet initialized
            return get_logger()
        return self._logger

    def console_msg(self, message):
        """
        Print a high-level status message to console (stdout).

        Used for displaying major task progress to the user during script execution.
        Does NOT affect file logging or audit trail functionality.

        Args:
            message: str - Status message to display.
        """
        print(f"  >> {message}", flush=True)

    def set_pipeline_id(self, pipeline_id):
        """
        Set the pipeline ID for audit logging.

        Called when script is triggered by an Azure DevOps pipeline.
        The pipeline ID is included in all subsequent audit log records.

        Args:
            pipeline_id: str - Azure DevOps Build ID (or None if not pipeline-triggered).
        """
        self._pipeline_id = pipeline_id
        if pipeline_id:
            self._logger.info(f"Pipeline ID set: {pipeline_id}")

    @trace
    def get_connection(self, connection_name):
        """
        Get a Snowflake connection by name. Caches connections for reuse.

        Args:
            connection_name: str - Name of the connection from config.

        Returns:
            snowflake.connector.SnowflakeConnection
        """
        # Return cached connection if still open
        if connection_name in self._connections:
            conn = self._connections[connection_name]
            if not conn.is_closed():
                return conn
            else:
                del self._connections[connection_name]

        # Validate and create new connection
        validate_connection_name(self._config, connection_name)
        conn = get_connection(self._config, connection_name)
        self._connections[connection_name] = conn
        return conn

    @trace
    def get_metadata_connection(self):
        """
        Get the connection designated for metadata operations.

        Returns:
            snowflake.connector.SnowflakeConnection
        """
        metadata_cfg = self._config.get("metadata", {})
        conn_name = metadata_cfg.get("connection")

        if not conn_name:
            raise ValueError(
                "Metadata connection not configured. "
                "Set 'metadata.connection' in config."
            )

        conn = self.get_connection(conn_name)

        # Switch to metadata database/schema if configured
        meta_db = metadata_cfg.get("database")
        meta_schema = metadata_cfg.get("schema")

        if meta_db:
            conn.cursor().execute(f"USE DATABASE {meta_db}")
        if meta_schema:
            conn.cursor().execute(f"USE SCHEMA {meta_schema}")

        return conn

    @trace
    def execute_query(self, connection_name, query, params=None):
        """
        Execute a SQL query on a named connection.

        Args:
            connection_name: str - Connection name from config.
            query: str - SQL query to execute.
            params: tuple/list - Optional query parameters.

        Returns:
            list - Query results as list of tuples.
        """
        conn = self.get_connection(connection_name)
        cursor = conn.cursor()

        try:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            results = cursor.fetchall()
            self._logger.info(
                f"Query executed on '{connection_name}': {len(results)} rows returned"
            )
            return results
        except Exception as e:
            self._logger.erro(
                f"Query execution failed on '{connection_name}': {str(e)}"
            )
            raise
        finally:
            cursor.close()

    @trace
    def execute_sql(self, connection_name, sql, description=""):
        """
        Execute a single SQL statement and raise on failure.
        After execution, inserts an audit record into
        SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG (audit insert is not logged to file).

        Args:
            connection_name: str - Connection name from config.
            sql: str - SQL statement to execute.
            description: str - Human-readable description for logging.

        Returns:
            list - Query results as list of tuples.

        Raises:
            RuntimeError: If the SQL execution fails.
        """
        conn = self.get_connection(connection_name)
        cursor = conn.cursor()
        try:
            self._logger.info(f"Executing SQL [{description}]: {sql}")
            cursor.execute(sql)
            query_id = cursor.sfqid  # Snowflake query ID for this execution
            results = cursor.fetchall()
            self._logger.info(
                f"SQL executed successfully [{description}]: {len(results)} rows returned"
            )
            # Log the output of the SQL command
            if results:
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                self._logger.info(f"SQL output [{description}]: columns={columns}")
                for row in results:
                    self._logger.info(f"SQL output [{description}]: {row}")
            else:
                self._logger.info(f"SQL output [{description}]: (no rows)")

            # Insert audit record (not logged to file, best-effort)
            self._insert_audit_log(conn, sql, results, query_id, connection_name)

            return results
        except Exception as e:
            self._logger.erro(
                f"SQL execution failed [{description}]: {str(e)}"
            )
            raise RuntimeError(
                f"SQL execution failed [{description}]: {str(e)}"
            ) from e
        finally:
            cursor.close()

    def execute_metadata_sql(self, sql, description=""):
        """
        Execute a SQL statement on the metadata connection.

        Used for reading metadata tables (TASK_TO_ROLE_MAP, ACCESS_TO_ROLES).
        Does NOT trigger audit logging to avoid recursion.

        Args:
            sql: str - SQL statement to execute.
            description: str - Human-readable description for logging.

        Returns:
            list - Query results as list of tuples.

        Raises:
            RuntimeError: If the SQL execution fails.
        """
        meta_cfg = self._config.get("metadata", {})
        meta_conn_name = meta_cfg.get("connection")
        if not meta_conn_name:
            raise ValueError(
                "Metadata connection not configured. "
                "Set 'metadata.connection' in config."
            )

        conn = self.get_connection(meta_conn_name)
        cursor = conn.cursor()
        try:
            self._logger.info(f"Executing metadata SQL [{description}]: {sql}")
            cursor.execute(sql)
            results = cursor.fetchall()
            self._logger.info(
                f"Metadata SQL executed [{description}]: {len(results)} rows returned"
            )
            return results
        except Exception as e:
            self._logger.erro(
                f"Metadata SQL failed [{description}]: {str(e)}"
            )
            raise RuntimeError(
                f"Metadata SQL failed [{description}]: {str(e)}"
            ) from e
        finally:
            cursor.close()

    def _insert_audit_log(self, conn, cmd, cmd_output, query_id="", connection_name=""):
        """
        Insert an audit record into SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG.

        Uses the metadata connection for writing audit records, ensuring all
        audit history is centralized in one location regardless of which
        connection the command script executed against.

        This method does NOT log to the log file and does NOT raise on failure.
        Audit logging is best-effort — failures are silently ignored to avoid
        disrupting the main execution flow.

        Args:
            conn: Active Snowflake connection (unused, kept for signature compat).
            cmd: str - The SQL command that was executed.
            cmd_output: list - The result rows from the executed command.
            query_id: str - The Snowflake query ID of the executed command.
            connection_name: str - The connection name used by the command script.
        """
        try:
            meta_cfg = self._config.get("metadata", {})
            meta_db = meta_cfg.get("database", "")
            meta_schema = meta_cfg.get("schema", "")
            meta_conn_name = meta_cfg.get("connection", "")
            fq_audit_table = f"{meta_db}.{meta_schema}.SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG"

            # Get metadata connection for audit write
            if meta_conn_name:
                audit_conn = self.get_connection(meta_conn_name)
            else:
                # Fallback to passed connection if metadata connection not configured
                audit_conn = conn

            # Get the invoking script/command name
            task_name = os.path.basename(sys.argv[0]) if sys.argv else "unknown"
            safe_task_name = task_name.replace("'", "''")

            # Sanitize cmd for SQL string (escape single quotes)
            safe_cmd = cmd.replace("'", "''")

            # Format output as string, truncate if too large (max 10000 chars)
            output_str = str(cmd_output) if cmd_output else ""
            if len(output_str) > 10000:
                output_str = output_str[:10000] + "...(truncated)"
            safe_output = output_str.replace("'", "''")

            # Sanitize query ID
            safe_query_id = str(query_id).replace("'", "''") if query_id else ""

            # Sanitize pipeline ID
            safe_pipeline_id = str(self._pipeline_id).replace("'", "''") if self._pipeline_id else ""

            # Sanitize connection name
            safe_connection = str(connection_name).replace("'", "''") if connection_name else ""

            audit_sql = (
                f"INSERT INTO {fq_audit_table} "
                f"(TASK_ID, EXECUTED_AT, TASK_NAME, USERNAME, ROLE_NAME, DATABASE_NAME, WAREHOUSE_NAME, "
                f"CMD, CMD_OUTPUT, CMD_QUERY_ID, PIPELINE_ID, SNF_CONNECTION) "
                f"VALUES ({self._task_id}, CURRENT_TIMESTAMP(), '{safe_task_name}', CURRENT_USER(), CURRENT_ROLE(), "
                f"CURRENT_DATABASE(), CURRENT_WAREHOUSE(), '{safe_cmd}', '{safe_output}', "
                f"'{safe_query_id}', '{safe_pipeline_id}', '{safe_connection}')"
            )

            audit_cursor = audit_conn.cursor()
            try:
                audit_cursor.execute(audit_sql)
            finally:
                audit_cursor.close()
        except Exception:
            # Audit logging is best-effort; do not disrupt main flow
            pass

    @trace
    def provision_database_access(self, connection_name, database_name, database_type):
        """
        Provision access/grants on a database and all its objects.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use
        2. Reads ACCESS_TO_ROLES for role-to-access mappings
        3. Verifies the database exists
        4. Switches role and database
        5. Grants RO/RW/RWD/C privileges via database roles
        6. Sets up database role hierarchy
        7. Grants access to roles per ACCESS_TO_ROLES config

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database to provision access on.
            database_type: str - Type of database (APPLICATION_DB or BKP_DB).

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        db = database_name.upper()
        db_type = database_type.upper()

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for ACCESS_PROVISION...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='ACCESS_PROVISION'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'ACCESS_PROVISION' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='ACCESS_PROVISION'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='ACCESS_PROVISION' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Read ACCESS_TO_ROLES ---
        self.console_msg(f"Reading ACCESS_TO_ROLES for DATABASE_TYPE='{db_type}'...")
        fq_access_roles = f"{meta_db}.{meta_schema}.ACCESS_TO_ROLES"

        self._logger.info(
            f"Reading {fq_access_roles} for DATABASE_TYPE='{db_type}'"
        )
        access_roles_sql = (
            f"SELECT ROLE_NAME, ACCESS_TO_BE_GRANTED, DATABASE_TYPE "
            f"FROM {fq_access_roles} "
            f"WHERE DATABASE_TYPE = '{db_type}' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        access_roles_rows = self.execute_metadata_sql(
            access_roles_sql, "Read ACCESS_TO_ROLES"
        )
        self._logger.info(
            f"ACCESS_TO_ROLES returned {len(access_roles_rows)} rows"
        )

        # --- Step 3: Verify database exists ---
        self.console_msg(f"Verifying database '{db}' exists...")
        self._logger.info(f"Verifying database '{db}' exists")
        show_db_sql = f"SHOW DATABASES LIKE '{db}'"
        db_rows = self.execute_sql(
            connection_name, show_db_sql, f"Verify database {db} exists"
        )
        if len(db_rows) == 0:
            raise RuntimeError(
                f"Database '{db}' does not exist on the connected Snowflake "
                f"account. Terminating access provision."
            )
        self._logger.info(f"Database '{db}' confirmed to exist")

        # --- Step 4: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 5: Switch database ---
        self.console_msg(f"Switching to database: {db}...")
        self._logger.info(f"Switching to database: {db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {db}", f"Switch to database {db}"
        )

        # --- Step 6: Determine required access levels from ACCESS_TO_ROLES ---
        required_access_types = set()
        for row in access_roles_rows:
            required_access_types.add(row[1].upper())

        # Map access types to which database role privileges are needed
        needs_ro = bool(required_access_types & {"RO", "RW", "ADMIN", "SRV_RO", "SRV_RW", "SRV_RWD", "SRV_RWDC", "SRV_ADMIN"})
        needs_rw = bool(required_access_types & {"RW", "ADMIN", "SRV_RW", "SRV_RWD", "SRV_RWDC", "SRV_ADMIN"})
        needs_rwd = bool(required_access_types & {"ADMIN", "SRV_RWD", "SRV_RWDC", "SRV_ADMIN"})
        needs_c = bool(required_access_types & {"ADMIN", "SRV_RWDC", "SRV_ADMIN"})

        self._logger.info(
            f"Required access levels based on ACCESS_TO_ROLES: "
            f"RO={needs_ro}, RW={needs_rw}, RWD={needs_rwd}, C={needs_c}"
        )

        # Grant only the required privilege levels
        if needs_ro:
            self.console_msg(f"Granting READ-ONLY access to {db}_ALL_R...")
            self._grant_read_only_access(connection_name, db)
        if needs_rw:
            self.console_msg(f"Granting READ-WRITE access to {db}_ALL_RW...")
            self._grant_read_write_access(connection_name, db)
        if needs_rwd:
            self.console_msg(f"Granting READ-WRITE-DELETE access to {db}_ALL_RWD...")
            self._grant_read_write_delete_access(connection_name, db)
        if needs_c:
            self.console_msg(f"Granting CREATE access to {db}_ALL_C...")
            self._grant_create_access(connection_name, db)

        # --- Step 7: Set up database role hierarchy (only for required levels) ---
        self.console_msg("Setting up database role hierarchy...")
        self._setup_role_hierarchy(connection_name, db, needs_ro, needs_rw, needs_rwd, needs_c)

        # --- Step 8: Grant access per ACCESS_TO_ROLES ---
        self.console_msg("Granting access to roles per ACCESS_TO_ROLES...")
        self._grant_access_to_roles(connection_name, db, access_roles_rows)

        self.console_msg("Access provision completed successfully.")
        self._logger.info(
            f"Access provision completed successfully for database '{db}'"
        )

    @trace
    def _grant_read_only_access(self, connection_name, db):
        """
        Grant read-only access to the <DB>_ALL_R database role on all
        objects and future objects in the database.

        Includes SELECT on tables, external tables, views, dynamic tables,
        materialized views, streams, and REFERENCES on tables, external tables,
        views, materialized views.
        Note: USAGE on sequences, functions, procedures is excluded.
        """
        db_role = f"{db}.{db}_ALL_R"
        grants = [
            f"GRANT USAGE ON DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT USAGE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT USAGE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL EXTERNAL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE EXTERNAL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL DYNAMIC TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE DYNAMIC TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL MATERIALIZED VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE MATERIALIZED VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON ALL EXTERNAL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON FUTURE EXTERNAL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON ALL VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON FUTURE VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON ALL MATERIALIZED VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT REFERENCES ON FUTURE MATERIALIZED VIEWS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON ALL STREAMS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT SELECT ON FUTURE STREAMS IN DATABASE {db} TO DATABASE ROLE {db_role}",
        ]

        self._logger.info(f"Granting READ-ONLY access to database role {db_role}")
        for sql in grants:
            self.execute_sql(connection_name, sql, f"RO grant to {db_role}")

    @trace
    def _grant_read_write_access(self, connection_name, db):
        """
        Grant INSERT and UPDATE access to the <DB>_ALL_RW database role
        on all tables and future tables in the database.
        Note: Views are excluded from INSERT/UPDATE grants.
        """
        db_role = f"{db}.{db}_ALL_RW"
        grants = [
            f"GRANT INSERT ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT INSERT ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT UPDATE ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT UPDATE ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
        ]

        self._logger.info(f"Granting READ-WRITE access to database role {db_role}")
        for sql in grants:
            self.execute_sql(connection_name, sql, f"RW grant to {db_role}")

    @trace
    def _grant_read_write_delete_access(self, connection_name, db):
        """
        Grant DELETE and TRUNCATE access to the <DB>_ALL_RWD database role
        on all tables and future tables in the database.
        Note: Views are excluded from DELETE grants.
        """
        db_role = f"{db}.{db}_ALL_RWD"
        grants = [
            f"GRANT DELETE ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT DELETE ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT TRUNCATE ON ALL TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT TRUNCATE ON FUTURE TABLES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT USAGE ON ALL SEQUENCES IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT USAGE ON FUTURE SEQUENCES IN DATABASE {db} TO DATABASE ROLE {db_role}",
        ]

        self._logger.info(f"Granting READ-WRITE-DELETE access to database role {db_role}")
        for sql in grants:
            self.execute_sql(connection_name, sql, f"RWD grant to {db_role}")

    @trace
    def _grant_create_access(self, connection_name, db):
        """
        Grant CREATE access to the <DB>_ALL_C database role on all
        current schemas and future schemas in the database.

        CREATE privileges granted:
        - DYNAMIC TABLE, FILE FORMAT, FUNCTION, PIPE, PROCEDURE,
          SEQUENCE, STAGE, STREAM, TABLE, TASK, VIEW
        """
        db_role = f"{db}.{db}_ALL_C"
        grants = [
            f"GRANT CREATE SCHEMA ON DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE DYNAMIC TABLE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE DYNAMIC TABLE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE FILE FORMAT ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE FILE FORMAT ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE FUNCTION ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE FUNCTION ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE PIPE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE PIPE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE PROCEDURE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE PROCEDURE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE SEQUENCE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE SEQUENCE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE STAGE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE STAGE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE STREAM ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE STREAM ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE TABLE ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE TABLE ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE TASK ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE TASK ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE VIEW ON ALL SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
            f"GRANT CREATE VIEW ON FUTURE SCHEMAS IN DATABASE {db} TO DATABASE ROLE {db_role}",
        ]

        self._logger.info(f"Granting CREATE access to database role {db_role}")
        for sql in grants:
            self.execute_sql(connection_name, sql, f"CREATE grant to {db_role}")

    @trace
    def _setup_role_hierarchy(self, connection_name, db, needs_ro, needs_rw, needs_rwd, needs_c):
        """
        Set up the database role hierarchy based on required access levels:
        - <DB>_ALL_R -> <DB>_ALL_RW (only if RW needed)
        - <DB>_ALL_RW -> <DB>_ALL_RWD (only if RWD needed)
        - <DB>_ALL_C + <DB>_ALL_RWD -> <DB>_ADMIN (only if C/RWD needed)
        """
        db_role_r = f"{db}.{db}_ALL_R"
        db_role_rw = f"{db}.{db}_ALL_RW"
        db_role_rwd = f"{db}.{db}_ALL_RWD"
        db_role_c = f"{db}.{db}_ALL_C"
        admin_role = f"{db}_ADMIN"

        grants = []

        if needs_rw and needs_ro:
            grants.append(f"GRANT DATABASE ROLE {db_role_r} TO DATABASE ROLE {db_role_rw}")
        if needs_rwd and needs_rw:
            grants.append(f"GRANT DATABASE ROLE {db_role_rw} TO DATABASE ROLE {db_role_rwd}")
        if needs_c:
            grants.append(f"GRANT DATABASE ROLE {db_role_c} TO ROLE {admin_role}")
        if needs_rwd:
            grants.append(f"GRANT DATABASE ROLE {db_role_rwd} TO ROLE {admin_role}")

        if grants:
            self._logger.info(f"Setting up role hierarchy for database '{db}'")
            for sql in grants:
                self.execute_sql(connection_name, sql, f"Role hierarchy for {db}")
        else:
            self._logger.info(f"No role hierarchy needed for database '{db}'")

    @trace
    def _grant_access_to_roles(self, connection_name, db, access_roles_rows):
        """
        Iterate ACCESS_TO_ROLES resultset and grant database role usage
        to the specified roles based on ACCESS_TO_BE_GRANTED value.

        Args:
            connection_name: str - Connection name.
            db: str - Database name (uppercase).
            access_roles_rows: list - Rows from ACCESS_TO_ROLES table
                                      [(ROLE_NAME, ACCESS_TO_BE_GRANTED, DATABASE_TYPE), ...]
        """
        db_role_r = f"{db}.{db}_ALL_R"
        db_role_rw = f"{db}.{db}_ALL_RW"
        db_role_rwd = f"{db}.{db}_ALL_RWD"
        db_role_c = f"{db}.{db}_ALL_C"
        admin_role = f"{db}_ADMIN"

        valid_access_types = {"RO", "RW", "ADMIN", "SRV_RO", "SRV_RWDC", "SRV_RWD", "SRV_RW", "SRV_ADMIN"}

        for row in access_roles_rows:
            role_name = row[0]
            access_type = row[1].upper()

            if access_type not in valid_access_types:
                raise RuntimeError(
                    f"Invalid ACCESS_TO_BE_GRANTED value '{access_type}' for "
                    f"role '{role_name}' in ACCESS_TO_ROLES table. "
                    f"Valid values: {', '.join(sorted(valid_access_types))}. "
                    f"Terminating access provision."
                )

            self._logger.info(
                f"Granting access type '{access_type}' to role '{role_name}'"
            )

            if access_type == "RO":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_r} TO ROLE {role_name}",
                    f"Grant RO ({db_role_r}) to {role_name}",
                )
            elif access_type == "RW":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_rw} TO ROLE {role_name}",
                    f"Grant RW ({db_role_rw}) to {role_name}",
                )
            elif access_type == "ADMIN":
                self.execute_sql(
                    connection_name,
                    f"GRANT ROLE {admin_role} TO ROLE {role_name}",
                    f"Grant ADMIN ({admin_role}) to {role_name}",
                )
            elif access_type == "SRV_RO":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_r} TO ROLE {role_name}",
                    f"Grant SRV_RO ({db_role_r}) to {role_name}",
                )
            elif access_type == "SRV_RWDC":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_rwd} TO ROLE {role_name}",
                    f"Grant SRV_RWDC ({db_role_rwd}) to {role_name}",
                )
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_c} TO ROLE {role_name}",
                    f"Grant SRV_RWDC ({db_role_c}) to {role_name}",
                )
            elif access_type == "SRV_RWD":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_rwd} TO ROLE {role_name}",
                    f"Grant SRV_RWD ({db_role_rwd}) to {role_name}",
                )
            elif access_type == "SRV_RW":
                self.execute_sql(
                    connection_name,
                    f"GRANT DATABASE ROLE {db_role_rw} TO ROLE {role_name}",
                    f"Grant SRV_RW ({db_role_rw}) to {role_name}",
                )
            elif access_type == "SRV_ADMIN":
                self.execute_sql(
                    connection_name,
                    f"GRANT ROLE {admin_role} TO ROLE {role_name}",
                    f"Grant SRV_ADMIN ({admin_role}) to {role_name}",
                )

    @trace
    def create_database_roles(self, connection_name, database_name):
        """
        Create the default database roles for a given database.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='DATABASE_ROLE_CREATION')
        2. Verifies the database exists
        3. Switches to the required role
        4. Switches to the target database
        5. Creates the four standard database roles:
           <DBNAME>_ALL_R, <DBNAME>_ALL_RW, <DBNAME>_ALL_RWD, <DBNAME>_ALL_C

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database to create roles for.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        db = database_name.upper()

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for DATABASE_ROLE_CREATION...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='DATABASE_ROLE_CREATION'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'DATABASE_ROLE_CREATION' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_ROLE_CREATION'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_ROLE_CREATION' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Verify database exists ---
        self._logger.info(f"Verifying database '{db}' exists")
        show_db_sql = f"SHOW DATABASES LIKE '{db}'"
        db_rows = self.execute_sql(
            connection_name, show_db_sql, f"Verify database {db} exists"
        )
        if len(db_rows) == 0:
            raise RuntimeError(
                f"Database '{db}' does not exist on the connected Snowflake "
                f"account. Terminating database role creation."
            )
        self._logger.info(f"Database '{db}' confirmed to exist")

        # --- Step 3: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 4: Switch database ---
        self.console_msg(f"Switching to database: {db}...")
        self._logger.info(f"Switching to database: {db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {db}", f"Switch to database {db}"
        )

        # --- Step 5: Create database roles ---
        db_roles = [
            f"{db}_ALL_R",
            f"{db}_ALL_RW",
            f"{db}_ALL_RWD",
            f"{db}_ALL_C",
        ]

        self.console_msg(f"Creating database roles: {', '.join(db_roles)}...")
        self._logger.info(f"Creating database roles for database '{db}'")
        for role_name in db_roles:
            create_sql = f"CREATE DATABASE ROLE IF NOT EXISTS {db}.{role_name}"
            self.execute_sql(
                connection_name, create_sql, f"Create database role {role_name}"
            )

        self.console_msg("Database roles created successfully.")
        self._logger.info(
            f"Database role creation completed successfully for database '{db}'"
        )

    @trace
    def create_database_account_role(self, connection_name, database_name):
        """
        Create the default account-level role for a given database.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION')
        2. Verifies the database exists
        3. Switches to the required role
        4. Switches to the target database
        5. Creates the account role: <DBNAME>_ADMIN

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database to create the account role for.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        db = database_name.upper()

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for DATABASE_SFACCOUNT_ROLE_CREATION...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'DATABASE_SFACCOUNT_ROLE_CREATION' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Verify database exists ---
        self.console_msg(f"Verifying database '{db}' exists...")
        self._logger.info(f"Verifying database '{db}' exists")
        show_db_sql = f"SHOW DATABASES LIKE '{db}'"
        db_rows = self.execute_sql(
            connection_name, show_db_sql, f"Verify database {db} exists"
        )
        if len(db_rows) == 0:
            raise RuntimeError(
                f"Database '{db}' does not exist on the connected Snowflake "
                f"account. Terminating account role creation."
            )
        self._logger.info(f"Database '{db}' confirmed to exist")

        # --- Step 3: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 4: Switch database ---
        self.console_msg(f"Switching to database: {db}...")
        self._logger.info(f"Switching to database: {db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {db}", f"Switch to database {db}"
        )

        # --- Step 5: Create account role ---
        account_role = f"{db}_ADMIN"
        self.console_msg(f"Creating account role: {account_role}...")
        self._logger.info(f"Creating account role '{account_role}' for database '{db}'")
        create_sql = f"CREATE ROLE IF NOT EXISTS {account_role}"
        self.execute_sql(
            connection_name, create_sql, f"Create account role {account_role}"
        )

        self.console_msg(f"Account role '{account_role}' created successfully.")
        self._logger.info(
            f"Account role creation completed successfully for database '{db}': {account_role}"
        )

    @trace
    def create_database(self, connection_name, database_name, drop_flag, database_type):
        """
        Create a standard database in Snowflake with full role and access setup.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='DB_CREATION')
        2. Switches to the required role
        3. Checks if database exists and handles DROP_FLAG logic
        4. Creates the database
        5. Switches to the newly created database
        6. Calls create_database_roles() to create database roles
        7. Calls create_database_account_role() to create account role
        8. Calls provision_database_access() to set up grants

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database name to create.
            drop_flag: bool - If True, drop and re-create if database exists.
            database_type: str - Type of database (APP_DB or BKP_DB) for access provisioning.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        db = database_name.upper()
        db_type = database_type.upper()

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for DB_CREATION...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='DB_CREATION'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'DB_CREATION' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='DB_CREATION'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='DB_CREATION' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 3: Check if database exists ---
        self.console_msg(f"Checking if database '{db}' exists...")
        self._logger.info(f"Checking if database '{db}' exists")
        show_db_sql = f"SHOW DATABASES LIKE '{db}'"
        db_rows = self.execute_sql(
            connection_name, show_db_sql, f"Check database {db} existence"
        )
        db_exists = len(db_rows) > 0

        # --- Step 4: Handle DROP_FLAG logic and create database ---
        if db_exists and drop_flag:
            self.console_msg(f"Database '{db}' exists. Dropping account role and database...")
            self._logger.info(
                f"Database '{db}' exists and DROP_FLAG is enabled. "
                f"Dropping account role and database, then re-creating."
            )
            # Drop account role before dropping database (while DB still exists)
            self.drop_database_account_role(
                connection_name=connection_name,
                database_name=database_name,
            )
            # Switch back to DB_CREATION role for drop & create operations
            self.console_msg(f"Switching back to role: {role_to_use}...")
            self._logger.info(f"Switching back to role: {role_to_use}")
            self.execute_sql(
                connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
            )
            # Drop the database
            self.console_msg(f"Dropping database '{db}'...")
            self.execute_sql(
                connection_name, f"DROP DATABASE {db}", f"Drop database {db}"
            )
            # Re-create the database
            self.console_msg(f"Creating database '{db}'...")
            self.execute_sql(
                connection_name, f"CREATE DATABASE {db}", f"Create database {db}"
            )
        elif db_exists and not drop_flag:
            raise RuntimeError(
                f"Database '{db}' already exists and DROP_FLAG is not enabled. "
                f"Cannot proceed. Enable DROP_FLAG (YES) to drop and re-create."
            )
        else:
            # Database does not exist — create it regardless of drop_flag
            self.console_msg(f"Creating database '{db}'...")
            self._logger.info(f"Database '{db}' does not exist. Creating.")
            self.execute_sql(
                connection_name, f"CREATE DATABASE {db}", f"Create database {db}"
            )

        self._logger.info(f"Database '{db}' created successfully")

        # --- Step 5: Switch to newly created database ---
        self.console_msg(f"Switching to database: {db}...")
        self._logger.info(f"Switching to database: {db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {db}", f"Switch to database {db}"
        )

        # --- Step 6: Create DBAALL schema and drop PUBLIC schema ---
        self.console_msg("Creating DBAALL schema and dropping PUBLIC schema...")
        self._logger.info(f"Creating schema DBAALL in database '{db}'")
        self.execute_sql(
            connection_name,
            f"CREATE SCHEMA {db}.DBAALL",
            f"Create schema DBAALL in {db}",
        )
        self._logger.info(f"Dropping PUBLIC schema from database '{db}'")
        self.execute_sql(
            connection_name,
            f"DROP SCHEMA {db}.PUBLIC",
            f"Drop PUBLIC schema from {db}",
        )

        # --- Step 7: Create database roles ---
        self.console_msg("Creating database roles...")
        self._logger.info(f"Creating database roles for '{db}'")
        self.create_database_roles(
            connection_name=connection_name,
            database_name=database_name,
        )

        # --- Step 8: Create account role ---
        self.console_msg("Creating account role...")
        self._logger.info(f"Creating account role for '{db}'")
        self.create_database_account_role(
            connection_name=connection_name,
            database_name=database_name,
        )

        # --- Step 9: Provision access ---
        self.console_msg(f"Provisioning access for type '{db_type}'...")
        self._logger.info(f"Provisioning access for '{db}' with type '{db_type}'")
        self.provision_database_access(
            connection_name=connection_name,
            database_name=database_name,
            database_type=db_type,
        )

        self.console_msg(f"Database creation completed successfully for '{db}'.")
        self._logger.info(
            f"Database creation completed successfully for '{db}' "
            f"(roles, account role, and access provisioned)"
        )

    @trace
    def drop_database_account_role(self, connection_name, database_name):
        """
        Drop the default account-level role for a given database.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='DATABASE_SFACCOUNT_ROLE_DROP')
        2. Verifies the database exists
        3. Switches to the required role
        4. Switches to the target database
        5. Drops the account role: <DBNAME>_ADMIN

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database to drop the account role for.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        db = database_name.upper()

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for DATABASE_SFACCOUNT_ROLE_DROP...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='DATABASE_SFACCOUNT_ROLE_DROP'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'DATABASE_SFACCOUNT_ROLE_DROP' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_SFACCOUNT_ROLE_DROP'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_SFACCOUNT_ROLE_DROP' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Verify database exists ---
        self.console_msg(f"Verifying database '{db}' exists...")
        self._logger.info(f"Verifying database '{db}' exists")
        show_db_sql = f"SHOW DATABASES LIKE '{db}'"
        db_rows = self.execute_sql(
            connection_name, show_db_sql, f"Verify database {db} exists"
        )
        if len(db_rows) == 0:
            raise RuntimeError(
                f"Database '{db}' does not exist on the connected Snowflake "
                f"account. Terminating account role drop."
            )
        self._logger.info(f"Database '{db}' confirmed to exist")

        # --- Step 3: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 4: Switch database ---
        self.console_msg(f"Switching to database: {db}...")
        self._logger.info(f"Switching to database: {db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {db}", f"Switch to database {db}"
        )

        # --- Step 5: Drop account role ---
        account_role = f"{db}_ADMIN"
        self.console_msg(f"Dropping account role: {account_role}...")
        self._logger.info(f"Dropping account role '{account_role}' for database '{db}'")
        drop_sql = f"DROP ROLE IF EXISTS {account_role}"
        self.execute_sql(
            connection_name, drop_sql, f"Drop account role {account_role}"
        )

        self.console_msg(f"Account role '{account_role}' dropped successfully.")
        self._logger.info(
            f"Account role drop completed successfully for database '{db}': {account_role}"
        )

    @trace
    def drop_database_roles_by_prefix(self, connection_name, database_name, source_database_name):
        """
        Drop all database roles in a database that match the source database naming pattern.

        Drops roles matching <SOURCE_DB>_ALL_% from the target database.
        This is used after cloning to remove cloned source database roles.

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database containing the roles (target database).
            source_database_name: str - Source database name whose roles should be dropped.

        Raises:
            RuntimeError: On any SQL failure.
        """
        db = database_name.upper()
        source_db = source_database_name.upper()
        role_prefix = f"{source_db}_ALL_"

        self.console_msg(f"Listing database roles in '{db}'...")
        self._logger.info(
            f"Dropping database roles with prefix '{role_prefix}' from database '{db}'"
        )

        # Get all database roles in the target database
        show_roles_sql = f"SHOW DATABASE ROLES IN DATABASE {db}"
        roles_rows = self.execute_sql(
            connection_name, show_roles_sql, f"Show database roles in {db}"
        )

        # Iterate and drop roles matching the source prefix
        self.console_msg(f"Dropping cloned source roles matching '{role_prefix}*'...")
        dropped_count = 0
        for row in roles_rows:
            role_name = row[1] if len(row) > 1 else row[0]
            role_name_upper = str(role_name).upper()
            if role_name_upper.startswith(role_prefix):
                drop_sql = f"DROP DATABASE ROLE {db}.{role_name_upper}"
                self.execute_sql(
                    connection_name, drop_sql, f"Drop cloned database role {role_name_upper}"
                )
                dropped_count += 1

        self.console_msg(f"Dropped {dropped_count} cloned source database role(s).")
        self._logger.info(
            f"Dropped {dropped_count} database roles with prefix '{role_prefix}' from '{db}'"
        )

    @trace
    def transfer_schema_objects_ownership(self, connection_name, database_name, schema_name, target_role="SYSADMIN"):
        """
        Transfer ownership of all objects in a schema to a target role using bulk grants.

        This method is reusable and can be called by other commands that need
        to transfer ownership of schema objects. Uses bulk GRANT OWNERSHIP ON ALL
        statements for efficiency.

        Handles the following object types:
        - Tables
        - Views
        - Materialized Views
        - Procedures
        - Functions
        - Sequences
        - Stages
        - File Formats
        - Streams
        - Tasks
        - Pipes

        Args:
            connection_name: str - Connection name from config.
            database_name: str - Database containing the schema.
            schema_name: str - Schema whose objects' ownership will be transferred.
            target_role: str - Role to transfer ownership to (default: SYSADMIN).

        Raises:
            RuntimeError: On any SQL failure.
        """
        db = database_name.upper()
        schema = schema_name.upper()
        role = target_role.upper()
        fq_schema = f"{db}.{schema}"

        self._logger.info(
            f"Starting bulk ownership transfer for schema '{fq_schema}' to role '{role}'"
        )
        self.console_msg(f"Transferring ownership of all objects in {fq_schema} to {role}...")

        # Object types that support GRANT OWNERSHIP ON ALL ... IN SCHEMA
        # Format: (grant_type_plural, display_name)
        # Note: PIPES excluded - Snowflake restricts bulk ownership grants on pipes
        object_types = [
            ("TABLES", "tables"),
            ("VIEWS", "views"),
            ("MATERIALIZED VIEWS", "materialized views"),
            ("PROCEDURES", "procedures"),
            ("FUNCTIONS", "functions"),
            ("SEQUENCES", "sequences"),
            ("STAGES", "stages"),
            ("FILE FORMATS", "file formats"),
            ("STREAMS", "streams"),
            ("TASKS", "tasks"),
        ]

        for grant_type_plural, display_name in object_types:
            grant_sql = (
                f"GRANT OWNERSHIP ON ALL {grant_type_plural} IN SCHEMA {fq_schema} "
                f"TO ROLE {role} REVOKE CURRENT GRANTS"
            )
            self.console_msg(f"  Transferring all {display_name}...")
            try:
                self.execute_sql(
                    connection_name, grant_sql, f"Transfer all {display_name} ownership to {role}"
                )
                self._logger.info(f"Transferred ownership of all {display_name} in {fq_schema} to {role}")
            except Exception as e:
                # Log but continue - some object types may have no objects or not be supported
                self._logger.info(f"Could not transfer {display_name} (may be empty or unsupported): {str(e)}")

        # Finally, transfer ownership of the schema itself
        self.console_msg(f"Transferring schema ownership to {role}...")
        schema_grant_sql = f"GRANT OWNERSHIP ON SCHEMA {fq_schema} TO ROLE {role} REVOKE CURRENT GRANTS"
        self.execute_sql(
            connection_name, schema_grant_sql, f"Transfer schema {fq_schema} ownership to {role}"
        )

        self.console_msg(f"Bulk ownership transfer complete for schema {fq_schema} to {role}.")
        self._logger.info(
            f"Bulk ownership transfer completed for schema '{fq_schema}' to role '{role}'"
        )

    @trace
    def clone_schema(
        self,
        connection_name,
        source_database,
        source_schema,
        target_database,
        target_schema,
        drop_target,
        database_type,
    ):
        """
        Clone a source schema to a target schema with ownership transfer and access provisioning.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='SCHEMA_CLONE')
        2. Switches to the required role
        3. Validates source database and schema exist
        4. Validates target database exists
        5. Checks target schema existence and handles drop flag logic
        6. Switches to target database
        7. Clones source schema to target
        8. Transfers ownership of all objects to SYSADMIN
        9. Provisions access on target database

        Args:
            connection_name: str - Connection name from config.
            source_database: str - Source database containing the schema to clone.
            source_schema: str - Source schema name.
            target_database: str - Target database for the cloned schema.
            target_schema: str - Target schema name.
            drop_target: bool - If True, drop target schema if it exists.
            database_type: str - Type of database (APP_DB or BKP_DB) for access provisioning.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        src_db = source_database.upper()
        src_schema = source_schema.upper()
        tgt_db = target_database.upper()
        tgt_schema = target_schema.upper()
        db_type = database_type.upper()

        source_fq = f"{src_db}.{src_schema}"
        target_fq = f"{tgt_db}.{tgt_schema}"

        self._logger.info(
            f"Starting schema clone from '{source_fq}' to '{target_fq}', "
            f"drop_target={drop_target}, db_type={db_type}"
        )

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for SCHEMA_CLONE...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='SCHEMA_CLONE'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'SCHEMA_CLONE' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(task_map_sql, "Read TASK_TO_ROLE_MAP")

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='SCHEMA_CLONE', CONNECTION_NAME='{connection_name}'. "
                f"Cannot proceed without role configuration."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='SCHEMA_CLONE', CONNECTION_NAME='{connection_name}'. "
                f"Expected exactly one active record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")
        self.console_msg(f"Role to be used: {role_to_use}")

        # --- Step 2: Switch to role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 3: Validate source database exists ---
        self.console_msg(f"Validating source database '{src_db}' exists...")
        self._logger.info(f"Validating source database '{src_db}' exists")
        show_src_db_sql = f"SHOW DATABASES LIKE '{src_db}'"
        src_db_rows = self.execute_sql(
            connection_name, show_src_db_sql, f"Verify source database {src_db} exists"
        )
        if len(src_db_rows) == 0:
            raise RuntimeError(
                f"Source database '{src_db}' does not exist. Terminating schema clone."
            )

        # --- Step 4: Validate source schema exists ---
        self.console_msg(f"Validating source schema '{src_schema}' exists...")
        self._logger.info(f"Validating source schema '{src_schema}' in database '{src_db}'")
        show_src_schema_sql = f"SHOW SCHEMAS LIKE '{src_schema}' IN DATABASE {src_db}"
        src_schema_rows = self.execute_sql(
            connection_name, show_src_schema_sql, f"Verify source schema {src_schema} exists"
        )
        if len(src_schema_rows) == 0:
            raise RuntimeError(
                f"Source schema '{source_fq}' does not exist. Terminating schema clone."
            )
        self._logger.info(f"Source schema '{source_fq}' confirmed to exist")

        # --- Step 5: Validate target database exists ---
        self.console_msg(f"Validating target database '{tgt_db}' exists...")
        self._logger.info(f"Validating target database '{tgt_db}' exists")
        show_tgt_db_sql = f"SHOW DATABASES LIKE '{tgt_db}'"
        tgt_db_rows = self.execute_sql(
            connection_name, show_tgt_db_sql, f"Verify target database {tgt_db} exists"
        )
        if len(tgt_db_rows) == 0:
            raise RuntimeError(
                f"Target database '{tgt_db}' does not exist. Terminating schema clone."
            )

        # --- Step 6: Check target schema existence ---
        self.console_msg(f"Checking if target schema '{tgt_schema}' exists...")
        self._logger.info(f"Checking if target schema '{tgt_schema}' exists in database '{tgt_db}'")
        show_tgt_schema_sql = f"SHOW SCHEMAS LIKE '{tgt_schema}' IN DATABASE {tgt_db}"
        tgt_schema_rows = self.execute_sql(
            connection_name, show_tgt_schema_sql, f"Check target schema {tgt_schema} existence"
        )
        target_schema_exists = len(tgt_schema_rows) > 0

        # --- Step 7: Switch to target database ---
        self.console_msg(f"Switching to target database: {tgt_db}...")
        self._logger.info(f"Switching to target database: {tgt_db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {tgt_db}", f"Switch to database {tgt_db}"
        )

        # --- Step 8: Handle drop target flag logic ---
        if target_schema_exists and drop_target:
            self.console_msg(f"Target schema '{tgt_schema}' exists. Dropping it...")
            self._logger.info(
                f"Target schema '{target_fq}' exists and DROP_TARGET is enabled. Dropping."
            )
            drop_schema_sql = f"DROP SCHEMA {tgt_db}.{tgt_schema}"
            self.execute_sql(
                connection_name, drop_schema_sql, f"Drop target schema {target_fq}"
            )
            self._logger.info(f"Target schema '{target_fq}' dropped successfully")
        elif target_schema_exists and not drop_target:
            raise RuntimeError(
                f"Target schema '{target_fq}' already exists and DROP_TARGET flag is not enabled. "
                f"Cannot proceed. Set --drop-target YES to drop and re-create."
            )
        else:
            self.console_msg(f"Target schema '{tgt_schema}' does not exist. Proceeding...")
            self._logger.info(
                f"Target schema '{target_fq}' does not exist. Proceeding with clone."
            )

        # --- Step 9: Clone schema ---
        self.console_msg(f"Cloning schema '{source_fq}' to '{target_fq}'...")
        self._logger.info(f"Cloning schema '{source_fq}' to '{target_fq}'")
        clone_sql = f"CREATE SCHEMA {tgt_db}.{tgt_schema} CLONE {src_db}.{src_schema}"
        self.execute_sql(
            connection_name, clone_sql, f"Clone schema {source_fq} to {target_fq}"
        )
        self._logger.info(f"Schema clone completed: {source_fq} -> {target_fq}")

        # --- Step 10: Transfer ownership to SYSADMIN ---
        self.console_msg("Transferring ownership of schema objects to SYSADMIN...")
        self._logger.info(f"Transferring ownership of '{target_fq}' objects to SYSADMIN")
        self.transfer_schema_objects_ownership(
            connection_name=connection_name,
            database_name=tgt_db,
            schema_name=tgt_schema,
            target_role="SYSADMIN",
        )

        # --- Step 11: Provision access ---
        self.console_msg(f"Provisioning access on target database '{tgt_db}' with type '{db_type}'...")
        self._logger.info(f"Provisioning access for '{tgt_db}' with type '{db_type}'")
        self.provision_database_access(
            connection_name=connection_name,
            database_name=tgt_db,
            database_type=db_type,
        )

        self.console_msg(f"Schema clone completed successfully: {source_fq} -> {target_fq}.")
        self._logger.info(
            f"Schema clone completed successfully: {source_fq} -> {target_fq} "
            f"(ownership transferred to SYSADMIN, access provisioned)"
        )

    @trace
    def clone_database(self, connection_name, source_database, target_database, drop_flag, database_type):
        """
        Clone a source database to a target database with full role and access setup.

        This method:
        1. Reads TASK_TO_ROLE_MAP for the role to use (TASK_TYPE='DATABASE_CLONE')
        2. Switches to the required role
        3. Verifies source database exists
        4. Checks target database existence and handles drop flag logic
        5. Clones source to target
        6. Switches to target database
        7. Drops cloned source database roles from target
        8. Creates fresh database roles on target
        9. Creates account role on target
        10. Provisions access on target

        Args:
            connection_name: str - Connection name from config.
            source_database: str - Source database to clone from.
            target_database: str - Target database name.
            drop_flag: bool - If True, drop target if it exists.
            database_type: str - Type of database (APP_DB or BKP_DB) for access provisioning.

        Raises:
            RuntimeError: On any SQL failure or validation error.
        """
        source_db = source_database.upper()
        target_db = target_database.upper()
        db_type = database_type.upper()

        # --- Validation: Source and target cannot be the same ---
        if source_db == target_db:
            raise RuntimeError(
                f"Source and target database names are the same ('{source_db}'). "
                f"Cannot clone a database to itself."
            )

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for DATABASE_CLONE...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='DATABASE_CLONE'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'DATABASE_CLONE' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(
            task_map_sql, "Read TASK_TO_ROLE_MAP"
        )

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_CLONE'. Cannot proceed."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='DATABASE_CLONE' AND STATUS='ACTIVE'. "
                f"Expected exactly one record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")

        # --- Step 2: Switch role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 3: Verify source database exists ---
        self.console_msg(f"Verifying source database '{source_db}' exists...")
        self._logger.info(f"Verifying source database '{source_db}' exists")
        show_src_sql = f"SHOW DATABASES LIKE '{source_db}'"
        src_rows = self.execute_sql(
            connection_name, show_src_sql, f"Verify source database {source_db} exists"
        )
        if len(src_rows) == 0:
            raise RuntimeError(
                f"Source database '{source_db}' does not exist on the connected "
                f"Snowflake account. Cannot proceed with clone."
            )
        self._logger.info(f"Source database '{source_db}' confirmed to exist")

        # --- Step 4: Check target database existence ---
        self.console_msg(f"Checking if target database '{target_db}' exists...")
        self._logger.info(f"Checking if target database '{target_db}' exists")
        show_tgt_sql = f"SHOW DATABASES LIKE '{target_db}'"
        tgt_rows = self.execute_sql(
            connection_name, show_tgt_sql, f"Check target database {target_db} existence"
        )
        target_exists = len(tgt_rows) > 0

        # --- Step 5: Handle drop target flag logic ---
        if target_exists and drop_flag:
            self.console_msg(f"Target '{target_db}' exists. Dropping account role and database...")
            self._logger.info(
                f"Target database '{target_db}' exists and DROP_FLAG is enabled. "
                f"Dropping account role and target database."
            )
            self.drop_database_account_role(
                connection_name=connection_name,
                database_name=target_database,
            )
            self.console_msg(f"Switching back to role: {role_to_use}...")
            self._logger.info(f"Switching back to role: {role_to_use}")
            self.execute_sql(
                connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
            )
            self.console_msg(f"Dropping target database '{target_db}'...")
            self.execute_sql(
                connection_name, f"DROP DATABASE {target_db}", f"Drop target database {target_db}"
            )
        elif target_exists and not drop_flag:
            raise RuntimeError(
                f"Target database '{target_db}' already exists and DROP_FLAG is not enabled. "
                f"Cannot proceed. Enable DROP_FLAG (YES) to drop and re-create."
            )
        else:
            self.console_msg(f"Target database '{target_db}' does not exist. Proceeding...")
            self._logger.info(
                f"Target database '{target_db}' does not exist. Proceeding with clone."
            )

        # --- Step 6: Clone database ---
        self.console_msg(f"Cloning '{source_db}' to '{target_db}'...")
        self._logger.info(f"Cloning database '{source_db}' to '{target_db}'")
        clone_sql = f"CREATE DATABASE {target_db} CLONE {source_db}"
        self.execute_sql(
            connection_name, clone_sql, f"Clone {source_db} to {target_db}"
        )
        self._logger.info(f"Database clone completed: {source_db} -> {target_db}")

        # --- Step 7: Switch to target database ---
        self.console_msg(f"Switching to target database: {target_db}...")
        self._logger.info(f"Switching to target database: {target_db}")
        self.execute_sql(
            connection_name, f"USE DATABASE {target_db}", f"Switch to database {target_db}"
        )

        # --- Step 8: Drop cloned source database roles ---
        self.console_msg("Dropping cloned source database roles...")
        self._logger.info(
            f"Dropping cloned source database roles (prefix '{source_db}_ALL_') from '{target_db}'"
        )
        self.drop_database_roles_by_prefix(
            connection_name=connection_name,
            database_name=target_database,
            source_database_name=source_database,
        )

        # --- Step 9: Create database roles for target ---
        self.console_msg("Creating database roles for target...")
        self._logger.info(f"Creating database roles for '{target_db}'")
        self.create_database_roles(
            connection_name=connection_name,
            database_name=target_database,
        )

        # --- Step 10: Create account role for target ---
        self.console_msg("Creating account role for target...")
        self._logger.info(f"Creating account role for '{target_db}'")
        self.create_database_account_role(
            connection_name=connection_name,
            database_name=target_database,
        )

        # --- Step 11: Provision access for target ---
        self.console_msg(f"Provisioning access for type '{db_type}'...")
        self._logger.info(f"Provisioning access for '{target_db}' with type '{db_type}'")
        self.provision_database_access(
            connection_name=connection_name,
            database_name=target_database,
            database_type=db_type,
        )

        self.console_msg(f"Database clone completed successfully: {source_db} -> {target_db}.")
        self._logger.info(
            f"Database clone completed successfully: {source_db} -> {target_db} "
            f"(roles, account role, and access provisioned)"
        )

    @trace
    def insert_data_by_column_match(
        self,
        connection_name,
        source_database,
        source_schema,
        source_table,
        target_database,
        target_schema,
        target_table,
        truncate_target,
        source_filter=None,
    ):
        """
        Insert data from source table to target table by matching column names.

        Handles column mapping between source and target tables:
        - Matching columns are copied directly
        - Extra target columns with defaults use DEFAULT
        - Extra target columns that are nullable use NULL
        - Extra target columns that are NOT NULL without defaults cause an error

        Args:
            connection_name: str - Connection name from config.
            source_database: str - Source database name.
            source_schema: str - Source schema name.
            source_table: str - Source table name.
            target_database: str - Target database name.
            target_schema: str - Target schema name.
            target_table: str - Target table name.
            truncate_target: bool - If True, uses INSERT OVERWRITE; otherwise plain INSERT.
            source_filter: str or None - Optional WHERE clause filter for source table.

        Raises:
            RuntimeError: On validation failures or SQL execution errors.
        """
        # Build fully qualified names
        source_fqn = f"{source_database}.{source_schema}.{source_table}"
        target_fqn = f"{target_database}.{target_schema}.{target_table}"

        self._logger.info(
            f"Starting insert_data_by_column_match: {source_fqn} -> {target_fqn}, "
            f"truncate={truncate_target}, filter={source_filter}"
        )

        # --- Step 1: Read TASK_TO_ROLE_MAP ---
        self.console_msg("Reading TASK_TO_ROLE_MAP for INSERT_DATA_BY_COLUMN_MATCH...")
        meta_cfg = self._config.get("metadata", {})
        meta_db = meta_cfg.get("database", "")
        meta_schema = meta_cfg.get("schema", "")
        fq_task_map = f"{meta_db}.{meta_schema}.TASK_TO_ROLE_MAP"

        self._logger.info(f"Reading {fq_task_map} for TASK_TYPE='INSERT_DATA_BY_COLUMN_MATCH'")
        task_map_sql = (
            f"SELECT TASK_TYPE, ROLE_TO_BE_USED, STATUS "
            f"FROM {fq_task_map} "
            f"WHERE TASK_TYPE = 'INSERT_DATA_BY_COLUMN_MATCH' AND STATUS = 'ACTIVE' "
            f"AND CONNECTION_NAME = '{connection_name}'"
        )
        task_map_rows = self.execute_metadata_sql(task_map_sql, "Read TASK_TO_ROLE_MAP")

        if len(task_map_rows) == 0:
            raise RuntimeError(
                f"No active record found in {fq_task_map} for "
                f"TASK_TYPE='INSERT_DATA_BY_COLUMN_MATCH', CONNECTION_NAME='{connection_name}'. "
                f"Cannot proceed without role configuration."
            )
        if len(task_map_rows) > 1:
            raise RuntimeError(
                f"Multiple records found in {fq_task_map} for "
                f"TASK_TYPE='INSERT_DATA_BY_COLUMN_MATCH', CONNECTION_NAME='{connection_name}'. "
                f"Expected exactly one active record."
            )

        role_to_use = task_map_rows[0][1]
        self._logger.info(f"ROLE_TO_BE_USED from TASK_TO_ROLE_MAP: {role_to_use}")
        self.console_msg(f"Role to be used: {role_to_use}")

        # --- Step 2: Switch to role ---
        self.console_msg(f"Switching to role: {role_to_use}...")
        self._logger.info(f"Switching to role: {role_to_use}")
        self.execute_sql(
            connection_name, f"USE ROLE {role_to_use}", f"Switch to role {role_to_use}"
        )

        # --- Step 3: Validate source objects exist ---
        self.console_msg(f"Validating source database '{source_database}' exists...")
        self._logger.info(f"Validating source database '{source_database}' exists")
        show_src_db_sql = f"SHOW DATABASES LIKE '{source_database}'"
        src_db_rows = self.execute_sql(
            connection_name, show_src_db_sql, f"Verify source database {source_database} exists"
        )
        if len(src_db_rows) == 0:
            raise RuntimeError(
                f"Source database '{source_database}' does not exist. Terminating."
            )

        self.console_msg(f"Validating source schema '{source_schema}' exists...")
        self._logger.info(f"Validating source schema '{source_schema}' exists")
        show_src_schema_sql = f"SHOW SCHEMAS LIKE '{source_schema}' IN DATABASE {source_database}"
        src_schema_rows = self.execute_sql(
            connection_name, show_src_schema_sql, f"Verify source schema {source_schema} exists"
        )
        if len(src_schema_rows) == 0:
            raise RuntimeError(
                f"Source schema '{source_database}.{source_schema}' does not exist. Terminating."
            )

        self.console_msg(f"Validating source table '{source_table}' exists...")
        self._logger.info(f"Validating source table '{source_table}' exists")
        show_src_table_sql = f"SHOW TABLES LIKE '{source_table}' IN {source_database}.{source_schema}"
        src_table_rows = self.execute_sql(
            connection_name, show_src_table_sql, f"Verify source table {source_table} exists"
        )
        if len(src_table_rows) == 0:
            raise RuntimeError(
                f"Source table '{source_fqn}' does not exist. Terminating."
            )
        self._logger.info(f"Source objects validated: {source_fqn}")

        # --- Step 4: Validate target objects exist ---
        self.console_msg(f"Validating target database '{target_database}' exists...")
        self._logger.info(f"Validating target database '{target_database}' exists")
        show_tgt_db_sql = f"SHOW DATABASES LIKE '{target_database}'"
        tgt_db_rows = self.execute_sql(
            connection_name, show_tgt_db_sql, f"Verify target database {target_database} exists"
        )
        if len(tgt_db_rows) == 0:
            raise RuntimeError(
                f"Target database '{target_database}' does not exist. Terminating."
            )

        self.console_msg(f"Validating target schema '{target_schema}' exists...")
        self._logger.info(f"Validating target schema '{target_schema}' exists")
        show_tgt_schema_sql = f"SHOW SCHEMAS LIKE '{target_schema}' IN DATABASE {target_database}"
        tgt_schema_rows = self.execute_sql(
            connection_name, show_tgt_schema_sql, f"Verify target schema {target_schema} exists"
        )
        if len(tgt_schema_rows) == 0:
            raise RuntimeError(
                f"Target schema '{target_database}.{target_schema}' does not exist. Terminating."
            )

        self.console_msg(f"Validating target table '{target_table}' exists...")
        self._logger.info(f"Validating target table '{target_table}' exists")
        show_tgt_table_sql = f"SHOW TABLES LIKE '{target_table}' IN {target_database}.{target_schema}"
        tgt_table_rows = self.execute_sql(
            connection_name, show_tgt_table_sql, f"Verify target table {target_table} exists"
        )
        if len(tgt_table_rows) == 0:
            raise RuntimeError(
                f"Target table '{target_fqn}' does not exist. Terminating."
            )
        self._logger.info(f"Target objects validated: {target_fqn}")

        # --- Step 5: Switch to target database ---
        self.console_msg(f"Switching to target database: {target_database}...")
        self._logger.info(f"Switching to target database: {target_database}")
        self.execute_sql(
            connection_name, f"USE DATABASE {target_database}", f"Switch to database {target_database}"
        )

        # --- Step 6: Get pre-insert row counts ---
        self.console_msg("Getting pre-insert row counts...")

        # Source total count
        src_total_sql = f"SELECT COUNT(*) FROM {source_fqn}"
        src_total_rows = self.execute_sql(connection_name, src_total_sql, "Source total row count")
        src_total_count = src_total_rows[0][0] if src_total_rows else 0
        self.console_msg(f"Source table total row count: {src_total_count}")
        self._logger.info(f"Source table '{source_fqn}' total row count: {src_total_count}")

        # Source filtered count (if filter provided)
        src_filtered_count = src_total_count
        if source_filter:
            src_filtered_sql = f"SELECT COUNT(*) FROM {source_fqn} WHERE {source_filter}"
            src_filtered_rows = self.execute_sql(connection_name, src_filtered_sql, "Source filtered row count")
            src_filtered_count = src_filtered_rows[0][0] if src_filtered_rows else 0
            self.console_msg(f"Source table row count with filter [{source_filter}]: {src_filtered_count}")
            self._logger.info(f"Source table '{source_fqn}' filtered row count: {src_filtered_count}")

        # Target total count
        tgt_total_sql = f"SELECT COUNT(*) FROM {target_fqn}"
        tgt_total_rows = self.execute_sql(connection_name, tgt_total_sql, "Target total row count")
        tgt_total_count = tgt_total_rows[0][0] if tgt_total_rows else 0
        tgt_pre_insert_count = tgt_total_count
        self.console_msg(f"Target table total row count (pre-insert): {tgt_total_count}")
        self._logger.info(f"Target table '{target_fqn}' total row count (pre-insert): {tgt_total_count}")

        # Target filtered count (if filter provided)
        tgt_filtered_count = tgt_total_count
        if source_filter:
            tgt_filtered_sql = f"SELECT COUNT(*) FROM {target_fqn} WHERE {source_filter}"
            tgt_filtered_rows = self.execute_sql(connection_name, tgt_filtered_sql, "Target filtered row count")
            tgt_filtered_count = tgt_filtered_rows[0][0] if tgt_filtered_rows else 0
            self.console_msg(f"Target table row count with filter [{source_filter}]: {tgt_filtered_count}")
            self._logger.info(f"Target table '{target_fqn}' filtered row count: {tgt_filtered_count}")

        # --- Step 7: Validate source has data ---
        if src_filtered_count == 0:
            self.console_msg("Source table has no records to copy (row count is 0). Exiting successfully.")
            self._logger.info(
                f"Source table '{source_fqn}' has no records to copy "
                f"(filter: {source_filter if source_filter else 'none'}). Exiting successfully."
            )
            return  # Successful exit - nothing to copy

        self.console_msg(f"Source has {src_filtered_count} record(s) to copy.")

        # --- Step 8: Validate target state vs truncate flag ---
        target_has_data = tgt_filtered_count > 0 if source_filter else tgt_total_count > 0
        if target_has_data and not truncate_target:
            raise RuntimeError(
                f"Target table '{target_fqn}' has existing data "
                f"({'filtered count: ' + str(tgt_filtered_count) if source_filter else 'total count: ' + str(tgt_total_count)}) "
                f"but truncate flag is not enabled. "
                f"Set --truncate-target YES to overwrite existing data or ensure target is empty."
            )

        # --- Step 9: Get column metadata ---
        self.console_msg("Retrieving column metadata from source and target tables...")

        # Source columns via DESCRIBE
        desc_src_sql = f"DESCRIBE TABLE {source_fqn}"
        src_col_rows = self.execute_sql(connection_name, desc_src_sql, "Describe source table")
        # DESCRIBE returns: name, type, kind, null?, default, primary key, unique key, check, expression, comment, policy name, privacy domain
        source_columns = {}
        for row in src_col_rows:
            col_name = row[0].upper()  # Column name (uppercase for matching)
            source_columns[col_name] = {
                "name": row[0],
                "type": row[1],
                "nullable": row[3] == "Y" if len(row) > 3 else True,
                "default": row[4] if len(row) > 4 else None,
            }
        self._logger.info(f"Source table has {len(source_columns)} columns: {list(source_columns.keys())}")

        # Target columns via DESCRIBE
        desc_tgt_sql = f"DESCRIBE TABLE {target_fqn}"
        tgt_col_rows = self.execute_sql(connection_name, desc_tgt_sql, "Describe target table")
        target_columns = []
        for row in tgt_col_rows:
            col_name = row[0].upper()
            col_info = {
                "name": row[0],
                "name_upper": col_name,
                "type": row[1],
                "nullable": row[3] == "Y" if len(row) > 3 else True,
                "default": row[4] if len(row) > 4 else None,
            }
            target_columns.append(col_info)
        self._logger.info(f"Target table has {len(target_columns)} columns: {[c['name'] for c in target_columns]}")

        # --- Step 10: Match columns and build INSERT statement ---
        self.console_msg("Matching columns between source and target tables...")

        insert_cols = []  # Column names for INSERT INTO (...)
        select_exprs = []  # Expressions for SELECT (column or DEFAULT or NULL)

        for tgt_col in target_columns:
            col_name = tgt_col["name"]
            col_name_upper = tgt_col["name_upper"]
            is_nullable = tgt_col["nullable"]
            has_default = tgt_col["default"] is not None and tgt_col["default"] != ""

            if col_name_upper in source_columns:
                # Column exists in source - use it directly
                insert_cols.append(col_name)
                select_exprs.append(f'"{source_columns[col_name_upper]["name"]}"')
                self._logger.info(f"Column '{col_name}': matched from source")
            elif has_default:
                # Column has a default value - use DEFAULT
                insert_cols.append(col_name)
                select_exprs.append("DEFAULT")
                self._logger.info(f"Column '{col_name}': using DEFAULT (not in source)")
            elif is_nullable:
                # Column is nullable - use NULL
                insert_cols.append(col_name)
                select_exprs.append("NULL")
                self._logger.info(f"Column '{col_name}': using NULL (not in source, nullable)")
            else:
                # Column is NOT NULL without default and not in source - ERROR
                raise RuntimeError(
                    f"Target column '{col_name}' is NOT NULL, has no default value, "
                    f"and does not exist in source table '{source_fqn}'. "
                    f"Cannot proceed with insert."
                )

        # Build column lists
        insert_col_list = ", ".join([f'"{c}"' for c in insert_cols])
        select_expr_list = ", ".join(select_exprs)

        self.console_msg(f"Column mapping complete: {len(insert_cols)} columns will be inserted.")
        self._logger.info(f"INSERT columns: {insert_cols}")
        self._logger.info(f"SELECT expressions: {select_exprs}")

        # --- Step 11: Generate INSERT SQL ---
        if truncate_target:
            insert_keyword = "INSERT OVERWRITE INTO"
            self.console_msg("Using INSERT OVERWRITE (truncate mode enabled)...")
        else:
            insert_keyword = "INSERT INTO"
            self.console_msg("Using plain INSERT...")

        # Build the source SELECT with optional filter
        if source_filter:
            select_clause = f"SELECT {select_expr_list} FROM {source_fqn} WHERE {source_filter}"
        else:
            select_clause = f"SELECT {select_expr_list} FROM {source_fqn}"

        insert_sql = f"{insert_keyword} {target_fqn} ({insert_col_list}) {select_clause}"

        self._logger.info(f"Generated INSERT SQL: {insert_sql}")

        # --- Step 12: Execute INSERT ---
        self.console_msg("Executing INSERT statement...")
        self.execute_sql(connection_name, insert_sql, "Insert data by column match")
        self.console_msg("INSERT statement executed successfully.")

        # --- Step 13: Get post-insert row counts ---
        self.console_msg("Getting post-insert row counts...")

        # Source total count (should be unchanged)
        src_post_total_sql = f"SELECT COUNT(*) FROM {source_fqn}"
        src_post_total_rows = self.execute_sql(connection_name, src_post_total_sql, "Source post-insert total count")
        src_post_total_count = src_post_total_rows[0][0] if src_post_total_rows else 0
        self.console_msg(f"Source table total row count (post-insert): {src_post_total_count}")
        self._logger.info(f"Source table '{source_fqn}' total row count (post-insert): {src_post_total_count}")

        # Source filtered count (if filter)
        src_post_filtered_count = src_post_total_count
        if source_filter:
            src_post_filtered_sql = f"SELECT COUNT(*) FROM {source_fqn} WHERE {source_filter}"
            src_post_filtered_rows = self.execute_sql(connection_name, src_post_filtered_sql, "Source post-insert filtered count")
            src_post_filtered_count = src_post_filtered_rows[0][0] if src_post_filtered_rows else 0
            self.console_msg(f"Source table row count with filter [{source_filter}] (post-insert): {src_post_filtered_count}")
            self._logger.info(f"Source table '{source_fqn}' filtered row count (post-insert): {src_post_filtered_count}")

        # Target total count
        tgt_post_total_sql = f"SELECT COUNT(*) FROM {target_fqn}"
        tgt_post_total_rows = self.execute_sql(connection_name, tgt_post_total_sql, "Target post-insert total count")
        tgt_post_total_count = tgt_post_total_rows[0][0] if tgt_post_total_rows else 0
        self.console_msg(f"Target table total row count (post-insert): {tgt_post_total_count}")
        self._logger.info(f"Target table '{target_fqn}' total row count (post-insert): {tgt_post_total_count}")

        # Target filtered count (if filter)
        tgt_post_filtered_count = tgt_post_total_count
        if source_filter:
            tgt_post_filtered_sql = f"SELECT COUNT(*) FROM {target_fqn} WHERE {source_filter}"
            tgt_post_filtered_rows = self.execute_sql(connection_name, tgt_post_filtered_sql, "Target post-insert filtered count")
            tgt_post_filtered_count = tgt_post_filtered_rows[0][0] if tgt_post_filtered_rows else 0
            self.console_msg(f"Target table row count with filter [{source_filter}] (post-insert): {tgt_post_filtered_count}")
            self._logger.info(f"Target table '{target_fqn}' filtered row count (post-insert): {tgt_post_filtered_count}")

        # --- Step 14: Verify row counts ---
        self.console_msg("Verifying row counts...")

        # Calculate rows inserted
        if truncate_target:
            rows_inserted = tgt_post_total_count
            self.console_msg(f"Rows inserted (INSERT OVERWRITE): {rows_inserted}")
        else:
            rows_inserted = tgt_post_total_count - tgt_pre_insert_count
            self.console_msg(f"Rows inserted: {rows_inserted}")

        self._logger.info(f"Rows inserted: {rows_inserted}")

        # Compare source vs target counts
        if source_filter:
            # Compare filtered counts
            if src_post_filtered_count == tgt_post_filtered_count:
                self.console_msg(
                    f"SUCCESS: Row counts match! Source filtered: {src_post_filtered_count}, "
                    f"Target filtered: {tgt_post_filtered_count}"
                )
                self._logger.info(
                    f"Row count verification PASSED (filtered): Source={src_post_filtered_count}, "
                    f"Target={tgt_post_filtered_count}"
                )
            else:
                self.console_msg(
                    f"WARNING: Row count mismatch! Source filtered: {src_post_filtered_count}, "
                    f"Target filtered: {tgt_post_filtered_count}"
                )
                self._logger.warn(
                    f"Row count verification MISMATCH (filtered): Source={src_post_filtered_count}, "
                    f"Target={tgt_post_filtered_count}"
                )
        else:
            # Compare total counts (when no filter or for general verification)
            if truncate_target:
                # For INSERT OVERWRITE, target should equal source
                if src_post_total_count == tgt_post_total_count:
                    self.console_msg(
                        f"SUCCESS: Row counts match! Source: {src_post_total_count}, "
                        f"Target: {tgt_post_total_count}"
                    )
                    self._logger.info(
                        f"Row count verification PASSED: Source={src_post_total_count}, "
                        f"Target={tgt_post_total_count}"
                    )
                else:
                    self.console_msg(
                        f"WARNING: Row count mismatch! Source: {src_post_total_count}, "
                        f"Target: {tgt_post_total_count}"
                    )
                    self._logger.warn(
                        f"Row count verification MISMATCH: Source={src_post_total_count}, "
                        f"Target={tgt_post_total_count}"
                    )
            else:
                # For plain INSERT, verify rows_inserted matches source count
                if rows_inserted == src_filtered_count:
                    self.console_msg(
                        f"SUCCESS: Rows inserted ({rows_inserted}) matches source count ({src_filtered_count})."
                    )
                    self._logger.info(
                        f"Row count verification PASSED: Inserted={rows_inserted}, Source={src_filtered_count}"
                    )
                else:
                    self.console_msg(
                        f"WARNING: Rows inserted ({rows_inserted}) does not match source count ({src_filtered_count})."
                    )
                    self._logger.warn(
                        f"Row count verification MISMATCH: Inserted={rows_inserted}, Source={src_filtered_count}"
                    )

        self.console_msg("Insert data by column match completed successfully.")
        self._logger.info(
            f"insert_data_by_column_match completed: {source_fqn} -> {target_fqn}, "
            f"rows_inserted={rows_inserted}"
        )

    @trace
    def shutdown(self):
        """
        Gracefully shut down the engine: close all connections and flush logs.
        """
        self._logger.info("Engine shutting down...")

        # Close all cached connections
        for name, conn in list(self._connections.items()):
            close_connection(conn, name)

        self._connections.clear()
        self._logger.info("Engine shutdown complete")


# =============================================================================
# Command Script Helper
# =============================================================================

def create_engine_from_args(args):
    """
    Helper function for command scripts to create and initialize an engine
    from parsed argparse arguments.

    Args:
        args: argparse.Namespace - Parsed arguments (expects args.connection).

    Returns:
        tuple: (Engine instance, connection_name)
    """
    engine = Engine()
    engine.initialize()

    connection_name = getattr(args, "connection", None)
    if connection_name:
        validate_connection_name(engine.config, connection_name)

    # Set pipeline ID if provided (optional, for CI/CD pipeline tracking)
    pipeline_id = getattr(args, "pipeline_id", None)
    if pipeline_id:
        engine.set_pipeline_id(pipeline_id)

    return engine, connection_name
