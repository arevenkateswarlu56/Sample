"""
Snowflake DBA Tasks Automation - Connection Manager

Provides factory-based Snowflake connection management supporting:
- PAT (Programmatic Access Token) authentication
- Key Pair (RSA) authentication
- OAuth (Client Credentials) authentication

Usage:
    from core.connection import get_connection
    conn = get_connection(config, "prod_main")
    cursor = conn.cursor()
"""

import os
import re

from core.logger import get_logger


# =============================================================================
# Environment Variable Substitution
# =============================================================================

ENV_VAR_PATTERN = re.compile(r"\$\{([^}]+)\}")


def resolve_env_vars(value):
    """
    Replace ${ENV_VAR_NAME} patterns in a string with environment variable values.

    Args:
        value: String that may contain ${ENV_VAR} references.

    Returns:
        String with environment variables resolved.

    Raises:
        ValueError: If referenced environment variable is not set.
    """
    if not isinstance(value, str):
        return value

    def replacer(match):
        env_name = match.group(1)
        env_value = os.environ.get(env_name)
        if env_value is None:
            raise ValueError(
                f"Environment variable '{env_name}' is not set. "
                f"Required by configuration."
            )
        return env_value

    return ENV_VAR_PATTERN.sub(replacer, value)


# =============================================================================
# Connection Factory
# =============================================================================

def get_connection(config, connection_name):
    """
    Create and return a Snowflake connection based on the named configuration.

    Args:
        config: dict - Full configuration dictionary with 'connections' section.
        connection_name: str - Name of the connection entry in config.

    Returns:
        snowflake.connector.SnowflakeConnection

    Raises:
        ValueError: If connection name not found or auth method unsupported.
        ConnectionError: If connection to Snowflake fails.
    """
    logger = get_logger()

    # Validate connection exists in config
    connections = config.get("connections", {})
    if connection_name not in connections:
        available = ", ".join(connections.keys())
        raise ValueError(
            f"Connection '{connection_name}' not found in configuration. "
            f"Available connections: {available}"
        )

    conn_cfg = connections[connection_name]
    auth_method = conn_cfg.get("auth_method", "").lower()

    logger.info(
        f"Establishing connection '{connection_name}' using auth method: {auth_method}"
    )

    # Base connection parameters (common to all auth methods)
    base_params = {
        "account": resolve_env_vars(conn_cfg.get("account", "")),
        "user": resolve_env_vars(conn_cfg.get("user", "")),
        "role": resolve_env_vars(conn_cfg.get("role", "")),
        "warehouse": resolve_env_vars(conn_cfg.get("warehouse", "")),
        "database": resolve_env_vars(conn_cfg.get("database", "")),
        "schema": resolve_env_vars(conn_cfg.get("schema", "")),
    }

    # Dispatch to auth-specific connection
    if auth_method == "pat":
        return _connect_pat(base_params, conn_cfg, connection_name)
    elif auth_method == "key_pair":
        return _connect_key_pair(base_params, conn_cfg, connection_name)
    elif auth_method == "oauth":
        return _connect_oauth(base_params, conn_cfg, connection_name)
    else:
        raise ValueError(
            f"Unsupported auth_method '{auth_method}' for connection "
            f"'{connection_name}'. Supported: pat, key_pair, oauth"
        )


# =============================================================================
# PAT Authentication
# =============================================================================

def _connect_pat(base_params, conn_cfg, connection_name):
    """
    Connect using Programmatic Access Token (PAT).

    Args:
        base_params: dict - Common connection parameters.
        conn_cfg: dict - Connection-specific configuration.
        connection_name: str - Name for logging purposes.

    Returns:
        snowflake.connector.SnowflakeConnection
    """
    import snowflake.connector

    logger = get_logger()

    pat_token = resolve_env_vars(conn_cfg.get("pat_token", ""))
    if not pat_token:
        raise ValueError(
            f"Connection '{connection_name}': pat_token is required for PAT authentication."
        )

    logger.debg(f"Connecting to Snowflake via PAT for connection '{connection_name}'")

    try:
        conn = snowflake.connector.connect(
            **base_params,
            token=pat_token,
            authenticator="programmatic_access_token",
        )
        logger.info(f"Connection '{connection_name}' established successfully (PAT)")
        return conn
    except Exception as e:
        logger.erro(f"Failed to connect '{connection_name}' via PAT: {str(e)}")
        raise ConnectionError(
            f"Failed to establish PAT connection '{connection_name}': {str(e)}"
        ) from e


# =============================================================================
# Key Pair Authentication
# =============================================================================

def _connect_key_pair(base_params, conn_cfg, connection_name):
    """
    Connect using RSA Key Pair authentication.

    Supports two modes:
    - private_key: PEM-encoded private key content passed directly as a string
      (preferred for CI/CD pipelines where the key is stored as a secret variable)
    - private_key_path: Path to PEM private key file on disk (fallback)

    Args:
        base_params: dict - Common connection parameters.
        conn_cfg: dict - Connection-specific configuration.
        connection_name: str - Name for logging purposes.

    Returns:
        snowflake.connector.SnowflakeConnection
    """
    import snowflake.connector
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization

    logger = get_logger()

    private_key_content = resolve_env_vars(conn_cfg.get("private_key", ""))
    private_key_path = resolve_env_vars(conn_cfg.get("private_key_path", ""))
    passphrase = resolve_env_vars(conn_cfg.get("private_key_passphrase", ""))

    if not private_key_content and not private_key_path:
        raise ValueError(
            f"Connection '{connection_name}': Either 'private_key' (key content) or "
            f"'private_key_path' (file path) is required for key_pair authentication."
        )

    # Load private key from content variable or file
    if private_key_content:
        logger.debg(f"Loading private key from variable for connection '{connection_name}'")
        key_bytes = private_key_content.encode("utf-8")
    else:
        if not os.path.isfile(private_key_path):
            raise FileNotFoundError(
                f"Connection '{connection_name}': Private key file not found: "
                f"{private_key_path}"
            )
        logger.debg(f"Loading private key from file: {private_key_path}")
        with open(private_key_path, "rb") as key_file:
            key_bytes = key_file.read()

    # Decode the private key
    private_key = serialization.load_pem_private_key(
        key_bytes,
        password=passphrase.encode() if passphrase else None,
        backend=default_backend(),
    )

    # Get DER-encoded private key bytes
    private_key_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    logger.debg(f"Connecting to Snowflake via Key Pair for connection '{connection_name}'")

    try:
        conn = snowflake.connector.connect(
            **base_params,
            private_key=private_key_bytes,
        )
        logger.info(f"Connection '{connection_name}' established successfully (Key Pair)")
        return conn
    except Exception as e:
        logger.erro(f"Failed to connect '{connection_name}' via Key Pair: {str(e)}")
        raise ConnectionError(
            f"Failed to establish Key Pair connection '{connection_name}': {str(e)}"
        ) from e


# =============================================================================
# OAuth Authentication
# =============================================================================

def _connect_oauth(base_params, conn_cfg, connection_name):
    """
    Connect using OAuth Client Credentials flow.

    Args:
        base_params: dict - Common connection parameters.
        conn_cfg: dict - Connection-specific configuration.
        connection_name: str - Name for logging purposes.

    Returns:
        snowflake.connector.SnowflakeConnection
    """
    import requests
    import snowflake.connector

    logger = get_logger()

    token_url = resolve_env_vars(conn_cfg.get("oauth_token_url", ""))
    client_id = resolve_env_vars(conn_cfg.get("oauth_client_id", ""))
    client_secret = resolve_env_vars(conn_cfg.get("oauth_client_secret", ""))
    scope = resolve_env_vars(conn_cfg.get("oauth_scope", ""))

    if not all([token_url, client_id, client_secret]):
        raise ValueError(
            f"Connection '{connection_name}': oauth_token_url, oauth_client_id, "
            f"and oauth_client_secret are required for OAuth authentication."
        )

    logger.debg(f"Requesting OAuth token from: {token_url}")

    # Request access token
    try:
        token_response = requests.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
                "scope": scope,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=30,
        )
        token_response.raise_for_status()
    except requests.RequestException as e:
        logger.erro(f"OAuth token request failed for '{connection_name}': {str(e)}")
        raise ConnectionError(
            f"Failed to obtain OAuth token for '{connection_name}': {str(e)}"
        ) from e

    token_data = token_response.json()
    access_token = token_data.get("access_token")

    if not access_token:
        raise ConnectionError(
            f"OAuth token response for '{connection_name}' did not contain access_token."
        )

    logger.debg(f"Connecting to Snowflake via OAuth for connection '{connection_name}'")

    try:
        conn = snowflake.connector.connect(
            **base_params,
            token=access_token,
            authenticator="oauth",
        )
        logger.info(f"Connection '{connection_name}' established successfully (OAuth)")
        return conn
    except Exception as e:
        logger.erro(f"Failed to connect '{connection_name}' via OAuth: {str(e)}")
        raise ConnectionError(
            f"Failed to establish OAuth connection '{connection_name}': {str(e)}"
        ) from e


# =============================================================================
# Connection Cleanup
# =============================================================================

def close_connection(conn, connection_name="unknown"):
    """
    Safely close a Snowflake connection.

    Args:
        conn: snowflake.connector.SnowflakeConnection
        connection_name: str - Name for logging purposes.
    """
    logger = get_logger()
    try:
        if conn and not conn.is_closed():
            conn.close()
            logger.info(f"Connection '{connection_name}' closed successfully")
    except Exception as e:
        logger.warn(f"Error closing connection '{connection_name}': {str(e)}")
