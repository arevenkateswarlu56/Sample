# Snowflake DBA Tasks Automation - Core Package
# This package provides: logging, connection management, and core engine logic.
#
# Imports are deferred to avoid import errors when dependencies
# are not yet installed. Use direct imports in your scripts:
#   from core.logger import get_logger
#   from core.connection import get_connection
#   from core.engine import Engine
