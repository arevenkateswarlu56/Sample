"""
Snowflake DBA Tasks Automation - Custom Logging Module

Provides:
- Custom log levels: DEBG(10), INFO(20), WARN(30), ERRO(40), SEVR(50)
- Daily log rotation with naming: snf-dba-tasks-auto-YYYYMMDD.log
- Call chain context: Script -> Function -> CallerScript -> CallerFunction -> Message
- Thread-safe logging with file handler

Usage:
    from core.logger import get_logger
    logger = get_logger()
    logger.info("Operation completed successfully")
"""

import logging
import os
import inspect
from datetime import datetime
from logging.handlers import TimedRotatingFileHandler


# =============================================================================
# Custom Log Levels
# =============================================================================

# Define custom level names and numeric values
DEBG = 10
INFO = 20
WARN = 30
ERRO = 40
SEVR = 50

# Register custom level names
logging.addLevelName(DEBG, "DEBG")
logging.addLevelName(INFO, "INFO")
logging.addLevelName(WARN, "WARN")
logging.addLevelName(ERRO, "ERRO")
logging.addLevelName(SEVR, "SEVR")

# Map string config values to numeric levels
LEVEL_MAP = {
    "DEBG": DEBG,
    "INFO": INFO,
    "WARN": WARN,
    "ERRO": ERRO,
    "SEVR": SEVR,
}


# =============================================================================
# Custom Formatter
# =============================================================================

class DBATaskFormatter(logging.Formatter):
    """
    Custom formatter that includes call chain context.

    Format: <Timestamp> <Level> : <Script> -> <Function> -> <CallerScript> -> <CallerFunction> -> <Message>
    """

    def format(self, record):
        # Get timestamp
        timestamp = datetime.fromtimestamp(record.created).strftime(
            "%Y-%m-%d %H:%M:%S.%f"
        )[:-3]

        # Get the call stack to determine script and function context
        script_name = os.path.basename(record.pathname)
        func_name = record.funcName

        # Get caller context (who called the logging function)
        caller_script = ""
        caller_func = ""

        # Walk up the stack to find the actual caller
        stack = inspect.stack()
        # Skip frames: format -> handler.emit -> logger method -> actual caller
        # We look for frames outside the logging module and this module
        caller_found = False
        current_found = False

        for frame_info in stack:
            frame_file = os.path.basename(frame_info.filename)
            # Skip logging internals and this logger module
            if frame_file in ("logger.py", "__init__.py") or "logging" in frame_info.filename:
                continue
            if not current_found:
                current_found = True
                continue
            if not caller_found:
                caller_script = frame_file
                caller_func = frame_info.function
                caller_found = True
                break

        # Build the log line
        level_name = record.levelname
        message = record.getMessage()

        # Format: Timestamp Level : Script -> Function -> CallerScript -> CallerFunction -> Message
        if caller_script and caller_func:
            log_line = (
                f"{timestamp} {level_name} : {script_name} -> {func_name} -> "
                f"{caller_script} -> {caller_func} -> {message}"
            )
        else:
            log_line = (
                f"{timestamp} {level_name} : {script_name} -> {func_name} -> {message}"
            )

        return log_line


# =============================================================================
# Daily Rotating File Handler
# =============================================================================

class DailyLogHandler(TimedRotatingFileHandler):
    """
    Daily rotating handler that names files as:
    snf-dba-tasks-auto-YYYYMMDD.log

    Rotates at midnight each day.
    """

    def __init__(self, log_path):
        # Ensure log directory exists
        os.makedirs(log_path, exist_ok=True)

        # Current date for initial log file name
        today = datetime.now().strftime("%Y%m%d")
        log_file = os.path.join(log_path, f"snf-dba-tasks-auto-{today}.log")

        super().__init__(
            filename=log_file,
            when="midnight",
            interval=1,
            backupCount=0,  # Keep all log files
            encoding="utf-8",
        )

        self.log_path = log_path
        self.suffix = "%Y%m%d"
        self.namer = self._custom_namer

    def _custom_namer(self, default_name):
        """
        Custom namer to produce: snf-dba-tasks-auto-YYYYMMDD.log
        """
        # Extract the date from the rotated file suffix
        # default_name format: /path/snf-dba-tasks-auto-YYYYMMDD.log.YYYYMMDD
        dir_name = os.path.dirname(default_name)
        # Get the date suffix that TimedRotatingFileHandler appends
        date_suffix = default_name.split(".")[-1]
        return os.path.join(dir_name, f"snf-dba-tasks-auto-{date_suffix}.log")

    def doRollover(self):
        """
        Override rollover to create new file with today's date.
        """
        if self.stream:
            self.stream.close()
            self.stream = None

        # New log file with today's date
        today = datetime.now().strftime("%Y%m%d")
        new_log_file = os.path.join(self.log_path, f"snf-dba-tasks-auto-{today}.log")
        self.baseFilename = new_log_file

        # Open new file
        self.stream = self._open()

        # Calculate next rollover time
        current_time = int(datetime.now().timestamp())
        self.rolloverAt = self.computeRollover(current_time)


# =============================================================================
# Logger Singleton
# =============================================================================

_logger_instance = None


def get_logger(config=None):
    """
    Get or create the singleton logger instance.

    Args:
        config: dict - Configuration dictionary with 'logging' section.
                If None, uses defaults.

    Returns:
        logging.Logger instance configured with custom levels and rotation.
    """
    global _logger_instance

    if _logger_instance is not None:
        return _logger_instance

    # Default configuration
    log_level = "INFO"
    log_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
    )

    # Apply config if provided
    if config and "logging" in config:
        log_cfg = config["logging"]
        log_level = log_cfg.get("level", "INFO").upper()
        log_path = log_cfg.get("log_path", log_path)

    # Create logger
    logger = logging.getLogger("snf_dba_tasks")
    logger.setLevel(LEVEL_MAP.get(log_level, INFO))

    # Remove existing handlers
    logger.handlers.clear()

    # Add daily rotating file handler
    file_handler = DailyLogHandler(log_path)
    file_handler.setFormatter(DBATaskFormatter())
    file_handler.setLevel(LEVEL_MAP.get(log_level, INFO))
    logger.addHandler(file_handler)

    # Add console handler for WARN and above
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(DBATaskFormatter())
    console_handler.setLevel(WARN)
    logger.addHandler(console_handler)

    # Add convenience methods for custom levels
    def debg(msg, *args, **kwargs):
        logger.log(DEBG, msg, *args, **kwargs)

    def warn(msg, *args, **kwargs):
        logger.log(WARN, msg, *args, **kwargs)

    def erro(msg, *args, **kwargs):
        logger.log(ERRO, msg, *args, **kwargs)

    def sevr(msg, *args, **kwargs):
        logger.log(SEVR, msg, *args, **kwargs)

    logger.debg = debg
    logger.warn = warn
    logger.erro = erro
    logger.sevr = sevr

    _logger_instance = logger
    return logger


def reset_logger():
    """Reset the logger singleton (useful for testing)."""
    global _logger_instance
    if _logger_instance:
        for handler in _logger_instance.handlers[:]:
            handler.close()
            _logger_instance.removeHandler(handler)
    _logger_instance = None
