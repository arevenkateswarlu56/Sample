# DBA-TASKS-AUTO Framework - Session Summary

## Overview

This document summarizes all development work performed on the Snowflake DBA Tasks Automation Framework during this session. Use as context for future prompts.

**Base Directory**: `/DMVA_DATA/snow-cli/DBA-TASKS-AUTO/`
**Reference Doc**: `/DMVA_DATA/snow-cli/DBA-TASKS-AUTO/REQUIREMENTS.md`

---

## Framework Structure

```
DBA-TASKS-AUTO/
├── config/
│   ├── dba_tasks_config.yaml           # Active config (gitignored - has secrets)
│   └── dba_tasks_config.yaml.template  # Template for deployments (in git)
├── core/
│   ├── __init__.py
│   ├── engine.py          # Core logic (~1585 lines) - ALL business logic
│   ├── connection.py      # Snowflake connection factory (PAT, Key Pair, OAuth)
│   └── logger.py          # Custom logging (DEBG/INFO/WARN/ERRO/SEVR)
├── commands/
│   ├── __init__.py
│   ├── snf_test_connection.py
│   ├── snf_access_provision.py
│   ├── snf_create_database.py
│   ├── snf_create_db_roles.py
│   ├── snf_create_db_account_role.py
│   ├── snf_drop_db_account_role.py
│   └── snf_clone_database.py
├── pipelines/
│   ├── snf-create-database.yml
│   └── snf-clone-database.yml
├── logs/
├── py-pip-packages/
├── REQUIREMENTS.md
├── requirements.txt
└── SESSION_SUMMARY.md  (THIS FILE)
```

---

## Commands Implemented

| Command | Purpose | Parameters |
|---------|---------|------------|
| `snf_test_connection.py` | Test Snowflake connectivity | --connection, [--query] |
| `snf_access_provision.py` | Grant privileges via database roles | --connection, --database, --db-type |
| `snf_create_db_roles.py` | Create 4 database roles (_ALL_R, _ALL_RW, _ALL_RWD, _ALL_C) | --connection, --database |
| `snf_create_db_account_role.py` | Create account role (_ADMIN) | --connection, --database |
| `snf_drop_db_account_role.py` | Drop account role (_ADMIN) | --connection, --database |
| `snf_create_database.py` | Full DB creation (DB + schemas + roles + access) | --connection, --database, --drop-flag, --db-type |
| `snf_clone_database.py` | Clone DB with role cleanup + fresh provisioning | --connection, --source-database, --target-database, --drop-flag, --db-type |

---

## Key Engine Methods

| Method | TASK_TYPE filter |
|--------|----------------|
| `provision_database_access()` | ACCESS_PROVISION |
| `create_database_roles()` | DATABASE_ROLE_CREATION |
| `create_database_account_role()` | DATABASE_SFACCOUNT_ROLE_CREATION |
| `drop_database_account_role()` | DATABASE_SFACCOUNT_ROLE_DROP |
| `create_database()` | DB_CREATION |
| `clone_database()` | DATABASE_CLONE |
| `drop_database_roles_by_prefix()` | (no TASK_TO_ROLE_MAP - utility) |
| `execute_sql()` | (core SQL executor with audit) |
| `console_msg()` | (prints status to stdout) |

---

## Authentication Methods Supported

| Method | Config Key | Fields |
|--------|-----------|--------|
| PAT | `pat` | `pat_token` (via `${ENV_VAR}`) |
| Key Pair (variable) | `key_pair` | `private_key` (PEM content via `${ENV_VAR}`), `private_key_passphrase` |
| Key Pair (file) | `key_pair` | `private_key_path`, `private_key_passphrase` |
| OAuth | `oauth` | `oauth_token_url`, `oauth_client_id`, `oauth_client_secret`, `oauth_scope` |

**Key Pair Priority**: `private_key` (content) takes precedence over `private_key_path` (file) if both provided.

---

## Metadata Configuration

```yaml
metadata:
  database: ZNAWUSERDB
  schema: DBAALL
```

- `metadata.connection` was removed (unused dead config)
- All metadata tables referenced with fully qualified names: `ZNAWUSERDB.DBAALL.<TABLE>`

---

## Audit Logging

**Table**: `ZNAWUSERDB.DBAALL.SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG`

| Column | Source |
|--------|--------|
| TASK_ID | `int(time.time() * 1000)` — epoch ms, generated once per invocation |
| EXECUTED_AT | `CURRENT_TIMESTAMP()` |
| TASK_NAME | Script filename from `sys.argv[0]` |
| USERNAME | `CURRENT_USER()` |
| ROLE_NAME | `CURRENT_ROLE()` |
| DATABASE_NAME | `CURRENT_DATABASE()` |
| WAREHOUSE_NAME | `CURRENT_WAREHOUSE()` |
| CMD | Full SQL executed |
| CMD_OUTPUT | Result rows (truncated at 10000 chars) |
| CMD_QUERY_ID | `cursor.sfqid` — Snowflake query ID |

---

## Console Output Standard

All commands print high-level progress to stdout via `Engine.console_msg()`:
- Header banner: command name + parameters
- Step-by-step `  >> <message>` lines
- Footer banner: COMPLETED SUCCESSFULLY

This does NOT affect file logging or audit trail.

---

## Key Design Decisions Made

1. **create_database flow**: After DB creation, creates DBAALL schema and drops PUBLIC schema before creating roles.
2. **DROP_FLAG + account role**: When DROP_FLAG=YES, drops `<DBNAME>_ADMIN` account role BEFORE dropping the database, then switches back to the DB_CREATION role for DROP/CREATE.
3. **clone_database**: Validates source != target. After cloning, drops source DB roles (matching `<SOURCE_DB>_ALL_%`) from target before creating fresh target roles.
4. **Access provisioning logic**: Privilege levels (RO/RW/RWD/C) are determined by the `ACCESS_TO_ROLES` table data per `DATABASE_TYPE`. Different data = different grants.
5. **Each sub-method sets its own role**: `create_database_roles`, `create_database_account_role`, `provision_database_access` each independently read TASK_TO_ROLE_MAP and switch roles.

---

## Azure DevOps Integration

- **Agent pool**: `ZNA-CDO-AKS-AGENTS` (self-hosted, required for privatelink)
- **Secret variable group**: `DBA-TASKS-SECRETS`
- **Key pair secrets**: `SNOWFLAKE_DEV_PRIVATE_KEY`, `SNOWFLAKE_DEV_KEY_PASSPHRASE`
- **Config template approach**: Pipeline copies `.yaml.template` to `.yaml` at runtime
- **Approval**: Can use Azure DevOps Environments with Approvals + Teams notification (documented but not yet implemented)

---

## Streamlit Application (REMOVED)

A Streamlit app was built under `stream-lit/` directory but was subsequently removed. It had:
- Role-based Admin/User consoles
- Request raise + approval + status pages
- Subprocess execution of `snf_create_database.py`
- Known issue: Streamlit button reruns interrupted long-running subprocess

---

## Active Connections in Config

| Name | Account | Auth | Used For |
|------|---------|------|----------|
| SNF_DEV | rw96133.central-us.privatelink | PAT / Key Pair | Development |
| SNF_QA | cm11763.central-us.privatelink | PAT | QA |

---

## Rules / Preferences Stored

1. Always update REQUIREMENTS.md with full documentation for every framework change (without explicit instruction).

---

## Troubleshooting Notes

- **"Could not connect after 2 attempts"**: Agent can't reach privatelink URL. Need self-hosted agent on same network.
- **PAT auth error "Invalid OAuth access token"**: Use `authenticator="programmatic_access_token"` not `"oauth"`.
- **Different grants on different servers for same DB type**: Caused by different data in `ACCESS_TO_ROLES` table, not code differences.
