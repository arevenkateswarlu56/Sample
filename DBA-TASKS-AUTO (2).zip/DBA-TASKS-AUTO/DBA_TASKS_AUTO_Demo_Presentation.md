# DBA Tasks Automation Framework
## Management Demo - Prototype Overview

---

## Slide 1: Title

**DBA Tasks Automation Framework (Prototype)**

Automating Snowflake Database Administration at Scale

| | |
|---|---|
| **Team** | DBA Team - Zurich North America (ZNA) |
| **Platform** | Snowflake + Azure DevOps |
| **Status** | Framework Prototype |

---

## Slide 2: Problem Statement

### Current Challenges

- **Manual Execution** - DBA tasks (database creation, cloning, role provisioning) performed manually via SQL scripts
- **No Audit Trail** - Difficult to track who did what and when
- **Inconsistent Standards** - Different DBAs may apply different naming conventions or privilege sets
- **No Approval Workflow** - No formal governance over high-impact operations
- **Slow Turnaround** - Requests handled ad-hoc, no structured SLA process

---

## Slide 3: Solution Overview

### DBA Tasks Automation Framework

A **Python-based automation framework** integrated with **Azure DevOps Pipelines** that:

1. Standardizes DBA operations with coded business logic
2. Enforces naming conventions and privilege models automatically
3. Provides a governed request/approval workflow
4. Maintains a complete audit trail in Snowflake
5. Sends notifications on task completion

> **Key Principle**: Metadata-driven logic - role assignments and access grants are driven by Snowflake configuration tables, not hardcoded in scripts.

---

## Slide 4: Architecture Overview

```
+-------------------+       +---------------------+       +------------------+
|   Azure DevOps    |       |   DBA-TASKS-AUTO    |       |    Snowflake     |
|   (Pipelines)     |       |   (Python Engine)   |       |    (Target)      |
+-------------------+       +---------------------+       +------------------+
|                   |       |                     |       |                  |
| - Request Forms   | ----> | - Core Engine       | ----> | - Database Ops   |
| - Approval Gates  |       | - Connection Mgr    |       | - Role Mgmt      |
| - Self-hosted     |       | - Custom Logger     |       | - Audit Table    |
|   AKS Agents      |       | - Command Modules   |       | - Metadata Tables|
|                   |       |                     |       |                  |
+-------------------+       +---------------------+       +------------------+
         |                           |                            |
         v                           v                            v
  DBA-APPROVAL Env            Audit Logging              TASK_TO_ROLE_MAP
  (Teams Notification)        (Every SQL logged)         ACCESS_TO_ROLES
```

---

## Slide 5: Supported DBA Tasks (Prototype)

| # | Task | Description |
|---|------|-------------|
| 1 | **Test Connection** | Validate Snowflake connectivity and authentication |
| 2 | **Create Database** | Full DB creation with standard schema, roles, and grants |
| 3 | **Clone Database** | Clone source DB to target with fresh role provisioning |
| 4 | **Create Database Roles** | Standard role set: Read, Read-Write, Read-Write-Delete, Create |
| 5 | **Create Account Role** | Create DB_ADMIN account-level role |
| 6 | **Drop Account Role** | Remove account-level roles |
| 7 | **Access Provisioning** | Grant privileges based on metadata-driven rules |

---

## Slide 6: Request & Approval Workflow (3-Stage Pipeline)

```
 STAGE 1: SUBMIT          STAGE 2: APPROVE           STAGE 3: EXECUTE
+------------------+    +--------------------+    +--------------------+
|                  |    |                    |    |                    |
| User fills       |    | Pipeline pauses at |    | After approval:    |
| pipeline form    |--->| DBA-APPROVAL       |--->| - Execute command  |
| (parameters)     |    | Environment        |    | - Log to audit     |
|                  |    |                    |    | - Email notify     |
| Record inserted  |    | Approver gets      |    | - Update status    |
| (SUBMITTED)      |    | Teams notification |    | (COMPLETED/FAILED) |
|                  |    |                    |    |                    |
+------------------+    +--------------------+    +--------------------+
```

**Governance**: No high-impact operation runs without explicit DBA approval.

---

## Slide 7: Standardized Role Model

For every database created (e.g., `SALES_DB`), the framework automatically provisions:

### Database Roles
| Role | Privileges | Use Case |
|------|-----------|----------|
| `SALES_DB_ALL_R` | SELECT on all schemas | Read-only access |
| `SALES_DB_ALL_RW` | SELECT, INSERT, UPDATE | Read-write access |
| `SALES_DB_ALL_RWD` | SELECT, INSERT, UPDATE, DELETE | Full DML access |
| `SALES_DB_ALL_C` | CREATE TABLE, VIEW, etc. | Developer/DDL access |

### Account Role
| Role | Purpose |
|------|---------|
| `SALES_DB_ADMIN` | Database ownership and administration |

> Privileges are assigned based on the `ACCESS_TO_ROLES` metadata table, parameterized by database type (APP_DB, BKP_DB).

---

## Slide 8: Audit & Compliance

Every SQL command executed through the framework is logged to:

**`ZNAWUSERDB.DBAALL.SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG`**

| Field | Description |
|-------|-------------|
| TASK_ID | Unique run identifier (groups all operations from one execution) |
| PIPELINE_ID | Azure DevOps Build ID (traceability) |
| EXECUTED_AT | Timestamp of execution |
| TASK_NAME | Which automation script ran |
| CMD | Full SQL statement executed |
| CMD_OUTPUT | Result of the operation |
| CMD_QUERY_ID | Snowflake Query ID for deep investigation |
| SNF_CONNECTION | Which environment was targeted |

**Benefits**: Full traceability, compliance-ready, enables post-mortem analysis.

---

## Slide 9: Security & Authentication

### Multi-Method Authentication Support

| Method | Use Case | Security Level |
|--------|----------|---------------|
| **Programmatic Access Token (PAT)** | CI/CD pipelines | High - token-based, rotatable |
| **Key Pair (RSA)** | Automated service accounts | High - certificate-based |
| **OAuth (Client Credentials)** | Future integrations | Enterprise-grade |

### Security Controls
- Credentials stored in Azure DevOps Variable Groups (encrypted)
- Config files with restricted permissions (600)
- Environment variable substitution - no secrets in code
- Self-hosted AKS agents with private link connectivity (no public internet exposure)

---

## Slide 10: Environment Support

| Environment | Account | Connectivity | Status |
|-------------|---------|--------------|--------|
| **DEV** | rw96133.central-us.privatelink | Private Link | Active |
| **QA** | cm11763.central-us.privatelink | Private Link | Active |
| **PROD** | (configurable) | Private Link | Planned |

- Framework is **environment-agnostic** - same code, different config
- Config template injected with env-specific secrets at pipeline runtime

---

## Slide 11: Key Benefits Summary

| Benefit | Impact |
|---------|--------|
| **Consistency** | Every database follows the same standard structure |
| **Speed** | Automated provisioning in minutes vs. hours |
| **Governance** | Formal approval workflow for all changes |
| **Audit** | Complete SQL-level audit trail for compliance |
| **Scalability** | Add new tasks by creating new command modules |
| **Security** | No shared credentials, private link only |
| **Extensibility** | Metadata-driven logic - change behavior via config, not code |

---

## Slide 12: Future Enhancement - Power Automate & Teams Integration

### Vision: Self-Service Request Portal with Microsoft Power Platform

```
+------------------+     +-------------------+     +------------------+
|  Microsoft Teams |     |  Power Automate   |     |  Azure DevOps    |
|  (User Portal)   |     |  (Orchestrator)   |     |  (Execution)     |
+------------------+     +-------------------+     +------------------+
|                  |     |                   |     |                  |
| - Adaptive Card  |---->| - Receive request |---->| - Trigger        |
|   request form   |     | - Route to        |     |   pipeline       |
| - Approval card  |     |   approver        |     | - Execute task   |
|   to DBA team    |     | - Track status    |     | - Return result  |
| - Status updates |<----| - Notify on       |<----| - Update status  |
|   in channel     |     |   completion      |     |                  |
+------------------+     +-------------------+     +------------------+
```

### Planned Capabilities

| Feature | Description |
|---------|-------------|
| **Teams Adaptive Cards** | Rich interactive forms for submitting DBA requests directly in Teams |
| **Approval Flow in Teams** | DBA approvers receive actionable approval cards - approve/reject with one click |
| **Real-time Notifications** | Status updates posted to a dedicated Teams channel |
| **Power Automate Orchestration** | Route requests, enforce SLAs, escalate overdue approvals |
| **Self-Service Catalog** | Users browse available DBA services and submit requests without leaving Teams |
| **Audit Dashboard** | Power BI dashboard connected to audit table for management visibility |

### Benefits of Power Automate + Teams Integration

1. **Reduced Friction** - No need to navigate to Azure DevOps; request from Teams
2. **Faster Approvals** - Actionable notifications push to approvers in real-time
3. **Better Visibility** - Status updates visible in shared Teams channel
4. **SLA Enforcement** - Auto-escalation for overdue approvals
5. **User Adoption** - Meet users where they already work (Microsoft Teams)

---

## Slide 13: Roadmap Summary

| Phase | Scope | Status |
|-------|-------|--------|
| **Phase 1** | Core Framework + Engine + CLI Commands | Complete (Prototype) |
| **Phase 2** | Azure DevOps Pipeline Integration + Approval Gates | Complete (Prototype) |
| **Phase 3** | Audit Logging + Email Notifications | Complete (Prototype) |
| **Phase 4** | Power Automate + Teams Approval Workflow | Future Enhancement |
| **Phase 5** | Self-Service Portal + Power BI Dashboard | Future Enhancement |
| **Phase 6** | Additional DBA Tasks (User Mgmt, Warehouse Ops, etc.) | Future Enhancement |

---

## Slide 14: Technology Stack

| Layer | Technology |
|-------|-----------|
| **Automation Engine** | Python 3.9+ |
| **Database Platform** | Snowflake |
| **CI/CD** | Azure DevOps Pipelines |
| **Compute** | Self-hosted AKS Agents (Private Link) |
| **Secrets Management** | Azure DevOps Variable Groups |
| **Notifications (Current)** | SMTP Email |
| **Notifications (Future)** | Microsoft Teams + Power Automate |
| **Monitoring (Future)** | Power BI |

---

## Slide 15: Demo Walkthrough

### What We Will Show Today

1. **Configuration** - YAML-based environment config with secure credential handling
2. **Connection Test** - Validate connectivity to Snowflake DEV environment
3. **Database Creation** - End-to-end automated database provisioning with roles
4. **Audit Trail** - Query the audit log showing full execution history
5. **Pipeline Trigger** - Azure DevOps request pipeline with approval gate

---

## Slide 16: Summary & Ask

### This Prototype Demonstrates

- A **production-ready framework** for automating DBA tasks at scale
- **Governed workflows** with formal approval gates
- **Complete audit trail** for compliance and traceability
- **Extensible architecture** - easy to add new tasks without modifying core

### Ask

- Approval to move from **Prototype to Production**
- Support for **Power Automate + Teams** integration (Phase 4)
- Alignment on **priority tasks** to add next (user management, warehouse ops, etc.)

---

*Framework Prototype - DBA Team, Zurich North America*
