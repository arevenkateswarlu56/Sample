# Snowflake DBA Tasks Automation Framework - Requirements & Architecture

## Overview

This framework automates Snowflake DBA tasks using Python. It is designed to be portable across Linux servers, secure by default, and simple to understand and extend.

**Base Directory**: `/DMVA_DATA/snow-cli/DBA-TASKS-AUTO/`

### Attribution

| Role | Name |
|------|------|
| Designed by | Venkateswarlu Are |
| Architected by | Venkateswarlu Are |
| Reviewed by | Venkateswarlu Are |
| Coded by | AI (Cortex Code) |

---

## Architecture

### Directory Structure

```
DBA-TASKS-AUTO/
├── config/
│   └── dba_tasks_config.yaml       # All configuration (connections, logging, metadata)
├── core/
│   ├── __init__.py                  # Package initializer
│   ├── engine.py                    # Core logic - SINGLE file with all shared functionality
│   ├── connection.py                # Snowflake connection manager (PAT, Key Pair, OAuth)
│   └── logger.py                    # Custom logging (5 levels + daily rotation)
├── commands/                        # Command scripts (DBA task scripts)
│   ├── __init__.py
│   ├── snf_<task_name>.py           # Each task = one script with snf_ prefix and argparse CLI
│   └── snf_request_handler.py       # Request lifecycle handler (submit/approve/start/complete)
├── pipelines/                       # Azure DevOps pipeline YAML definitions
│   ├── snf-create-database.yml
│   ├── snf-clone-database.yml
│   └── snf-test-connection-request.yml  # Request/approval workflow pipeline
├── logs/                            # Log output directory (daily rotation)
├── requirements.txt                 # Python pip dependencies
└── REQUIREMENTS.md                  # THIS FILE - master reference
```

### Design Principles

1. **Single Core File**: All core business logic resides in `core/engine.py`. Command scripts are thin wrappers that validate input and delegate to the engine.
2. **Configuration-Driven**: All environment-specific settings live in `config/dba_tasks_config.yaml`. No hardcoded values in Python files.
3. **Portable**: Framework migrates to any Linux server with Python 3.9+ and pip. No Docker/Kubernetes dependency.
4. **Secure by Default**: Config file permissions 600, credentials never logged, private keys referenced by path.
5. **Traceable**: Every function entry/exit is logged with full call chain context.

---

## Configuration Standards

### File: `config/dba_tasks_config.yaml`

**Sections:**

| Section | Purpose |
|---------|---------|
| `logging` | Log level, log file path, file prefix |
| `connections` | Named Snowflake connections (multiple accounts supported) |
| `metadata` | Default metadata connection name and schema |

### Connection Authentication Methods

| Method | Config Key | Required Fields |
|--------|-----------|-----------------|
| PAT (Programmatic Access Token) | `pat` | `pat_token` |
| Key Pair (RSA) - Variable | `key_pair` | `private_key` (PEM content), `private_key_passphrase` (optional) |
| Key Pair (RSA) - File | `key_pair` | `private_key_path` (file path), `private_key_passphrase` (optional) |
| OAuth (Client Credentials) | `oauth` | `oauth_token_url`, `oauth_client_id`, `oauth_client_secret`, `oauth_scope` |

**Key Pair Priority**: If both `private_key` (content) and `private_key_path` (file) are provided, the `private_key` content takes precedence. Use `private_key` with `${ENV_VAR}` substitution for CI/CD pipelines where the key is stored as a secret variable.

### Environment Variable Substitution

Any config value can reference an environment variable using `${ENV_VAR_NAME}` syntax. This allows sensitive values to be injected at runtime without storing them in the config file.

---

## Logging Standards

### Log Levels

| Level | Code | Numeric | Usage |
|-------|------|---------|-------|
| DEBG | DEBG | 10 | Debug/trace information |
| INFO | INFO | 20 | Normal operational messages |
| WARN | WARN | 30 | Warning conditions |
| ERRO | ERRO | 40 | Error conditions (recoverable) |
| SEVR | SEVR | 50 | Severe/critical errors (unrecoverable) |

### Log File Naming

- Pattern: `snf-dba-tasks-auto-YYYYMMDD.log`
- Rotation: Daily at midnight, new file created with current date
- Location: Defined in `config/dba_tasks_config.yaml` under `logging.log_path`

### Log Message Format

```
<Timestamp> <Level> : <Script> -> <Function> -> <CallerScript> -> <CallerFunction> -> <Message>
```

Example:
```
2025-01-15 10:30:45.123 INFO : compare_ddl.py -> validate_inputs -> engine.py -> run_comparison -> Starting DDL comparison for PROD_DB
```

### Function Tracing

Every Python function must log:
- Entry: `Entering <function_name>` with parameters (sanitized - no credentials)
- Exit: `Exiting <function_name>` with status
- Operations: What the function is performing

Use the `@trace` decorator from `core/engine.py` to automate entry/exit logging.

---

## Command Script Standards

### CLI Interface Pattern

Every command script (except `core/engine.py`) must:

1. Accept `--help` flag showing usage
2. Define mandatory and optional argument groups
3. Always include `--connection` parameter to select named connection
4. Validate all inputs before calling core logic

### Help Output Format

```
usage: script_name.py [-h] [--connection conn_name]
                      [--option1 input1] --option2 input2
                      --option3 input3

<Description of what this script does>

Mandatory arguments:
  --connection         Snowflake connection name from config
  --option1            Description of this parameter

Optional arguments:
  -h, --help           Show this help message and exit
  --option2            Description of this parameter
  --option3            Description of this parameter
```

### Input Validation

- All mandatory parameters must be present
- Connection name must exist in config
- Parameter values validated against expected types/ranges
- Clear error messages on validation failure

---

## Security Standards

1. **Config File Permissions**: `chmod 600 config/dba_tasks_config.yaml`
2. **Private Keys**: Referenced by file path, never stored inline in config
3. **No Credential Logging**: Logger sanitizes any credential-like values before writing
4. **Environment Variables**: Sensitive values can use `${ENV_VAR}` substitution
5. **No Secrets in Code**: Zero hardcoded credentials, tokens, or keys in `.py` files
6. **Token Rotation**: OAuth tokens refreshed per session, never cached to disk

---

## Deployment & Migration

### Prerequisites

- Python 3.9+
- pip (Python package manager)
- Network access to Snowflake account(s)

### Deployment Steps

1. Copy `DBA-TASKS-AUTO/` directory to target server
2. Install dependencies: `pip install -r requirements.txt`
3. Update `config/dba_tasks_config.yaml` with target environment values
4. Set file permissions: `chmod 600 config/dba_tasks_config.yaml`
5. Ensure `logs/` directory is writable
6. Test connectivity: `python commands/snf_test_connection.py --connection <name>`

### No Container Dependency

This framework runs directly on Linux with Python and pip. It does NOT require Docker, Kubernetes, or any containerization platform.

---

## Future Development Requirements

### Planned Enhancements

1. **DDL Comparison Tool**: Compare source and target database table DDLs
2. **Schema Drift Detection**: Detect schema changes between environments
3. ~~**Automated Grants Management**: Manage role grants across accounts~~ (IMPLEMENTED: `commands/access_provision.py`)
4. **Storage Monitoring**: Track table/schema/database storage growth
5. **Query Performance Analyzer**: Identify and report slow queries
6. **User Access Audit**: Audit user permissions and access patterns
7. **Replication Monitoring**: Monitor database replication status and lag
8. **Task/Stream Health Check**: Monitor Snowflake tasks and streams status
9. **Cost Attribution Reports**: Generate per-warehouse/per-user cost reports
10. **Automated Maintenance**: Schedule and execute maintenance operations

### Extension Pattern

To add a new DBA task:

1. Create `commands/snf_<task_name>.py` with argparse CLI (must start with `snf_` prefix)
2. Add task logic as functions in `core/engine.py`
3. Use `@trace` decorator for automatic logging
4. Document the command in this file under the relevant section
5. Test with `--help` flag and validate all argument combinations

### Coding Standards for New Commands

- Follow existing argparse pattern from `commands/snf_template_command.py`
- All business logic in `core/engine.py`, command scripts are thin wrappers
- Use `core/connection.py` for all Snowflake connectivity
- Use `core/logger.py` for all logging (never use `print()`)
- Handle exceptions gracefully with proper ERRO/SEVR logging
- Return meaningful exit codes (0=success, 1=error, 2=invalid input)
- **File Naming**: All command/script files MUST start with `snf_` prefix (e.g., `snf_access_provision.py`, `snf_test_connection.py`).
- **Fully Qualified Object Names**: All SQL commands throughout the framework MUST use fully qualified `<DBNAME>.<SCHEMA>.<OBJECT>` names wherever applicable. This applies to all object references including metadata table reads, GRANT statements, USE commands, SHOW commands, and any other SQL operations. Never rely on session context for object resolution.
- **SQL Command Logging**: Every SQL command executed MUST be printed to the log file along with its output (columns and rows). This is enforced via `Engine.execute_sql()` which logs the SQL statement before execution and the full result set after execution. This rule applies to all current and future commands/enhancements.
- **Audit Logging**: Every SQL command executed via `Engine.execute_sql()` MUST be inserted into the `SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG` table in the metadata schema. The audit INSERT must NOT be printed to the log file. Audit logging is best-effort — failures do not disrupt the main execution flow. This rule applies to all current and future commands/enhancements.
- **Console Output**: Every command script MUST print high-level/major task progress to stdout (console) so users can monitor execution progress in real-time (especially in CI/CD pipelines). This is implemented via `Engine.console_msg(message)` which prints `  >> <message>` to stdout. Each command script also prints a header (command name, parameters) and footer (COMPLETED SUCCESSFULLY) banner. Console output does NOT replace or affect file logging or audit trail — both continue to function independently. This rule applies to all current and future commands/enhancements.

---

## Implemented Commands

### Access Provision (`commands/snf_access_provision.py`)

**Purpose**: Provisions access/grants on a database and all its objects by creating and configuring database roles with appropriate privilege levels and granting them to account roles.

**Script**: `commands/snf_access_provision.py`
**Engine Methods**: `Engine.provision_database_access()`, `Engine.execute_sql()`

#### CLI Usage

```
python commands/snf_access_provision.py --connection <conn_name> --database <database_name> --db-type <APP_DB|BKP_DB>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--database` | Yes | Database name to provision access on |
| `--db-type` | Yes | Type of database. Accepts only: `APP_DB` or `BKP_DB` |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='ACCESS_PROVISION' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Read ACCESS_TO_ROLES**: Query `<META_DB>.<META_SCHEMA>.ACCESS_TO_ROLES` with filter `DATABASE_TYPE=<input db-type>`. Stores resultset for later iteration.
3. **Verify Database Exists**: Executes `SHOW DATABASES LIKE '<DBNAME>'`. If no results, terminates with error.
4. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>` from TASK_TO_ROLE_MAP. Fails on error.
5. **Switch Database**: Executes `USE DATABASE <DBNAME>`. Fails on error.
6. **Determine Required Access Levels**: Inspects the `ACCESS_TO_BE_GRANTED` values from the `ACCESS_TO_ROLES` resultset to determine which database role privilege levels are needed. Only the required levels are provisioned:
   - `needs_ro` = true if any of: RO, RW, ADMIN, SRV_RO, SRV_RW, SRV_RWD, SRV_RWDC
   - `needs_rw` = true if any of: RW, ADMIN, SRV_RW, SRV_RWD, SRV_RWDC
   - `needs_rwd` = true if any of: ADMIN, SRV_RWD, SRV_RWDC
   - `needs_c` = true if any of: ADMIN, SRV_RWDC
   
   For example, if `BKP_DB` only has `RO` entries in ACCESS_TO_ROLES, only read-only access is granted — no RW/RWD/C privileges are provisioned.

7. **Grant Read-Only Access** (only if `needs_ro`) to database role `<DBNAME>.<DBNAME>_ALL_R`:
   - USAGE ON DATABASE
   - USAGE ON ALL/FUTURE SCHEMAS
   - SELECT ON ALL/FUTURE TABLES
   - SELECT ON ALL/FUTURE EXTERNAL TABLES
   - SELECT ON ALL/FUTURE VIEWS
   - SELECT ON ALL/FUTURE DYNAMIC TABLES
   - SELECT ON ALL/FUTURE MATERIALIZED VIEWS
   - REFERENCES ON ALL/FUTURE TABLES
   - REFERENCES ON ALL/FUTURE EXTERNAL TABLES
   - REFERENCES ON ALL/FUTURE VIEWS
   - REFERENCES ON ALL/FUTURE MATERIALIZED VIEWS
   - Note: REFERENCES is not supported on DYNAMIC TABLES in Snowflake.
   - SELECT ON ALL/FUTURE STREAMS
   - Note: USAGE on SEQUENCES, FUNCTIONS, PROCEDURES is excluded from this role.
8. **Grant Read-Write Access** (only if `needs_rw`) to database role `<DBNAME>.<DBNAME>_ALL_RW`:
   - INSERT ON ALL/FUTURE TABLES
   - UPDATE ON ALL/FUTURE TABLES
   - Note: Views are explicitly excluded from INSERT/UPDATE grants.
9. **Grant Read-Write-Delete Access** (only if `needs_rwd`) to database role `<DBNAME>.<DBNAME>_ALL_RWD`:
   - DELETE ON ALL/FUTURE TABLES
   - TRUNCATE ON ALL/FUTURE TABLES
   - USAGE ON ALL/FUTURE SEQUENCES
   - Note: Views are explicitly excluded from DELETE grants.
10. **Grant Create Access** (only if `needs_c`) to database role `<DBNAME>.<DBNAME>_ALL_C`:
   - CREATE SCHEMA ON DATABASE
   - CREATE DYNAMIC TABLE ON ALL/FUTURE SCHEMAS
   - CREATE FILE FORMAT ON ALL/FUTURE SCHEMAS
   - CREATE FUNCTION ON ALL/FUTURE SCHEMAS
   - CREATE PIPE ON ALL/FUTURE SCHEMAS
   - CREATE PROCEDURE ON ALL/FUTURE SCHEMAS
   - CREATE SEQUENCE ON ALL/FUTURE SCHEMAS
   - CREATE STAGE ON ALL/FUTURE SCHEMAS
   - CREATE STREAM ON ALL/FUTURE SCHEMAS
   - CREATE TABLE ON ALL/FUTURE SCHEMAS
   - CREATE TASK ON ALL/FUTURE SCHEMAS
   - CREATE VIEW ON ALL/FUTURE SCHEMAS
11. **Setup Role Hierarchy** (conditional — only sets up hierarchy for provisioned levels):
    - `GRANT DATABASE ROLE <DBNAME>.<DBNAME>_ALL_R TO DATABASE ROLE <DBNAME>.<DBNAME>_ALL_RW` (only if `needs_rw` and `needs_ro`)
    - `GRANT DATABASE ROLE <DBNAME>.<DBNAME>_ALL_RW TO DATABASE ROLE <DBNAME>.<DBNAME>_ALL_RWD` (only if `needs_rwd` and `needs_rw`)
    - `GRANT DATABASE ROLE <DBNAME>.<DBNAME>_ALL_C TO ROLE <DBNAME>_ADMIN` (only if `needs_c`)
    - `GRANT DATABASE ROLE <DBNAME>.<DBNAME>_ALL_RWD TO ROLE <DBNAME>_ADMIN` (only if `needs_rwd`)
    - Note: `<DBNAME>_ADMIN` is an account-level role, not a database role.
12. **Grant Access per ACCESS_TO_ROLES**: Iterates resultset and maps `ACCESS_TO_BE_GRANTED` values:

    | ACCESS_TO_BE_GRANTED | Action |
    |---------------------|--------|
    | `RO` | Grant `<DBNAME>.<DBNAME>_ALL_R` database role to the specified role |
    | `RW` | Grant `<DBNAME>.<DBNAME>_ALL_RW` database role to the specified role |
    | `ADMIN` | Grant `<DBNAME>_ADMIN` account role to the specified role |
    | `SRV_RO` | Grant `<DBNAME>.<DBNAME>_ALL_R` database role to the specified role |
    | `SRV_RW` | Grant `<DBNAME>.<DBNAME>_ALL_RW` database role to the specified role |
    | `SRV_RWD` | Grant `<DBNAME>.<DBNAME>_ALL_RWD` database role to the specified role |
    | `SRV_RWDC` | Grant `<DBNAME>.<DBNAME>_ALL_RWD` and `<DBNAME>.<DBNAME>_ALL_C` database roles to the specified role |
    | `SRV_ADMIN` | Grant `<DBNAME>_ADMIN` account role to the specified role |

    If `ACCESS_TO_BE_GRANTED` contains any value not in the above list, the script terminates immediately with an error.

#### Metadata Tables Required

**TASK_TO_ROLE_MAP** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `TASK_TYPE` | Task identifier (filter: `ACCESS_PROVISION`) |
| `ROLE_TO_BE_USED` | Snowflake role to switch to for executing grants |
| `STATUS` | Record status (filter: `ACTIVE`) |

**ACCESS_TO_ROLES** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `ROLE_NAME` | Target Snowflake role to receive access |
| `ACCESS_TO_BE_GRANTED` | Access level: RO, RW, ADMIN, SRV_RO, SRV_RW, SRV_RWD, SRV_RWDC, SRV_ADMIN |
| `DATABASE_TYPE` | Filter by database type: APP_DB or BKP_DB |

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Database Creation (`commands/snf_create_database.py`)

**Purpose**: Creates a standard database in Snowflake with full role setup and access provisioning as per customer standards. Orchestrates database role creation, account role creation, and access provisioning in a single workflow.

**Script**: `commands/snf_create_database.py`
**Engine Methods**: `Engine.create_database()`, `Engine.create_database_roles()`, `Engine.create_database_account_role()`, `Engine.provision_database_access()`

#### CLI Usage

```
python commands/snf_create_database.py --connection <conn_name> --database <database_name> --drop-flag <YES|NO> --db-type <APP_DB|BKP_DB>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--database` | Yes | Database name to create |
| `--drop-flag` | Yes | Whether to drop and re-create if database already exists. Accepts: `YES` or `NO` |
| `--db-type` | Yes | Type of database for access provisioning. Accepts: `APP_DB` or `BKP_DB` |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='DB_CREATION' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
3. **Check Database Existence**: Executes `SHOW DATABASES LIKE '<DBNAME>'`.
4. **Handle DROP_FLAG Logic**:
   - If database exists AND `DROP_FLAG=YES`: First drop the account role `<DBNAME>_ADMIN` by calling `Engine.drop_database_account_role()` (while DB still exists), then switch back to `DB_CREATION` role (`USE ROLE <ROLE_TO_BE_USED>`), then drop database (`DROP DATABASE <DBNAME>`), then create (`CREATE DATABASE <DBNAME>`). All steps must succeed or the script fails entirely.
   - If database exists AND `DROP_FLAG=NO`: Terminate with error — "Database already exists and DROP_FLAG is not enabled."
   - If database does NOT exist (regardless of DROP_FLAG): Create database (`CREATE DATABASE <DBNAME>`).
5. **Switch Database**: Executes `USE DATABASE <DBNAME>`. Fails on error.
6. **Create DBAALL Schema and Drop PUBLIC Schema**: Executes `CREATE SCHEMA <DBNAME>.DBAALL` followed by `DROP SCHEMA <DBNAME>.PUBLIC`. Fails on error.
7. **Create Database Roles**: Calls `Engine.create_database_roles()` which independently reads `TASK_TO_ROLE_MAP` with `TASK_TYPE='DATABASE_ROLE_CREATION'` and switches to appropriate role. Creates: `<DBNAME>_ALL_R`, `<DBNAME>_ALL_RW`, `<DBNAME>_ALL_RWD`, `<DBNAME>_ALL_C`.
8. **Create Account Role**: Calls `Engine.create_database_account_role()` which independently reads `TASK_TO_ROLE_MAP` with `TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION'` and switches to appropriate role. Creates: `<DBNAME>_ADMIN`.
9. **Provision Access**: Calls `Engine.provision_database_access()` which independently reads `TASK_TO_ROLE_MAP` with `TASK_TYPE='ACCESS_PROVISION'` and switches to appropriate role. Grants all privileges per `ACCESS_TO_ROLES` metadata table.

#### Metadata Tables Required

**TASK_TO_ROLE_MAP** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `TASK_TYPE` | Task identifier (filter: `DB_CREATION`) |
| `ROLE_TO_BE_USED` | Snowflake role to switch to for database creation |
| `STATUS` | Record status (filter: `ACTIVE`) |

Note: Sub-steps also require their own `TASK_TO_ROLE_MAP` entries: `DATABASE_ROLE_CREATION`, `DATABASE_SFACCOUNT_ROLE_CREATION`, `ACCESS_PROVISION`.

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE, DROP DATABASE, CREATE DATABASE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Create Database Roles (`commands/snf_create_db_roles.py`)

**Purpose**: Creates the four standard database roles for a given database as per customer standards.

**Script**: `commands/snf_create_db_roles.py`
**Engine Methods**: `Engine.create_database_roles()`

#### CLI Usage

```
python commands/snf_create_db_roles.py --connection <conn_name> --database <database_name>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--database` | Yes | Database name to create roles for |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='DATABASE_ROLE_CREATION' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Verify Database Exists**: Executes `SHOW DATABASES LIKE '<DBNAME>'`. If no results, terminates with error.
3. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
4. **Switch Database**: Executes `USE DATABASE <DBNAME>`. Fails on error.
5. **Create Database Roles**: Executes `CREATE DATABASE ROLE IF NOT EXISTS` for each:
   - `<DBNAME>.<DBNAME>_ALL_R`
   - `<DBNAME>.<DBNAME>_ALL_RW`
   - `<DBNAME>.<DBNAME>_ALL_RWD`
   - `<DBNAME>.<DBNAME>_ALL_C`

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Create Database Account Role (`commands/snf_create_db_account_role.py`)

**Purpose**: Creates the default account-level role for a given database as per customer standards.

**Script**: `commands/snf_create_db_account_role.py`
**Engine Methods**: `Engine.create_database_account_role()`

#### CLI Usage

```
python commands/snf_create_db_account_role.py --connection <conn_name> --database <database_name>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--database` | Yes | Database name to create the account role for |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='DATABASE_SFACCOUNT_ROLE_CREATION' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Verify Database Exists**: Executes `SHOW DATABASES LIKE '<DBNAME>'`. If no results, terminates with error.
3. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
4. **Switch Database**: Executes `USE DATABASE <DBNAME>`. Fails on error.
5. **Create Account Role**: Executes `CREATE ROLE IF NOT EXISTS <DBNAME>_ADMIN`.

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Drop Database Account Role (`commands/snf_drop_db_account_role.py`)

**Purpose**: Drops the default account-level role for a given database.

**Script**: `commands/snf_drop_db_account_role.py`
**Engine Methods**: `Engine.drop_database_account_role()`

#### CLI Usage

```
python commands/snf_drop_db_account_role.py --connection <conn_name> --database <database_name>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--database` | Yes | Database name to drop the account role for |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='DATABASE_SFACCOUNT_ROLE_DROP' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Verify Database Exists**: Executes `SHOW DATABASES LIKE '<DBNAME>'`. If no results, terminates with error.
3. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
4. **Switch Database**: Executes `USE DATABASE <DBNAME>`. Fails on error.
5. **Drop Account Role**: Executes `DROP ROLE IF EXISTS <DBNAME>_ADMIN`.

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Clone Database (`commands/snf_clone_database.py`)

**Purpose**: Clones a source database to a target database in Snowflake, then sets up standard database roles, account role, and access provisioning on the target database.

**Script**: `commands/snf_clone_database.py`
**Engine Methods**: `Engine.clone_database()`, `Engine.drop_database_roles_by_prefix()`, `Engine.create_database_roles()`, `Engine.create_database_account_role()`, `Engine.provision_database_access()`

#### CLI Usage

```
python commands/snf_clone_database.py --connection <conn_name> --source-database <source_db> --target-database <target_db> --drop-flag <YES|NO> --db-type <APP_DB|BKP_DB>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--source-database` | Yes | Source database name to clone from |
| `--target-database` | Yes | Target database name to clone into |
| `--drop-flag` | Yes | Whether to drop the target database if it already exists. Accepts: `YES` or `NO` |
| `--db-type` | Yes | Type of database for access provisioning. Accepts: `APP_DB` or `BKP_DB` |

#### Execution Flow

1. **Validate Source != Target**: If source and target database names are the same (case-insensitive), terminate immediately with error — "Cannot clone a database to itself."
2. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='DATABASE_CLONE' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
3. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
4. **Verify Source Database Exists**: Executes `SHOW DATABASES LIKE '<SOURCE_DB>'`. If no results, terminates with error.
5. **Check Target Database Existence**: Executes `SHOW DATABASES LIKE '<TARGET_DB>'`.
6. **Handle Drop Target Flag Logic**:
   - If target exists AND `DROP_FLAG=YES`: Drop account role `<TARGET_DB>_ADMIN` via `Engine.drop_database_account_role()`, switch back to `DATABASE_CLONE` role, then `DROP DATABASE <TARGET_DB>`.
   - If target exists AND `DROP_FLAG=NO`: Terminate with error — "Target database already exists and DROP_FLAG is not enabled."
   - If target does NOT exist (regardless of DROP_FLAG): Proceed with clone.
7. **Clone Database**: Executes `CREATE DATABASE <TARGET_DB> CLONE <SOURCE_DB>`.
8. **Switch to Target Database**: Executes `USE DATABASE <TARGET_DB>`. Fails on error.
9. **Drop Cloned Source Database Roles**: Calls `Engine.drop_database_roles_by_prefix()` which executes `SHOW DATABASE ROLES IN DATABASE <TARGET_DB>`, then drops all roles matching `<SOURCE_DB>_ALL_%` pattern.
10. **Create Database Roles**: Calls `Engine.create_database_roles()` for the target database. Creates: `<TARGET_DB>_ALL_R`, `<TARGET_DB>_ALL_RW`, `<TARGET_DB>_ALL_RWD`, `<TARGET_DB>_ALL_C`.
11. **Create Account Role**: Calls `Engine.create_database_account_role()` for the target database. Creates: `<TARGET_DB>_ADMIN`.
12. **Provision Access**: Calls `Engine.provision_database_access()` for the target database with the specified db-type. Grants all privileges per `ACCESS_TO_ROLES` metadata table.

#### Future Enhancements

- **Cross-Region Object References**: After cloning, objects in the target database that reference other region/source databases (e.g., views, stored procedures, streams, tasks referencing fully qualified names from the source region) need to be re-pointed to the current/target region databases. This is not yet implemented and is documented here for future development.

#### Metadata Tables Required

**TASK_TO_ROLE_MAP** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `TASK_TYPE` | Task identifier (filter: `DATABASE_CLONE`) |
| `ROLE_TO_BE_USED` | Snowflake role to switch to for clone operations |
| `STATUS` | Record status (filter: `ACTIVE`) |

Note: Sub-steps also require their own `TASK_TO_ROLE_MAP` entries: `DATABASE_SFACCOUNT_ROLE_DROP`, `DATABASE_ROLE_CREATION`, `DATABASE_SFACCOUNT_ROLE_CREATION`, `ACCESS_PROVISION`.

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE, DROP DATABASE, CREATE DATABASE CLONE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Clone Schema (`commands/snf_clone_schema.py`)

**Purpose**: Clones a source schema to a target schema in Snowflake, transfers ownership of all cloned objects to SYSADMIN, and provisions access on the target database.

**Script**: `commands/snf_clone_schema.py`
**Engine Methods**: `Engine.clone_schema()`, `Engine.transfer_schema_objects_ownership()`, `Engine.provision_database_access()`

#### CLI Usage

```
python commands/snf_clone_schema.py --connection <conn_name> --source-database <source_db> --source-schema <source_schema> --target-database <target_db> --target-schema <target_schema> --drop-target <YES|NO> --db-type <APP_DB|BKP_DB>
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--source-database` | Yes | Source database name containing the schema to clone |
| `--source-schema` | Yes | Source schema name to clone from |
| `--target-database` | Yes | Target database name where schema will be cloned |
| `--target-schema` | Yes | Target schema name to clone into |
| `--drop-target` | Yes | Whether to drop the target schema if it already exists. Accepts: `YES` or `NO` |
| `--db-type` | Yes | Type of target database for access provisioning. Accepts: `APP_DB` or `BKP_DB` |
| `--pipeline-id` | No | Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline) |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='SCHEMA_CLONE' AND STATUS='ACTIVE' AND CONNECTION_NAME='<connection>'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
3. **Validate Source Database Exists**: Executes `SHOW DATABASES LIKE '<SOURCE_DB>'`. If no results, terminates with error.
4. **Validate Source Schema Exists**: Executes `SHOW SCHEMAS LIKE '<SOURCE_SCHEMA>' IN DATABASE <SOURCE_DB>`. If no results, terminates with error.
5. **Validate Target Database Exists**: Executes `SHOW DATABASES LIKE '<TARGET_DB>'`. If no results, terminates with error.
6. **Check Target Schema Existence**: Executes `SHOW SCHEMAS LIKE '<TARGET_SCHEMA>' IN DATABASE <TARGET_DB>`.
7. **Switch to Target Database**: Executes `USE DATABASE <TARGET_DB>`. Fails on error.
8. **Handle Drop Target Flag Logic**:
   - If target schema exists AND `DROP_TARGET=YES`: Executes `DROP SCHEMA <TARGET_DB>.<TARGET_SCHEMA>`.
   - If target schema exists AND `DROP_TARGET=NO`: Terminates with error — "Target schema already exists and DROP_TARGET flag is not enabled."
   - If target schema does NOT exist (regardless of DROP_TARGET): Proceed with clone.
9. **Clone Schema**: Executes `CREATE SCHEMA <TARGET_DB>.<TARGET_SCHEMA> CLONE <SOURCE_DB>.<SOURCE_SCHEMA>`.
10. **Transfer Ownership to SYSADMIN**: Calls `Engine.transfer_schema_objects_ownership()` which:
    - Lists all objects in the schema (tables, views, materialized views, procedures, functions, sequences, stages, file formats, streams, tasks, pipes)
    - For each object found: `GRANT OWNERSHIP ON <OBJECT_TYPE> <FQ_NAME> TO ROLE SYSADMIN`
    - Finally: `GRANT OWNERSHIP ON SCHEMA <TARGET_DB>.<TARGET_SCHEMA> TO ROLE SYSADMIN`
    - Note: Ownership is transferred WITHOUT copying current grants
11. **Provision Access**: Calls `Engine.provision_database_access()` for the target database with the specified db-type. Grants all privileges per `ACCESS_TO_ROLES` metadata table.

#### Transfer Ownership Object Types

The `transfer_schema_objects_ownership()` method handles the following object types:

| Object Type | SHOW Command | Ownership Grant |
|-------------|--------------|-----------------|
| Tables | `SHOW TABLES IN SCHEMA` | `GRANT OWNERSHIP ON TABLE` |
| Views | `SHOW VIEWS IN SCHEMA` | `GRANT OWNERSHIP ON VIEW` |
| Materialized Views | `SHOW MATERIALIZED VIEWS IN SCHEMA` | `GRANT OWNERSHIP ON MATERIALIZED VIEW` |
| Procedures | `SHOW PROCEDURES IN SCHEMA` | `GRANT OWNERSHIP ON PROCEDURE` |
| Functions | `SHOW USER FUNCTIONS IN SCHEMA` | `GRANT OWNERSHIP ON FUNCTION` |
| Sequences | `SHOW SEQUENCES IN SCHEMA` | `GRANT OWNERSHIP ON SEQUENCE` |
| Stages | `SHOW STAGES IN SCHEMA` | `GRANT OWNERSHIP ON STAGE` |
| File Formats | `SHOW FILE FORMATS IN SCHEMA` | `GRANT OWNERSHIP ON FILE FORMAT` |
| Streams | `SHOW STREAMS IN SCHEMA` | `GRANT OWNERSHIP ON STREAM` |
| Tasks | `SHOW TASKS IN SCHEMA` | `GRANT OWNERSHIP ON TASK` |
| Pipes | `SHOW PIPES IN SCHEMA` | `GRANT OWNERSHIP ON PIPE` |

**Note**: For procedures and functions, the method attempts to extract argument signatures to properly identify overloaded routines.

#### Metadata Tables Required

**TASK_TO_ROLE_MAP** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `TASK_TYPE` | Task identifier (filter: `SCHEMA_CLONE`) |
| `ROLE_TO_BE_USED` | Snowflake role to switch to for schema clone operations |
| `STATUS` | Record status (filter: `ACTIVE`) |
| `CONNECTION_NAME` | Connection name filter |

Note: The `ACCESS_PROVISION` task entry is also required for the access provisioning step.

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE, DROP SCHEMA, CREATE SCHEMA CLONE)
- Exit code 0: Success
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

### Insert Data by Column Match (`commands/snf_insert_data_by_column_match.py`)

**Purpose**: Inserts data from a source table to a target table by matching column names. Handles column mapping, default values, nullable columns, and optional INSERT OVERWRITE for truncation.

**Script**: `commands/snf_insert_data_by_column_match.py`
**Engine Methods**: `Engine.insert_data_by_column_match()`

#### CLI Usage

```
python commands/snf_insert_data_by_column_match.py --connection <conn_name> \
    --source-database <source_db> --source-schema <source_schema> --source-table <source_table> \
    --target-database <target_db> --target-schema <target_schema> --target-table <target_table> \
    --truncate-target <YES|NO> [--source-filter <filter_condition>]
```

#### Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--connection` | Yes | Snowflake connection name from config |
| `--source-database` | Yes | Source database name |
| `--source-schema` | Yes | Source schema name |
| `--source-table` | Yes | Source table name |
| `--target-database` | Yes | Target database name |
| `--target-schema` | Yes | Target schema name |
| `--target-table` | Yes | Target table name |
| `--truncate-target` | Yes | Enable INSERT OVERWRITE to truncate target before insert. Accepts: `YES` or `NO` (default: `NO`) |
| `--source-filter` | No | Optional WHERE clause filter for source table (e.g., `"STATUS='ACTIVE'"`) |
| `--pipeline-id` | No | Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline) |

#### Execution Flow

1. **Read TASK_TO_ROLE_MAP**: Query `<META_DB>.<META_SCHEMA>.TASK_TO_ROLE_MAP` with filter `TASK_TYPE='INSERT_DATA_BY_COLUMN_MATCH' AND STATUS='ACTIVE'`. Must return exactly one record. Retrieves `ROLE_TO_BE_USED`.
2. **Switch Role**: Executes `USE ROLE <ROLE_TO_BE_USED>`. Fails on error.
3. **Validate Source Objects Exist**:
   - Executes `SHOW DATABASES LIKE '<SOURCE_DB>'`. If no results, terminates with error.
   - Executes `SHOW SCHEMAS LIKE '<SOURCE_SCHEMA>' IN DATABASE <SOURCE_DB>`. If no results, terminates with error.
   - Executes `SHOW TABLES LIKE '<SOURCE_TABLE>' IN <SOURCE_DB>.<SOURCE_SCHEMA>`. If no results, terminates with error.
4. **Validate Target Objects Exist**:
   - Same validation pattern for target database, schema, and table.
5. **Switch to Target Database**: Executes `USE DATABASE <TARGET_DB>`. Fails on error.
6. **Get Pre-Insert Row Counts**:
   - Source total count: `SELECT COUNT(*) FROM <SOURCE_FQN>`
   - Source filtered count (if filter): `SELECT COUNT(*) FROM <SOURCE_FQN> WHERE <FILTER>`
   - Target total count: `SELECT COUNT(*) FROM <TARGET_FQN>`
   - Target filtered count (if filter): `SELECT COUNT(*) FROM <TARGET_FQN> WHERE <FILTER>`
   - Prints all counts with appropriate messages.
7. **Validate Source Has Data**:
   - If source row count (with filter if applicable) = 0: Prints "No records to copy" and exits successfully (exit code 0).
8. **Validate Target State vs Truncate Flag**:
   - If target has data (filtered or total based on filter presence) AND `--truncate-target=NO`: Terminates with error — "Target table has existing data but truncate flag is not enabled."
9. **Get Column Metadata**:
   - Executes `DESCRIBE TABLE <SOURCE_FQN>` to get source columns (name, type, nullable, default).
   - Executes `DESCRIBE TABLE <TARGET_FQN>` to get target columns (name, type, nullable, default).
10. **Match Columns and Build INSERT Statement**:
    - For each target column (in target column order):
      - If column exists in source: Use source column value.
      - Else if target column has DEFAULT defined: Use `DEFAULT`.
      - Else if target column allows NULL: Use `NULL`.
      - Else (NOT NULL, no default, not in source): **Terminate with error** — "Target column is NOT NULL, has no default value, and does not exist in source table."
    - Note: Extra columns in source that don't exist in target are ignored (only target columns are inserted).
11. **Generate INSERT SQL**:
    - If `--truncate-target=YES`: `INSERT OVERWRITE INTO <TARGET_FQN> (<COL_LIST>) SELECT <MAPPED_COLS> FROM <SOURCE_FQN> [WHERE <FILTER>]`
    - Else: `INSERT INTO <TARGET_FQN> (<COL_LIST>) SELECT <MAPPED_COLS> FROM <SOURCE_FQN> [WHERE <FILTER>]`
12. **Execute INSERT**: Executes the generated INSERT SQL. Logged to audit table.
13. **Get Post-Insert Row Counts**:
    - Source total and filtered counts (should be unchanged).
    - Target total and filtered counts (should reflect inserted rows).
14. **Verify Row Counts**:
    - If filter is provided: Compares source filtered count vs target filtered count.
    - If no filter and `--truncate-target=YES`: Compares source total vs target total.
    - If no filter and `--truncate-target=NO`: Verifies rows inserted matches source count.
    - Prints SUCCESS or WARNING message based on match/mismatch.

#### Column Matching Rules

| Target Column State | Source Column Exists? | Action |
|--------------------|-----------------------|--------|
| Any | Yes | Use source column value |
| Has DEFAULT | No | Use `DEFAULT` |
| Nullable (allows NULL) | No | Use `NULL` |
| NOT NULL, no DEFAULT | No | **ERROR** - Cannot proceed |

#### Metadata Tables Required

**TASK_TO_ROLE_MAP** (in metadata database/schema):

| Column | Description |
|--------|-------------|
| `TASK_TYPE` | Task identifier (filter: `INSERT_DATA_BY_COLUMN_MATCH`) |
| `ROLE_TO_BE_USED` | Snowflake role to switch to for insert operations |
| `STATUS` | Record status (filter: `ACTIVE`) |
| `CONNECTION_NAME` | Connection name filter |

#### Error Handling

- Script terminates immediately on ANY SQL execution failure (including USE ROLE, USE DATABASE, INSERT)
- Exit code 0: Success (including when source has no records to copy)
- Exit code 1: Runtime/connection error
- Exit code 2: Input validation error (invalid parameters, missing connection)

---

## Audit Logging

### Table: `SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG`

Located in the metadata database/schema (`<META_DB>.<META_SCHEMA>.SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG`).

Every SQL command executed via `Engine.execute_sql()` is automatically inserted into this table.

#### Table Schema

| Column | Type | Description |
|--------|------|-------------|
| `TASK_ID` | NUMBER | Unique epoch timestamp generated once per script invocation; groups all audit records from one execution |
| `EXECUTED_AT` | TIMESTAMP | When the SQL query was executed (`CURRENT_TIMESTAMP()`) |
| `TASK_NAME` | VARCHAR | The python script/command that invoked the SQL query (e.g., `snf_access_provision.py`) |
| `USERNAME` | VARCHAR | User who executed the SQL query (`CURRENT_USER()`) |
| `ROLE_NAME` | VARCHAR | Role used for executing the SQL query (`CURRENT_ROLE()`) |
| `DATABASE_NAME` | VARCHAR | Database connected at time of execution (`CURRENT_DATABASE()`) |
| `WAREHOUSE_NAME` | VARCHAR | Warehouse used for execution (`CURRENT_WAREHOUSE()`) |
| `CMD` | VARCHAR | Full SQL query that was executed |
| `CMD_OUTPUT` | VARCHAR | Output/result of the SQL query (truncated at 10000 chars if too large) |
| `CMD_QUERY_ID` | VARCHAR | Snowflake query ID (`cursor.sfqid`) of the executed SQL command |
| `PIPELINE_ID` | VARCHAR | Azure DevOps pipeline Build ID (empty string when script is run manually, not via pipeline) |
| `SNF_CONNECTION` | VARCHAR | The connection name (from config) that the command script executed against (e.g., `SNF_DEV`, `SNF_QA`) |

#### Behavior Rules

1. **Automatic**: Audit logging happens automatically inside `Engine.execute_sql()` — no manual action needed by command scripts.
2. **Not Logged to File**: The audit INSERT itself must NOT appear in the log file.
3. **Best-Effort**: If the audit INSERT fails (e.g., table doesn't exist, permission denied), it is silently ignored. The main operation continues unaffected.
4. **No Recursion**: The audit INSERT does not trigger another audit record.
5. **All Commands**: This rule applies to ALL current and future commands/scripts in this framework.
6. **Fully Qualified**: The audit table is always referenced with its full path `<META_DB>.<META_SCHEMA>.SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG`.
7. **TASK_ID Generation**: A unique epoch timestamp in milliseconds (`int(time.time() * 1000)`) is generated once during `Engine.initialize()` and used as `TASK_ID` for all audit records in that invocation. This groups all SQL executions from a single script run under one identifier.
8. **CMD_QUERY_ID**: The Snowflake query ID (`cursor.sfqid`) is captured after each SQL execution in `execute_sql()` and stored in the audit record. The query ID extraction itself is NOT logged to the log file and does NOT trigger its own audit record to avoid recursion.
9. **PIPELINE_ID**: All command scripts accept an optional `--pipeline-id` CLI parameter. When the script is triggered by an Azure DevOps pipeline, the pipeline passes `--pipeline-id $(Build.BuildId)`. The value is stored in `Engine._pipeline_id` via `set_pipeline_id()` and included in every audit INSERT. When not provided (manual execution), the column is stored as an empty string.
10. **SNF_CONNECTION**: The connection name passed via `--connection` to the command script is recorded in the `SNF_CONNECTION` column of each audit record. This identifies which Snowflake account/environment the command executed against.
11. **Centralized Metadata Connection**: All metadata operations (audit writes, TASK_TO_ROLE_MAP reads, ACCESS_TO_ROLES reads) use the connection specified in `metadata.connection` in the config file — NOT the command's `--connection` parameter. This ensures all audit history and metadata configuration is centralized in one location. The command's `--connection` is used exclusively for executing the actual provisioning/DBA SQL commands.
12. **CONNECTION_NAME in Metadata Tables**: Both `TASK_TO_ROLE_MAP` and `ACCESS_TO_ROLES` include a `CONNECTION_NAME` column. All queries against these tables filter by `CONNECTION_NAME = '<connection_name>'` to support per-environment configuration (different roles/grants per Snowflake account).

---

## Request/Approval Workflow

### Overview

DBA tasks can be submitted through an Azure DevOps Pipeline form with a built-in approval gate. This provides a GUI-like experience for users to fill in required details, automated approval routing via MS Teams, and post-execution email notifications.

### Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  1. SUBMIT REQUEST                                               │
│     User clicks "Run Pipeline" in Azure DevOps                  │
│     → Fills form (connection, project, requestor, email)        │
│     → Submit stage: inserts record into request table           │
│       (uses metadata connection from dba_tasks_config.yaml)      │
│     → Status = SUBMITTED                                         │
└──────────────────────────┬──────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│  2. APPROVAL GATE (Azure DevOps Environment)                     │
│     Pipeline deploys to "DBA-APPROVAL" environment              │
│     → Approver receives notification in MS Teams (built-in ADO) │
│     → Approver clicks Approve/Reject in ADO or Teams            │
│     → On approve: updates request (approved_by, timestamp)      │
│     → Status = APPROVED                                          │
└──────────────────────────┬──────────────────────────────────────┘
                           │ (if APPROVED)
┌──────────────────────────▼──────────────────────────────────────┐
│  3. EXECUTE PIPELINE                                             │
│     Execute stage runs the actual DBA task script               │
│     → Updates request: pipeline_start_timestamp                 │
│     → Status = IN_PROGRESS                                       │
│     → Runs snf_test_connection.py (or other command)            │
└──────────────────────────┬──────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────────┐
│  4. COMPLETION & NOTIFICATION                                    │
│     → Updates request: pipeline_end_timestamp, final status     │
│     → Status = COMPLETED or FAILED                               │
│     → Sends email notification to requestor via SMTP            │
└─────────────────────────────────────────────────────────────────┘
```

### Components

| Component | Technology | Description |
|-----------|-----------|-------------|
| GUI/Form | Azure DevOps Pipeline Parameters | "Run Pipeline" form with typed parameters |
| Approval | Azure DevOps Environment Approvals | Environment check sends notification to Teams |
| Trigger | Azure DevOps Stages | Pipeline stages auto-advance after approval |
| Notification | Python SMTP | Email sent via SMTP after execution completes |

### Request Handler Script

**File**: `commands/snf_request_handler.py`

A multi-action script that manages the entire request lifecycle:

| Action | Description | Status Transition |
|--------|-------------|-------------------|
| `submit` | Insert new request record | → SUBMITTED |
| `approve` | Update with approval details | SUBMITTED → APPROVED |
| `start` | Mark pipeline execution started | APPROVED → IN_PROGRESS |
| `complete` | Mark completed/failed + send email | IN_PROGRESS → COMPLETED/FAILED |

**Usage**:
```bash
python commands/snf_request_handler.py --action submit \
    --request-table REQUESTS_SNF_TEST_CONNECTION \
    --project-name MY_PROJECT --connection-name SNF_DEV \
    --requestor "John Doe" --email-distribution "john@co.com" \
    --pipeline-id 12345
```

**Database Connection**: Uses the metadata connection from `dba_tasks_config.yaml` (`metadata.connection`) for all request table operations.

### Request Tables

#### REQUESTS_SNF_TEST_CONNECTION

| Column | Type | Description |
|--------|------|-------------|
| `REQUEST_ID` | NUMBER | Unique epoch timestamp (ms) generated at submission |
| `PROJECT_NAME` | VARCHAR | Project/team requesting the task |
| `CONNECTION_NAME` | VARCHAR | Snowflake connection to use for execution |
| `REQUESTOR` | VARCHAR | Person who submitted the request |
| `EMAIL_DISTRIBUTION` | VARCHAR | Comma-separated email addresses for notification |
| `REQUESTED_TIMESTAMP` | TIMESTAMP | When the request was submitted |
| `APPROVED_BY` | VARCHAR | Who approved the request |
| `APPROVAL_TIMESTAMP` | TIMESTAMP | When the request was approved |
| `PIPELINE_ID` | VARCHAR | Azure DevOps Build ID |
| `PIPELINE_START_TIMESTAMP` | TIMESTAMP | When pipeline execution started |
| `REQUEST_STATUS` | VARCHAR | Current status (SUBMITTED/APPROVED/IN_PROGRESS/COMPLETED/FAILED) |
| `PIPELINE_END_TIMESTAMP` | TIMESTAMP | When pipeline execution ended |

#### REQUESTS_APPROVER_BY_PROJECT

| Column | Type | Description |
|--------|------|-------------|
| `PROJECT_NAME` | VARCHAR | Project identifier |
| `APPROVER` | VARCHAR | Approver email/name |
| `STATUS` | VARCHAR | ACTIVE or INACTIVE |
| `PROJECT_START_TIMESTAMP` | TIMESTAMP | Project validity start date |
| `PROJECT_COMPLETION_TIMESTAMP` | TIMESTAMP | Project validity end date |

#### REQUESTS_SNF_DATABASE_CREATION

| Column | Type | Description |
|--------|------|-------------|
| `REQUEST_ID` | NUMBER | Unique epoch timestamp (ms) generated at submission |
| `PROJECT_NAME` | VARCHAR | Project/team requesting the task |
| `CONNECTION_NAME` | VARCHAR | Snowflake connection to use for execution |
| `DATABASE_NAME` | VARCHAR | Name of the database to create |
| `TARGET_DB_DROP` | VARCHAR | Whether to drop existing database (YES/NO) |
| `TARGET_DB_TYPE` | VARCHAR | Database type for access provisioning (APP_DB/BKP_DB) |
| `REQUESTOR` | VARCHAR | Person who submitted the request |
| `EMAIL_DISTRIBUTION` | VARCHAR | Comma-separated email addresses for notification |
| `REQUESTED_TIMESTAMP` | TIMESTAMP | When the request was submitted |
| `APPROVED_BY` | VARCHAR | Who approved the request |
| `APPROVAL_TIMESTAMP` | TIMESTAMP | When the request was approved |
| `PIPELINE_ID` | VARCHAR | Azure DevOps Build ID |
| `PIPELINE_START_TIMESTAMP` | TIMESTAMP | When pipeline execution started |
| `REQUEST_STATUS` | VARCHAR | Current status (SUBMITTED/APPROVED/IN_PROGRESS/COMPLETED/FAILED) |
| `PIPELINE_END_TIMESTAMP` | TIMESTAMP | When pipeline execution ended |

### Extra Fields Support

The `snf_request_handler.py` script supports an `--extra-fields` parameter for inserting table-specific columns beyond the base set. This allows the same handler script to be reused across different request types.

**Usage**:
```bash
python commands/snf_request_handler.py --action submit \
    --request-table REQUESTS_SNF_DATABASE_CREATION \
    --project-name MY_PROJECT --connection-name SNF_DEV \
    --requestor "John Doe" --email-distribution "john@co.com" \
    --pipeline-id 12345 \
    --extra-fields DATABASE_NAME=MY_DB TARGET_DB_DROP=NO TARGET_DB_TYPE=APP_DB
```

Each extra field is provided as `KEY=VALUE`. The key becomes the column name (uppercased), and the value is inserted as a VARCHAR.

### Request Pipelines

| Pipeline | Request Table | Script Executed |
|----------|--------------|-----------------|
| `snf-test-connection-request.yml` | REQUESTS_SNF_TEST_CONNECTION | `snf_test_connection.py` |
| `snf-create-database-request.yml` | REQUESTS_SNF_DATABASE_CREATION | `snf_create_database.py` |
| `snf-clone-database-request.yml` | REQUESTS_SNF_DATABASE_CLONE | `snf_clone_database.py` |

#### REQUESTS_SNF_DATABASE_CLONE

| Column | Type | Description |
|--------|------|-------------|
| `REQUEST_ID` | NUMBER | Unique epoch timestamp (ms) generated at submission |
| `PROJECT_NAME` | VARCHAR | Project/team requesting the task |
| `CONNECTION_NAME` | VARCHAR | Snowflake connection to use for execution |
| `SOURCE_DATABASE_NAME` | VARCHAR | Name of the source database to clone from |
| `TARGET_DATABASE_NAME` | VARCHAR | Name of the target database to clone into |
| `TARGET_DB_DROP` | VARCHAR | Whether to drop target database if exists (YES/NO) |
| `TARGET_DB_TYPE` | VARCHAR | Database type for access provisioning (APP_DB/BKP_DB) |
| `REQUESTOR` | VARCHAR | Person who submitted the request (auto-populated from pipeline executor) |
| `EMAIL_DISTRIBUTION` | VARCHAR | Comma-separated email addresses for notification |
| `REQUESTED_TIMESTAMP` | TIMESTAMP | When the request was submitted |
| `APPROVED_BY` | VARCHAR | Who approved the request |
| `APPROVAL_TIMESTAMP` | TIMESTAMP | When the request was approved |
| `PIPELINE_ID` | VARCHAR | Azure DevOps Build ID |
| `PIPELINE_START_TIMESTAMP` | TIMESTAMP | When pipeline execution started |
| `REQUEST_STATUS` | VARCHAR | Current status (SUBMITTED/APPROVED/IN_PROGRESS/COMPLETED/FAILED) |
| `PIPELINE_END_TIMESTAMP` | TIMESTAMP | When pipeline execution ended |

### Request Status Flow

```
SUBMITTED → APPROVED → IN_PROGRESS → COMPLETED
                                    → FAILED
SUBMITTED → REJECTED (if approver rejects in ADO)
```

### Pipeline Setup (One-Time)

#### Prerequisites

1. **Create Azure DevOps Environment**:
   - Go to Pipelines → Environments → New Environment
   - Name: `DBA-APPROVAL`
   - Resource: None

2. **Add Approval Check**:
   - Open `DBA-APPROVAL` environment → Approvals and Checks
   - Add "Approvals" check
   - Add approver(s) — they will receive MS Teams notifications automatically

3. **Configure SMTP Variables** (in ADO Variable Group `DBA-TASKS-SECRETS`):
   - `SMTP_SERVER` — SMTP relay hostname
   - `SMTP_PORT` — Port (default: 25)
   - `SMTP_FROM` — Sender email address

4. **Populate Approver Table**:
   ```sql
   INSERT INTO ZNAWUSERDB.DBAALL.REQUESTS_APPROVER_BY_PROJECT
   (PROJECT_NAME, APPROVER, STATUS, PROJECT_START_TIMESTAMP, PROJECT_COMPLETION_TIMESTAMP)
   VALUES ('MY_PROJECT', 'approver@company.com', 'ACTIVE', '2025-01-01', '2026-12-31');
   ```

### Email Notification

- Sent via SMTP after pipeline execution completes (both success and failure)
- Recipients: `EMAIL_DISTRIBUTION` field from the request
- Subject format: `[DBA Tasks] Request {STATUS} - Pipeline {PIPELINE_ID}`
- Best-effort: if SMTP fails, a warning is logged but the pipeline does NOT fail

---

## Version History

| Date | Change | Author |
|------|--------|--------|
| 2026-01-15 | Initial framework setup - configuration, logging, core engine, connection manager | Venkateswarlu Are |
| 2026-05-15 | Added Access Provision command (snf_access_provision.py) - database role grants automation | Venkateswarlu Are |
| 2026-05-15 | Added SQL command+output logging rule; expanded CREATE grants (DYNAMIC TABLE, FILE FORMAT, PIPE, STAGE) | Venkateswarlu Are |
| 2026-05-15 | RO role: added external tables, dynamic tables, REFERENCES; RW/RWD roles: removed view grants | Venkateswarlu Are |
| 2026-05-15 | Conditional provisioning: only grant privilege levels needed per ACCESS_TO_ROLES; changed APPLICATION_DB to APP_DB | Venkateswarlu Are |
| 2026-05-16 | Renamed all command files to snf_ prefix; added audit logging to SNF_DBA_TASKS_AUTOMATION_AUDIT_LOG | Venkateswarlu Are |
| 2026-05-16 | Added TASK_ID column to audit log — epoch timestamp generated per invocation to group all audit records from one script run | Venkateswarlu Are |
| 2026-05-16 | Added CMD_QUERY_ID column to audit log — captures Snowflake query ID (cursor.sfqid) for each executed command | Venkateswarlu Are |
| 2026-05-16 | Added Database Creation command (snf_create_database.py) — orchestrates DB creation, database roles, account role, and access provisioning | Venkateswarlu Are |
| 2026-05-16 | Added Drop Database Account Role command (snf_drop_db_account_role.py) — drops <DBNAME>_ADMIN account role | Venkateswarlu Are |
| 2026-05-16 | Added Clone Database command (snf_clone_database.py) — clones source DB to target with role cleanup and access provisioning | Venkateswarlu Are |
| 2026-05-29 | Added PIPELINE_ID column to audit log — optional --pipeline-id CLI parameter on all scripts, populated with Azure DevOps Build.BuildId when triggered by pipeline | Venkateswarlu Are |
| 2026-05-29 | Centralized metadata: added metadata.connection config, SNF_CONNECTION audit column, CONNECTION_NAME filter on TASK_TO_ROLE_MAP and ACCESS_TO_ROLES, new execute_metadata_sql() method | Venkateswarlu Are |
| 2026-05-29 | Request/Approval Workflow: ADO Environment approval gate, snf_request_handler.py, REQUESTS_SNF_TEST_CONNECTION and REQUESTS_APPROVER_BY_PROJECT tables, SMTP email notifications | Venkateswarlu Are |
| 2026-05-29 | Database Creation Request Workflow: REQUESTS_SNF_DATABASE_CREATION table, snf-create-database-request.yml pipeline, --extra-fields support in request handler | Venkateswarlu Are |
| 2026-05-29 | Database Clone Request Workflow: REQUESTS_SNF_DATABASE_CLONE table, snf-clone-database-request.yml pipeline | Venkateswarlu Are |
| 2026-06-09 | Added Insert Data by Column Match command (snf_insert_data_by_column_match.py) — inserts data from source to target table with column matching, default value handling, INSERT OVERWRITE support, and row count verification | Venkateswarlu Are |
| 2026-07-08 | Added Clone Schema command (snf_clone_schema.py) — clones source schema to target with ownership transfer to SYSADMIN and access provisioning; added reusable transfer_schema_objects_ownership() engine method | Venkateswarlu Are |
