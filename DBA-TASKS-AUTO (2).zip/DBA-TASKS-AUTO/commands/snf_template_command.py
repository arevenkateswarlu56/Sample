#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Template Command Script

This is a TEMPLATE showing the standard pattern for command scripts.
Copy this file and modify for each new DBA task command.

Usage:
    python template_command.py --help
    python template_command.py --connection prod_main --source SOURCE_DB --target TARGET_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.

    Pattern:
    - Group mandatory and optional arguments separately
    - Always include --connection as mandatory
    - Provide clear descriptions for each parameter
    """
    parser = argparse.ArgumentParser(
        prog="snf_template_command.py",
        description="Compares the Source and Target database Tables DDL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_template_command.py --connection prod_main --source SOURCE_DB --target TARGET_DB
  python snf_template_command.py --connection prod_main --source SOURCE_DB --target TARGET_DB --schema PUBLIC
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--source",
        required=True,
        metavar="source_db",
        help="Source database name for comparison",
    )
    mandatory.add_argument(
        "--target",
        required=True,
        metavar="target_db",
        help="Target database name for comparison",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--schema",
        required=False,
        metavar="schema_name",
        default=None,
        help="Specific schema to compare (default: all schemas)",
    )
    optional.add_argument(
        "--output",
        required=False,
        metavar="output_path",
        default=None,
        help="Path to write comparison results (default: stdout)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, source, target, schema=None, output=None):
    """
    Execute the command logic.

    This is where the actual task work happens. It calls into
    core/engine.py methods for all business logic.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        source: str - Source database.
        target: str - Target database.
        schema: str - Optional schema filter.
        output: str - Optional output file path.
    """
    logger = engine.logger

    logger.info(f"Starting comparison: {source} vs {target}")

    # Example: Get connection and execute queries
    # conn = engine.get_connection(connection_name)
    # results = engine.execute_query(connection_name, "SELECT ...")

    # TODO: Implement actual comparison logic in core/engine.py
    # and call it from here.

    logger.info(f"Comparison complete: {source} vs {target}")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the command script."""
    parser = build_parser()
    args = parser.parse_args()

    # Initialize engine
    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {"source": args.source, "target": args.target},
            ["source", "target"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            source=args.source,
            target=args.target,
            schema=args.schema,
            output=args.output,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
