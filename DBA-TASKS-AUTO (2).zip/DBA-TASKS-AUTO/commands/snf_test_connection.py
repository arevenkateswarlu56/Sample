#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Test Connection Command

Tests connectivity to a named Snowflake connection from the configuration.
Validates authentication and executes a simple query to confirm access.

Usage:
    python test_connection.py --connection SNF_DEV
    python test_connection.py --connection SNF_DEV --query "SELECT CURRENT_WAREHOUSE()"
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """Build the argument parser for test_connection."""
    parser = argparse.ArgumentParser(
        prog="snf_test_connection.py",
        description="Tests Snowflake connection using the configured authentication method",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_test_connection.py --connection SNF_DEV
  python snf_test_connection.py --connection SNF_DEV --query "SELECT CURRENT_ROLE()"
        """,
    )

    # Mandatory arguments
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )

    # Optional arguments
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--query",
        required=False,
        metavar="sql_query",
        default=None,
        help="Custom SQL query to execute for testing (default: runs standard validation queries)",
    )
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Connection Test Logic
# =============================================================================

@trace
def test_connection(engine, connection_name, custom_query=None):
    """
    Test a Snowflake connection by establishing it and running validation queries.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection name from config.
        custom_query: str - Optional custom SQL to run.
    """
    logger = engine.logger

    print(f"\n{'='*60}")
    print(f"  Testing Connection: {connection_name}")
    print(f"{'='*60}\n")

    # Get connection config details for display
    conn_cfg = engine.config["connections"][connection_name]
    print(f"  Account    : {conn_cfg.get('account', 'N/A')}")
    print(f"  User       : {conn_cfg.get('user', 'N/A')}")
    print(f"  Role       : {conn_cfg.get('role', 'N/A')}")
    print(f"  Warehouse  : {conn_cfg.get('warehouse', 'N/A')}")
    print(f"  Database   : {conn_cfg.get('database', 'N/A')}")
    print(f"  Schema     : {conn_cfg.get('schema', 'N/A')}")
    print(f"  Auth Method: {conn_cfg.get('auth_method', 'N/A')}")
    print(f"\n{'-'*60}")

    # Step 1: Establish connection
    print("\n  [1/3] Establishing connection...")
    logger.info(f"Testing connection: {connection_name}")

    conn = engine.get_connection(connection_name)
    print("        Connection established successfully.")
    logger.info(f"Connection '{connection_name}' established for testing")

    # Step 2: Run validation queries
    print("\n  [2/3] Running validation queries...")
    cursor = conn.cursor()

    validation_queries = [
        ("Current User", "SELECT CURRENT_USER()"),
        ("Current Role", "SELECT CURRENT_ROLE()"),
        ("Current Warehouse", "SELECT CURRENT_WAREHOUSE()"),
        ("Current Database", "SELECT CURRENT_DATABASE()"),
        ("Current Schema", "SELECT CURRENT_SCHEMA()"),
        ("Snowflake Version", "SELECT CURRENT_VERSION()"),
    ]

    print(f"\n  {'Label':<22} {'Result'}")
    print(f"  {'-'*22} {'-'*35}")

    for label, query in validation_queries:
        try:
            cursor.execute(query)
            result = cursor.fetchone()
            value = result[0] if result else "NULL"
            print(f"  {label:<22} {value}")
            logger.info(f"Validation query '{label}': {value}")
        except Exception as e:
            print(f"  {label:<22} ERROR: {str(e)}")
            logger.erro(f"Validation query '{label}' failed: {str(e)}")

    # Step 3: Run custom query if provided
    if custom_query:
        print(f"\n  [3/3] Running custom query...")
        print(f"        SQL: {custom_query}")
        logger.info(f"Executing custom test query: {custom_query}")

        try:
            cursor.execute(custom_query)
            results = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]

            print(f"\n  Columns: {', '.join(columns)}")
            print(f"  Rows returned: {len(results)}")

            if results:
                print(f"\n  {'  |  '.join(columns)}")
                print(f"  {'-'*50}")
                for row in results[:10]:  # Limit display to 10 rows
                    print(f"  {'  |  '.join(str(v) for v in row)}")
                if len(results) > 10:
                    print(f"  ... ({len(results) - 10} more rows)")

            logger.info(f"Custom query returned {len(results)} rows")
        except Exception as e:
            print(f"        ERROR: {str(e)}")
            logger.erro(f"Custom query failed: {str(e)}")
            raise
    else:
        print("\n  [3/3] No custom query specified (use --query to run one)")

    cursor.close()

    print(f"\n{'='*60}")
    print(f"  Connection Test: PASSED")
    print(f"{'='*60}\n")

    logger.info(f"Connection test PASSED for '{connection_name}'")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for connection test command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        test_connection(
            engine=engine,
            connection_name=connection_name,
            custom_query=args.query,
        )

    except ValueError as e:
        print(f"\nERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        print(f"\nCONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except Exception as e:
        print(f"\nUNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in test_connection: {str(e)}")
        exit_code = 1
    finally:
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
