#!/usr/bin/env python3
"""
snf_request_handler.py
=======================
Handles request lifecycle operations for DBA Tasks Automation.

Actions:
    submit   - Insert a new request record (status=SUBMITTED)
    approve  - Update request with approval info (status=APPROVED)
    start    - Update request with pipeline start (status=IN_PROGRESS)
    complete - Update request with completion and send email (status=COMPLETED/FAILED)

Usage:
    python snf_request_handler.py --action submit --request-table REQUESTS_SNF_TEST_CONNECTION \
        --project-name MY_PROJECT --connection-name SNF_DEV --requestor "John Doe" \
        --email-distribution "john@company.com" --pipeline-id 12345

    python snf_request_handler.py --action approve --request-table REQUESTS_SNF_TEST_CONNECTION \
        --pipeline-id 12345 --approved-by "Manager Name"

    python snf_request_handler.py --action start --request-table REQUESTS_SNF_TEST_CONNECTION \
        --pipeline-id 12345

    python snf_request_handler.py --action complete --request-table REQUESTS_SNF_TEST_CONNECTION \
        --pipeline-id 12345 --email-distribution "john@company.com" --status COMPLETED
"""

import argparse
import os
import sys
import time
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_request_handler.py",
        description="Handles request lifecycle operations for DBA Tasks Automation pipelines",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Actions:
  submit   - Insert a new request record into the request table
  approve  - Update request with approval details
  start    - Mark request as in-progress (pipeline started)
  complete - Mark request as completed/failed and send email notification
        """,
    )

    # Action (required)
    parser.add_argument(
        "--action",
        required=True,
        choices=["submit", "approve", "start", "complete"],
        help="Lifecycle action to perform",
    )

    # Request table name (required)
    parser.add_argument(
        "--request-table",
        required=True,
        metavar="table_name",
        help="Request table name (e.g., REQUESTS_SNF_TEST_CONNECTION)",
    )

    # Pipeline ID (required for all actions)
    parser.add_argument(
        "--pipeline-id",
        required=True,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID",
    )

    # Submit action parameters
    parser.add_argument(
        "--project-name",
        required=False,
        metavar="project_name",
        help="Project name (required for submit)",
    )
    parser.add_argument(
        "--connection-name",
        required=False,
        metavar="connection_name",
        help="Snowflake connection name (required for submit)",
    )
    parser.add_argument(
        "--requestor",
        required=False,
        metavar="requestor",
        help="Requestor name (required for submit)",
    )
    parser.add_argument(
        "--email-distribution",
        required=False,
        metavar="emails",
        help="Email distribution list, comma-separated (required for submit and complete)",
    )

    # Approve action parameters
    parser.add_argument(
        "--approved-by",
        required=False,
        metavar="approver",
        help="Name of the approver (required for approve)",
    )

    # Complete action parameters
    parser.add_argument(
        "--status",
        required=False,
        choices=["COMPLETED", "FAILED"],
        help="Final status (required for complete)",
    )

    # Extra fields for table-specific columns (e.g., DATABASE_NAME, TARGET_DB_DROP)
    parser.add_argument(
        "--extra-fields",
        required=False,
        nargs="*",
        metavar="KEY=VALUE",
        help="Additional columns as KEY=VALUE pairs (e.g., --extra-fields DATABASE_NAME=MY_DB TARGET_DB_DROP=NO TARGET_DB_TYPE=APP_DB)",
    )

    return parser


# =============================================================================
# Action Handlers
# =============================================================================

@trace
def action_submit(engine, args):
    """
    Insert a new request record into the request table.
    Status: SUBMITTED
    """
    # Validate required fields for submit
    if not args.project_name:
        raise ValueError("--project-name is required for submit action")
    if not args.connection_name:
        raise ValueError("--connection-name is required for submit action")
    if not args.requestor:
        raise ValueError("--requestor is required for submit action")
    if not args.email_distribution:
        raise ValueError("--email-distribution is required for submit action")

    meta_cfg = engine.config.get("metadata", {})
    meta_db = meta_cfg.get("database", "")
    meta_schema = meta_cfg.get("schema", "")
    fq_table = f"{meta_db}.{meta_schema}.{args.request_table.upper()}"

    # Generate request ID (epoch ms)
    request_id = int(time.time() * 1000)

    # Sanitize inputs
    safe_project = args.project_name.replace("'", "''")
    safe_connection = args.connection_name.replace("'", "''")
    safe_requestor = args.requestor.replace("'", "''")
    safe_email = args.email_distribution.replace("'", "''")
    safe_pipeline_id = str(args.pipeline_id).replace("'", "''")

    # Build base columns and values
    columns = ["REQUEST_ID", "PROJECT_NAME", "CONNECTION_NAME", "REQUESTOR", "EMAIL_DISTRIBUTION",
               "REQUESTED_TIMESTAMP", "PIPELINE_ID", "REQUEST_STATUS"]
    values = [str(request_id), f"'{safe_project}'", f"'{safe_connection}'", f"'{safe_requestor}'",
              f"'{safe_email}'", "CURRENT_TIMESTAMP()", f"'{safe_pipeline_id}'", "'SUBMITTED'"]

    # Parse and add extra fields (table-specific columns)
    if args.extra_fields:
        for field in args.extra_fields:
            if "=" not in field:
                raise ValueError(f"Invalid extra field format: '{field}'. Expected KEY=VALUE.")
            key, val = field.split("=", 1)
            safe_key = key.strip().upper()
            safe_val = val.strip().replace("'", "''")
            columns.append(safe_key)
            values.append(f"'{safe_val}'")

    insert_sql = (
        f"INSERT INTO {fq_table} "
        f"({', '.join(columns)}) "
        f"VALUES ({', '.join(values)})"
    )

    engine.execute_metadata_sql(insert_sql, "Insert request record")

    print(f"  >> Request submitted successfully.", flush=True)
    print(f"  >> Request ID: {request_id}", flush=True)
    print(f"  >> Pipeline ID: {args.pipeline_id}", flush=True)
    print(f"  >> Status: SUBMITTED", flush=True)

    return request_id


@trace
def action_approve(engine, args):
    """
    Update request record with approval details.
    Status: APPROVED
    """
    if not args.approved_by:
        raise ValueError("--approved-by is required for approve action")

    meta_cfg = engine.config.get("metadata", {})
    meta_db = meta_cfg.get("database", "")
    meta_schema = meta_cfg.get("schema", "")
    fq_table = f"{meta_db}.{meta_schema}.{args.request_table.upper()}"

    safe_approver = args.approved_by.replace("'", "''")
    safe_pipeline_id = str(args.pipeline_id).replace("'", "''")

    update_sql = (
        f"UPDATE {fq_table} SET "
        f"APPROVED_BY = '{safe_approver}', "
        f"APPROVAL_TIMESTAMP = CURRENT_TIMESTAMP(), "
        f"REQUEST_STATUS = 'APPROVED' "
        f"WHERE PIPELINE_ID = '{safe_pipeline_id}' "
        f"AND REQUEST_STATUS = 'SUBMITTED'"
    )

    engine.execute_metadata_sql(update_sql, "Update request - approved")

    print(f"  >> Request approved successfully.", flush=True)
    print(f"  >> Approved by: {args.approved_by}", flush=True)
    print(f"  >> Status: APPROVED", flush=True)


@trace
def action_start(engine, args):
    """
    Update request record to mark pipeline execution started.
    Status: IN_PROGRESS
    """
    meta_cfg = engine.config.get("metadata", {})
    meta_db = meta_cfg.get("database", "")
    meta_schema = meta_cfg.get("schema", "")
    fq_table = f"{meta_db}.{meta_schema}.{args.request_table.upper()}"

    safe_pipeline_id = str(args.pipeline_id).replace("'", "''")

    update_sql = (
        f"UPDATE {fq_table} SET "
        f"PIPELINE_START_TIMESTAMP = CURRENT_TIMESTAMP(), "
        f"REQUEST_STATUS = 'IN_PROGRESS' "
        f"WHERE PIPELINE_ID = '{safe_pipeline_id}' "
        f"AND REQUEST_STATUS = 'APPROVED'"
    )

    engine.execute_metadata_sql(update_sql, "Update request - in progress")

    print(f"  >> Request marked as IN_PROGRESS.", flush=True)
    print(f"  >> Pipeline execution started.", flush=True)


@trace
def action_complete(engine, args):
    """
    Update request record with completion details and send email notification.
    Status: COMPLETED or FAILED
    """
    if not args.status:
        raise ValueError("--status is required for complete action")

    meta_cfg = engine.config.get("metadata", {})
    meta_db = meta_cfg.get("database", "")
    meta_schema = meta_cfg.get("schema", "")
    fq_table = f"{meta_db}.{meta_schema}.{args.request_table.upper()}"

    safe_pipeline_id = str(args.pipeline_id).replace("'", "''")
    final_status = args.status.upper()

    update_sql = (
        f"UPDATE {fq_table} SET "
        f"PIPELINE_END_TIMESTAMP = CURRENT_TIMESTAMP(), "
        f"REQUEST_STATUS = '{final_status}' "
        f"WHERE PIPELINE_ID = '{safe_pipeline_id}' "
        f"AND REQUEST_STATUS = 'IN_PROGRESS'"
    )

    engine.execute_metadata_sql(update_sql, "Update request - complete")

    print(f"  >> Request marked as {final_status}.", flush=True)
    print(f"  >> Pipeline execution finished.", flush=True)

    # Send email notification
    if args.email_distribution:
        send_email_notification(engine, args, final_status)


# =============================================================================
# Email Notification
# =============================================================================

def send_email_notification(engine, args, status):
    """
    Send email notification to the requestor/distribution list via SMTP.

    SMTP configuration is read from dba_tasks_config.yaml under the 'smtp' section:
        smtp.server       - SMTP server hostname
        smtp.port         - SMTP server port (default: 25)
        smtp.from_address - Sender email address
    """
    smtp_cfg = engine.config.get("smtp", {})
    smtp_server = smtp_cfg.get("server", "")
    smtp_port = int(smtp_cfg.get("port", "25"))
    smtp_from = smtp_cfg.get("from_address", "")

    if not smtp_server:
        print("  >> WARNING: SMTP_SERVER not configured. Email notification skipped.", flush=True)
        return

    recipients = [email.strip() for email in args.email_distribution.split(",") if email.strip()]
    if not recipients:
        print("  >> WARNING: No valid email recipients. Email notification skipped.", flush=True)
        return

    # Build email
    subject = f"[DBA Tasks] Request {status} - Pipeline {args.pipeline_id}"

    body = f"""
DBA Tasks Automation - Request Notification
============================================

Status:       {status}
Pipeline ID:  {args.pipeline_id}
Request Table: {args.request_table}

This is an automated notification from the DBA Tasks Automation framework.
The pipeline execution has {status.lower()}.

---
DBA Tasks Automation Team
"""

    msg = MIMEMultipart()
    msg["From"] = smtp_from
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.sendmail(smtp_from, recipients, msg.as_string())
        print(f"  >> Email notification sent to: {', '.join(recipients)}", flush=True)
    except Exception as e:
        # Email is best-effort; don't fail the pipeline
        print(f"  >> WARNING: Email notification failed: {str(e)}", flush=True)


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """
    Main entry point for the request handler.
    """
    print("", flush=True)
    print("========================================", flush=True)
    print("  DBA Tasks - Request Handler", flush=True)
    print("========================================", flush=True)

    parser = build_parser()
    args = parser.parse_args()

    # Initialize engine (uses metadata connection for all operations)
    engine = Engine()
    engine.initialize()

    try:
        action = args.action.lower()

        if action == "submit":
            action_submit(engine, args)
        elif action == "approve":
            action_approve(engine, args)
        elif action == "start":
            action_start(engine, args)
        elif action == "complete":
            action_complete(engine, args)
        else:
            raise ValueError(f"Unknown action: {action}")

    except Exception as e:
        print(f"  >> ERROR: {str(e)}", flush=True)
        engine.logger.erro(f"Request handler failed: {str(e)}")
        sys.exit(1)
    finally:
        engine.shutdown()

    print("========================================", flush=True)
    print("  Request Handler - Done", flush=True)
    print("========================================", flush=True)


if __name__ == "__main__":
    main()
