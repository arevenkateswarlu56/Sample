#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Create Database Account Role Command

Creates the default account-level role for a given database as per customer standards:
  <DBNAME>_ADMIN - Admin account role for the database

Usage:
    python snf_create_db_account_role.py --connection SNF_DEV --database MY_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_create_db_account_role.py",
        description="Creates the default account-level role for a database as per customer standards",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_create_db_account_role.py --connection SNF_DEV --database MY_APP_DB
  python snf_create_db_account_role.py --connection SNF_QA --database MY_BKP_DB
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--database",
        required=True,
        metavar="database_name",
        help="Database name to create the default account role for",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, database_name):
    """
    Execute the create database account role command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        database_name: str - Database to create the account role for.
    """
    logger = engine.logger

    print(f"\n{'='*60}")
    print(f"  Create Database Account Role")
    print(f"  Database: {database_name} | Connection: {connection_name}")
    print(f"{'='*60}\n")

    logger.info(
        f"Starting account role creation for database '{database_name}'"
    )

    engine.create_database_account_role(
        connection_name=connection_name,
        database_name=database_name,
    )

    logger.info(
        f"Account role creation completed for database '{database_name}'"
    )

    print(f"\n{'='*60}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*60}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the create database account role command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {"database": args.database},
            ["database"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            database_name=args.database,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in create_db_account_role: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in create_db_account_role: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
