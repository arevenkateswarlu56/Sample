#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Clone Schema Command

Clones a source schema to a target schema in Snowflake, transfers ownership
of all objects to SYSADMIN, and provisions access on the target database.

Orchestrates:
  1. Clone source schema to target schema
  2. Transfer ownership of all schema objects to SYSADMIN
  3. Provision access on target database

Usage:
    python snf_clone_schema.py --connection SNF_DEV --source-database SRC_DB --source-schema SRC_SCHEMA --target-database TGT_DB --target-schema TGT_SCHEMA --drop-target YES --db-type APP_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_clone_schema.py",
        description="Clones a source schema to a target schema with ownership transfer and access provisioning",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_clone_schema.py --connection SNF_DEV --source-database PROD_DB --source-schema PUBLIC --target-database DEV_DB --target-schema PUBLIC_CLONE --drop-target NO --db-type APP_DB
  python snf_clone_schema.py --connection SNF_DEV --source-database PROD_DB --source-schema DATA --target-database DEV_DB --target-schema DATA_BKP --drop-target YES --db-type APP_DB
  python snf_clone_schema.py --connection SNF_QA --source-database PROD_DB --source-schema STAGING --target-database BKP_DB --target-schema STAGING --drop-target NO --db-type BKP_DB
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--source-database",
        required=True,
        metavar="source_database_name",
        help="Source database name containing the schema to clone",
    )
    mandatory.add_argument(
        "--source-schema",
        required=True,
        metavar="source_schema_name",
        help="Source schema name to clone from",
    )
    mandatory.add_argument(
        "--target-database",
        required=True,
        metavar="target_database_name",
        help="Target database name where schema will be cloned",
    )
    mandatory.add_argument(
        "--target-schema",
        required=True,
        metavar="target_schema_name",
        help="Target schema name to clone into",
    )
    mandatory.add_argument(
        "--drop-target",
        required=True,
        metavar="drop_flag",
        choices=["YES", "NO"],
        help="Whether to drop the target schema if it already exists (YES or NO)",
    )
    mandatory.add_argument(
        "--db-type",
        required=True,
        metavar="database_type",
        choices=["APP_DB", "BKP_DB"],
        help="Type of target database for access provisioning (APP_DB or BKP_DB)",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(
    engine,
    connection_name,
    source_database,
    source_schema,
    target_database,
    target_schema,
    drop_target,
    database_type,
):
    """
    Execute the clone schema command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        source_database: str - Source database containing the schema.
        source_schema: str - Source schema to clone from.
        target_database: str - Target database for the cloned schema.
        target_schema: str - Target schema name.
        drop_target: str - Whether to drop target if exists (YES or NO).
        database_type: str - Type of database (APP_DB or BKP_DB).
    """
    logger = engine.logger

    print(f"\n{'='*70}")
    print(f"  Schema Clone")
    print(f"  Source: {source_database}.{source_schema}")
    print(f"  Target: {target_database}.{target_schema}")
    print(f"  Connection: {connection_name}")
    print(f"  Drop Target: {drop_target} | DB Type: {database_type}")
    print(f"{'='*70}\n")

    logger.info(
        f"Starting schema clone from '{source_database}.{source_schema}' to "
        f"'{target_database}.{target_schema}' with drop_target='{drop_target}', db_type='{database_type}'"
    )

    engine.clone_schema(
        connection_name=connection_name,
        source_database=source_database,
        source_schema=source_schema,
        target_database=target_database,
        target_schema=target_schema,
        drop_target=(drop_target == "YES"),
        database_type=database_type,
    )

    logger.info(
        f"Schema clone completed from '{source_database}.{source_schema}' to "
        f"'{target_database}.{target_schema}'"
    )

    print(f"\n{'='*70}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*70}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the clone schema command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {
                "source_database": args.source_database,
                "source_schema": args.source_schema,
                "target_database": args.target_database,
                "target_schema": args.target_schema,
                "drop_target": args.drop_target,
                "db_type": args.db_type,
            },
            ["source_database", "source_schema", "target_database", "target_schema", "drop_target", "db_type"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            source_database=args.source_database,
            source_schema=args.source_schema,
            target_database=args.target_database,
            target_schema=args.target_schema,
            drop_target=args.drop_target,
            database_type=args.db_type,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in clone_schema: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in clone_schema: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
