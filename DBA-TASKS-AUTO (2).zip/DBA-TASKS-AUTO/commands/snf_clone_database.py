#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Clone Database Command

Clones a source database to a target database in Snowflake, then sets up
standard database roles, account role, and access provisioning on the target.

Orchestrates:
  1. Clone source database to target
  2. Drop cloned source database roles from target
  3. Create fresh database roles on target
  4. Create account role on target
  5. Provision access on target

Usage:
    python snf_clone_database.py --connection SNF_DEV --source-database SRC_DB --target-database TGT_DB --drop-flag YES --db-type APP_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_clone_database.py",
        description="Clones a source database to a target database with full role and access setup",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_clone_database.py --connection SNF_DEV --source-database PROD_DB --target-database DEV_DB --drop-flag NO --db-type APP_DB
  python snf_clone_database.py --connection SNF_DEV --source-database PROD_DB --target-database DEV_DB --drop-flag YES --db-type APP_DB
  python snf_clone_database.py --connection SNF_QA --source-database PROD_DB --target-database BKP_DB --drop-flag NO --db-type BKP_DB
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--source-database",
        required=True,
        metavar="source_database_name",
        help="Source database name to clone from",
    )
    mandatory.add_argument(
        "--target-database",
        required=True,
        metavar="target_database_name",
        help="Target database name to clone into",
    )
    mandatory.add_argument(
        "--drop-flag",
        required=True,
        metavar="drop_flag",
        choices=["YES", "NO"],
        help="Whether to drop the target database if it already exists (YES or NO)",
    )
    mandatory.add_argument(
        "--db-type",
        required=True,
        metavar="database_type",
        choices=["APP_DB", "BKP_DB"],
        help="Type of database for access provisioning (APP_DB or BKP_DB)",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, source_database, target_database, drop_flag, database_type):
    """
    Execute the clone database command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        source_database: str - Source database to clone from.
        target_database: str - Target database to clone into.
        drop_flag: str - Whether to drop target if exists (YES or NO).
        database_type: str - Type of database (APP_DB or BKP_DB).
    """
    logger = engine.logger

    print(f"\n{'='*60}")
    print(f"  Database Clone")
    print(f"  Source: {source_database} -> Target: {target_database}")
    print(f"  Connection: {connection_name}")
    print(f"  Drop Flag: {drop_flag} | DB Type: {database_type}")
    print(f"{'='*60}\n")

    logger.info(
        f"Starting database clone from '{source_database}' to '{target_database}' "
        f"with drop_flag='{drop_flag}', db_type='{database_type}'"
    )

    engine.clone_database(
        connection_name=connection_name,
        source_database=source_database,
        target_database=target_database,
        drop_flag=(drop_flag == "YES"),
        database_type=database_type,
    )

    logger.info(
        f"Database clone completed from '{source_database}' to '{target_database}'"
    )

    print(f"\n{'='*60}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*60}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the clone database command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {
                "source_database": args.source_database,
                "target_database": args.target_database,
                "drop_flag": args.drop_flag,
                "db_type": args.db_type,
            },
            ["source_database", "target_database", "drop_flag", "db_type"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            source_database=args.source_database,
            target_database=args.target_database,
            drop_flag=args.drop_flag,
            database_type=args.db_type,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in clone_database: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in clone_database: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
