#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Access Provision Command

Provisions access/grants on a database and all its objects by creating and
configuring database roles with appropriate privilege levels (RO, RW, RWD, C)
and granting them to account roles as defined in the ACCESS_TO_ROLES metadata table.

Usage:
    python access_provision.py --connection SNF_DEV --database MY_DB --db-type APPLICATION_DB
    python access_provision.py --connection SNF_DEV --database MY_DB --db-type BKP_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_access_provision.py",
        description="Provisions access/grants on a database and all its objects using database roles",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_access_provision.py --connection SNF_DEV --database MY_APP_DB --db-type APP_DB
  python snf_access_provision.py --connection SNF_DEV --database MY_BKP_DB --db-type BKP_DB
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--database",
        required=True,
        metavar="database_name",
        help="Database name to provision access on",
    )
    mandatory.add_argument(
        "--db-type",
        required=True,
        metavar="database_type",
        choices=["APP_DB", "BKP_DB"],
        help="Type of database (APP_DB or BKP_DB)",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, database_name, database_type):
    """
    Execute the access provision command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        database_name: str - Database to provision access on.
        database_type: str - Type of database (APPLICATION_DB or BKP_DB).
    """
    logger = engine.logger

    print(f"\n{'='*60}")
    print(f"  Access Provision")
    print(f"  Database: {database_name} | Connection: {connection_name}")
    print(f"  DB Type: {database_type}")
    print(f"{'='*60}\n")

    logger.info(
        f"Starting access provision for database '{database_name}' "
        f"with type '{database_type}'"
    )

    engine.provision_database_access(
        connection_name=connection_name,
        database_name=database_name,
        database_type=database_type,
    )

    logger.info(
        f"Access provision completed for database '{database_name}'"
    )

    print(f"\n{'='*60}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*60}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the access provision command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {"database": args.database, "db_type": args.db_type},
            ["database", "db_type"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            database_name=args.database,
            database_type=args.db_type,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in access_provision: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in access_provision: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
