#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Insert Data by Column Match Command

Inserts data from a source table to a target table by matching column names.
Handles column mapping, default values, nullable columns, and optional INSERT OVERWRITE.

Usage:
    python snf_insert_data_by_column_match.py --connection SNF_DEV \
        --source-database SRC_DB --source-schema SRC_SCH --source-table SRC_TBL \
        --target-database TGT_DB --target-schema TGT_SCH --target-table TGT_TBL \
        --truncate-target NO
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_insert_data_by_column_match.py",
        description="Inserts data from source table to target table by matching column names",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Basic insert with column matching
  python snf_insert_data_by_column_match.py --connection SNF_DEV \\
      --source-database SRC_DB --source-schema SRC_SCH --source-table SRC_TBL \\
      --target-database TGT_DB --target-schema TGT_SCH --target-table TGT_TBL \\
      --truncate-target NO

  # Insert with source filter
  python snf_insert_data_by_column_match.py --connection SNF_DEV \\
      --source-database SRC_DB --source-schema SRC_SCH --source-table SRC_TBL \\
      --source-filter "STATUS='ACTIVE' AND CREATED_DATE >= '2024-01-01'" \\
      --target-database TGT_DB --target-schema TGT_SCH --target-table TGT_TBL \\
      --truncate-target NO

  # Insert with truncate (INSERT OVERWRITE)
  python snf_insert_data_by_column_match.py --connection SNF_DEV \\
      --source-database SRC_DB --source-schema SRC_SCH --source-table SRC_TBL \\
      --target-database TGT_DB --target-schema TGT_SCH --target-table TGT_TBL \\
      --truncate-target YES
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--source-database",
        required=True,
        metavar="database_name",
        help="Source database name",
    )
    mandatory.add_argument(
        "--source-schema",
        required=True,
        metavar="schema_name",
        help="Source schema name",
    )
    mandatory.add_argument(
        "--source-table",
        required=True,
        metavar="table_name",
        help="Source table name",
    )
    mandatory.add_argument(
        "--target-database",
        required=True,
        metavar="database_name",
        help="Target database name",
    )
    mandatory.add_argument(
        "--target-schema",
        required=True,
        metavar="schema_name",
        help="Target schema name",
    )
    mandatory.add_argument(
        "--target-table",
        required=True,
        metavar="table_name",
        help="Target table name",
    )
    mandatory.add_argument(
        "--truncate-target",
        required=True,
        metavar="YES|NO",
        choices=["YES", "NO"],
        default="NO",
        help="Enable INSERT OVERWRITE to truncate target before insert (YES or NO, default: NO)",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--source-filter",
        required=False,
        default=None,
        metavar="filter_condition",
        help="WHERE clause filter for source table (e.g., \"STATUS='ACTIVE'\")",
    )
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, source_database, source_schema, source_table,
                    target_database, target_schema, target_table, truncate_target, source_filter):
    """
    Execute the insert data by column match command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        source_database: str - Source database name.
        source_schema: str - Source schema name.
        source_table: str - Source table name.
        target_database: str - Target database name.
        target_schema: str - Target schema name.
        target_table: str - Target table name.
        truncate_target: str - 'YES' to enable INSERT OVERWRITE, 'NO' for plain INSERT.
        source_filter: str or None - Optional WHERE clause filter for source table.
    """
    logger = engine.logger

    # Convert truncate_target to boolean
    truncate_flag = truncate_target.upper() == "YES"

    # Build fully qualified table names for display
    source_fqn = f"{source_database}.{source_schema}.{source_table}"
    target_fqn = f"{target_database}.{target_schema}.{target_table}"

    print(f"\n{'='*70}")
    print(f"  Insert Data by Column Match")
    print(f"  Source: {source_fqn}")
    print(f"  Target: {target_fqn}")
    print(f"  Filter: {source_filter if source_filter else '(none)'}")
    print(f"  Truncate Target: {truncate_target}")
    print(f"  Connection: {connection_name}")
    print(f"{'='*70}\n")

    logger.info(
        f"Starting insert data by column match from '{source_fqn}' to '{target_fqn}'"
    )

    engine.insert_data_by_column_match(
        connection_name=connection_name,
        source_database=source_database,
        source_schema=source_schema,
        source_table=source_table,
        target_database=target_database,
        target_schema=target_schema,
        target_table=target_table,
        truncate_target=truncate_flag,
        source_filter=source_filter,
    )

    logger.info(
        f"Insert data by column match completed from '{source_fqn}' to '{target_fqn}'"
    )

    print(f"\n{'='*70}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*70}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the insert data by column match command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {
                "source_database": args.source_database,
                "source_schema": args.source_schema,
                "source_table": args.source_table,
                "target_database": args.target_database,
                "target_schema": args.target_schema,
                "target_table": args.target_table,
                "truncate_target": args.truncate_target,
            },
            [
                "source_database",
                "source_schema",
                "source_table",
                "target_database",
                "target_schema",
                "target_table",
                "truncate_target",
            ],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            source_database=args.source_database,
            source_schema=args.source_schema,
            source_table=args.source_table,
            target_database=args.target_database,
            target_schema=args.target_schema,
            target_table=args.target_table,
            truncate_target=args.truncate_target,
            source_filter=args.source_filter,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in insert_data_by_column_match: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in insert_data_by_column_match: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
