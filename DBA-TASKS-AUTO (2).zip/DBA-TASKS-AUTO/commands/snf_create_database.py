#!/usr/bin/env python3
"""
Snowflake DBA Tasks Automation - Create Database Command

Creates a standard database in a Snowflake account as per customer standards,
including database roles, account role, and access provisioning.

Orchestrates:
  1. Database creation (with optional drop if exists)
  2. Database role creation (snf_create_db_roles)
  3. Account role creation (snf_create_db_account_role)
  4. Access provisioning (snf_access_provision)

Usage:
    python snf_create_database.py --connection SNF_DEV --database MY_DB --drop-flag YES --db-type APP_DB
"""

import sys
import os
import argparse

# Add framework root to Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.engine import Engine, create_engine_from_args, trace, validate_required_params
from core.logger import get_logger


# =============================================================================
# Argument Parser
# =============================================================================

def build_parser():
    """
    Build and return the argument parser for this command.
    """
    parser = argparse.ArgumentParser(
        prog="snf_create_database.py",
        description="Creates a standard database in Snowflake with roles and access provisioning",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python snf_create_database.py --connection SNF_DEV --database MY_APP_DB --drop-flag NO --db-type APP_DB
  python snf_create_database.py --connection SNF_DEV --database MY_APP_DB --drop-flag YES --db-type APP_DB
  python snf_create_database.py --connection SNF_QA --database MY_BKP_DB --drop-flag NO --db-type BKP_DB
        """,
    )

    # Mandatory arguments group
    mandatory = parser.add_argument_group("Mandatory arguments")
    mandatory.add_argument(
        "--connection",
        required=True,
        metavar="conn_name",
        help="Snowflake connection name from config (must exist in dba_tasks_config.yaml)",
    )
    mandatory.add_argument(
        "--database",
        required=True,
        metavar="database_name",
        help="Database name to create",
    )
    mandatory.add_argument(
        "--drop-flag",
        required=True,
        metavar="drop_flag",
        choices=["YES", "NO"],
        help="Whether to drop and re-create the database if it already exists (YES or NO)",
    )
    mandatory.add_argument(
        "--db-type",
        required=True,
        metavar="database_type",
        choices=["APP_DB", "BKP_DB"],
        help="Type of database for access provisioning (APP_DB or BKP_DB)",
    )

    # Optional arguments group
    optional = parser.add_argument_group("Optional arguments")
    optional.add_argument(
        "--pipeline-id",
        required=False,
        default=None,
        metavar="pipeline_id",
        help="Azure DevOps pipeline Build ID (auto-populated when triggered by pipeline)",
    )

    return parser


# =============================================================================
# Command Logic
# =============================================================================

@trace
def execute_command(engine, connection_name, database_name, drop_flag, database_type):
    """
    Execute the create database command.

    Args:
        engine: Engine - Initialized engine instance.
        connection_name: str - Connection to use.
        database_name: str - Database to create.
        drop_flag: str - Whether to drop if exists (YES or NO).
        database_type: str - Type of database (APP_DB or BKP_DB).
    """
    logger = engine.logger

    print(f"\n{'='*60}")
    print(f"  Database Creation")
    print(f"  Database: {database_name} | Connection: {connection_name}")
    print(f"  Drop Flag: {drop_flag} | DB Type: {database_type}")
    print(f"{'='*60}\n")

    logger.info(
        f"Starting database creation for '{database_name}' "
        f"with drop_flag='{drop_flag}', db_type='{database_type}'"
    )

    engine.create_database(
        connection_name=connection_name,
        database_name=database_name,
        drop_flag=(drop_flag == "YES"),
        database_type=database_type,
    )

    logger.info(
        f"Database creation completed for '{database_name}'"
    )

    print(f"\n{'='*60}")
    print(f"  COMPLETED SUCCESSFULLY")
    print(f"{'='*60}\n")


# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    """Main entry point for the create database command."""
    parser = build_parser()
    args = parser.parse_args()

    engine = None
    exit_code = 0

    try:
        engine, connection_name = create_engine_from_args(args)

        # Validate command-specific required parameters
        validate_required_params(
            {"database": args.database, "drop_flag": args.drop_flag, "db_type": args.db_type},
            ["database", "drop_flag", "db_type"],
        )

        # Execute the command
        execute_command(
            engine=engine,
            connection_name=connection_name,
            database_name=args.database,
            drop_flag=args.drop_flag,
            database_type=args.db_type,
        )

    except ValueError as e:
        # Input validation errors
        print(f"ERROR: {str(e)}", file=sys.stderr)
        exit_code = 2
    except ConnectionError as e:
        # Connection failures
        print(f"CONNECTION ERROR: {str(e)}", file=sys.stderr)
        exit_code = 1
    except RuntimeError as e:
        # Runtime failures (SQL execution, validation)
        print(f"RUNTIME ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.erro(f"Runtime error in create_database: {str(e)}")
        exit_code = 1
    except Exception as e:
        # Unexpected errors
        print(f"UNEXPECTED ERROR: {str(e)}", file=sys.stderr)
        if engine and engine.logger:
            engine.logger.sevr(f"Unhandled exception in create_database: {str(e)}")
        exit_code = 1
    finally:
        # Always shutdown engine cleanly
        if engine:
            engine.shutdown()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
